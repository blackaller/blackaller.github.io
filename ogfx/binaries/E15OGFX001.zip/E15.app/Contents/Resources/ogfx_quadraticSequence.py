#
#  QuadraticCurves.py
#  OpenGFX
#
#  Created by blackaller on 10/24/07.
#  Copyright (c) 2007 MITPLW. All rights reserved.
# 


from drawengine import *
from math import *
import random 

size = 256

tsize(size)

class Polygon:
	global a, pipi, lalpha, falpha
	def __init__(self, numVertices, radius):
		self.n = numVertices
		self.r = radius	
		
		
	def setFill(self,r,g,b,a):
		color(r,g,b,a)
	
	def setLine(self,r,g,b,a):
		stroke(r,g,b,a)
	
	def displayPolygon(self):
		
		oscillateradius = radiusOscillator(self.r, a, 16, 0)
		
		moveto(oscillateradius,0)
		beginline()
		
		for i in range(self.n):
			k=1+i
			controlPointX = ((50*sin(a*k))+oscillateradius) * cos((k*pipi)/self.n - (pi)/self.n)
			controlPointY = ((50*sin(a*k))+oscillateradius) * sin((k*pipi)/self.n - (pi)/self.n)
			quadcurve(controlPointX, controlPointY, oscillateradius * cos(((k-1/2)*pipi)/self.n), oscillateradius * sin(((k-1/2)*pipi)/self.n))
		closeline()
		
		for i in range(self.n):
			k=1+i
			stroke(0,0,0,0)
			color(float(i)/self.n,float(i)/self.n,0.8,0.4)
			controlPointX = ((50*sin(a*k))+oscillateradius) * cos((k*pipi)/self.n - (pi)/self.n)
			controlPointY = ((50*sin(a*k))+oscillateradius) * sin((k*pipi)/self.n - (pi)/self.n)
			ellipse(controlPointX, controlPointY,2 + 8*sin(a*k),2 + 8*sin(a*k))

history(1,0.05, 1)

linejoin(2)
linewidth(4)

pipi = 2*pi
a=2

width = 256
height = 256

lalpha = 0.8
falpha = 0.2

p= Polygon(13, (width/8) * (1+sin(a)) + 10 )

envcolor(1,1,1)

blendmode(0,2)

def draw():
	global a, width, height, lalpha, falpha, p
	background(1,1,1,0)	

	push()
	translate(width/2,height/2)
	push()
	rotate(a)
	p.setFill(cos(sin(a)), sin(cos(a)), sin(a), falpha)
	p.setLine(1, cos(a/4), sin(a/4), lalpha)
	p.displayPolygon()
	pop()
	pop()
	a+=0.005

def superFormulaRadius(angle, m, n1, n2, n3):
	rad = ( abs( cos(m*angle/4)**n2 ) + abs( cos(m*angle/4)**n3 ) )**(-1/n1)
	return rad

def radiusRandomizer(radius, range):
	rand = float(random.randint(0,100))
	rad = radius - range * cos(rand)  
	return rad

def radiusOscillator(radius, osc, range, var):
	rand = float(random.randint(0,var))
	rad = radius - radius * cos(osc+rand) /range 
	return rad

state = 0

doArray = []
doArray.append(lambda : doStep1())
doArray.append(lambda : doStep2())
doArray.append(lambda : doStep3())
doArray.append(lambda : doStep4())
doArray.append(lambda : doStep5())
doArray.append(lambda : doStep6())
doArray.append(lambda : doStep7())
doArray.append(lambda : doStep8())
doArray.append(lambda : doStep9())
doArray.append(lambda : doStep10())

undoArray = []
undoArray.append(lambda : undoStep1())
undoArray.append(lambda : undoStep2())
undoArray.append(lambda : undoStep3())
undoArray.append(lambda : undoStep4())
undoArray.append(lambda : undoStep5())
undoArray.append(lambda : undoStep6())
undoArray.append(lambda : undoStep7())
undoArray.append(lambda : undoStep8())
undoArray.append(lambda : undoStep9())
undoArray.append(lambda : undoStep10())

print "Use the left & right arrow keys to step through this animation sequence of quadratic curves.\n"

def onRight():
  global state, doArray
  if state == 10:
    print "Nothing happens after Step 10."
    return
  func = doArray[state]
  state = state + 1
  func()

def onLeft():
  global state, undoArray
  if state == 0:
    print "Nothing happens before Step 1."
    return
  func = undoArray[state-1]
  state = state - 1
  if state < 0:
    state = 0
  func()

def doStep1():
  global lalpha, falpha, a
  print "Doing Step 1 :: Applying this history command of 200 frames and incremental rotation."
  lalpha = 0.1
  falpha = 0.01
  history(200, 0.02, 1)

def undoStep1():
  global lalpha, falpha
  print "Undoing Step 1 :: Removing the history command. Displaying only one animation frame."
  lalpha = 0.8
  falpha = 0.2
  history(1, 0.02, 0)

def doStep2():
  #Angle the camera to see perspective.
  print "Doing Step 2 :: Changing the perspective. Note you can also use the scroll wheel and holding down the cmd key to navigate the scene."
  camera(-1.0, 0.0, -1.0, 3.5501196384429932, 0.0, -2.1374876499176025)

def undoStep2():
  #Straighten out the camera.
  print "Undoing Step 2 :: Resetting the perspective."
  camera(0.0, 0.0, -1.0, 0.0, 0.0, 1.8)

def doStep3():
  print "Doing Step 3 :: Invert background."
  envcolor(0, 0, 0)

def undoStep3():
  print "Undoing Step 3 :: Invert back."
  envcolor(1, 1, 1)

def doStep4():
  print "Doing Step 4 :: Applying a Crystallization filter."
  root.crystallize("radius", 4)

def undoStep4():
  print "Undoing Step 4 :: Removing the Crystallization filter."
  root.removeFilter("crystallize", lambda: del_crystallize())

def doStep5():
  print "Doing Step 5 :: Applying a gaussian blur effect."
  root.gaussianblur("radius",2)

def undoStep5():
  print "Undoing Step 5 :: Removing the gaussian blur effect."
  root.removeFilter("gaussianblur", lambda: del_gaussianblur())
  

def doStep6():
  print "Doing Step 6 :: Applying an edge and saturation filters."
  root.edges("intensity",8)
  root.colorcontrols("saturation",10)

def undoStep6():
  print "Undoing Step 6 :: Removing the edge and saturation filters."
  root.removeFilter("edges", lambda: del_edges())
  root.removeFilter("colorcontrols", lambda: del_colorcontrols())

def doStep7():
  print "Doing Step 7 :: Navigating inside."
  camera(0.0, 0.0, -1.0, 0.0, 0.0, -3.3) # going in


def undoStep7():
  print "Undoing Step 7 :: Navigating back out."
  camera(-1.0, 0.0, -1.0, 3.5501196384429932, 0.0, -2.1374876499176025)

def doStep8():
  print "Doing Step 7 :: Changing to screen blend mode."
  blendmode(0,8)

def undoStep8():
  print "Undoing Step 7 :: Removing screen blend mode."
  blendmode(0,2)

def doStep9():
  global lalpha, falpha
  print "Doing Step 9 :: Changing to minmax blend mode."
  lalpha = 0.4
  falpha = 0.01
  blendmode(3,0)

def undoStep9():
  global lalpha, falpha
  print "Undoing Step 9 :: Removing minmax blend mode."
  lalpha = 0.1
  falpha = 0.01
  blendmode(0,8)

def doStep10():
  print "Doing Step 10 :: Back to origin."
  undoStep9()
  undoStep8()
  undoStep7()
  undoStep6()
  undoStep5()
  undoStep4()
  undoStep3()
  undoStep2()
  undoStep1()

def undoStep10():
  print "Undoing Step 10 :: Back to 10."
  doStep1()
  doStep2()
  doStep3()
  doStep4()
  doStep5()
  doStep6()
  doStep7()
  doStep8()
  doStep9()



#
#  BlendingHistory.py
#  OpenGFX
#
#  Created by blackaller on 10/24/07.
#  Copyright (c) 2007 MITPLW. All rights reserved.
#  

from drawengine import *
from math import *
#Size of the texture
size = 512

tsize(size)

history(200, 0.05, 1.0)

#setup globals
a=0
b=0
c=250
width=512
height=512
radiusX=0
radiusY=0
period=7

# filters
#root.gaussianblur("radius",10)
#root.colorcontrols("saturation",20)
#root.edges("intensity",6)
#root.pixellate("scale",6)

# filter removals
#root.removeFilter("gaussianblur", lambda: del_gaussianblur())
#root.removeFilter("colorcontrols", lambda: del_colorcontrols())
#root.removeFilter("edges", lambda: del_edges())
#root.removeFilter("pixellate", lambda: del_pixellate())

blendmode(0,0)

def draw():
	#lightdirection(20*cos(a/10),20*sin(a/10),60,1)
	global a,b,c, width, height, radiusX, radiusY, period
	background(1,1,1,0.01)	
	radiusX=10+abs(20*sin(c))
	radiusY=10+abs(20*sin(c))
	
	# custom function calls
	for i in range(12):
		radiusX=i+5+abs(20*sin(c))
		radiusY=i+5+abs(20*sin(c))
		display (width/2+(200*sin((a))),height/2+(200*sin((b))))
		display (width/2+(200*sin((a+pi/ period*i))),height/2+(200*sin((b+pi/ period*i))))
		display (width/2+(200*sin(-(a+2*pi/ period*i))),height/2+(200*sin((b+2*pi/ period*i))))
		display (width/2+(200*sin((-a))),height/2+(200*sin((-b))))
		display (width/2+(200*sin(-(a+pi/ period*i))),height/2+(200*sin(-(b+pi/ period*i))))
		display (width/2+(200*sin((a+2*pi/ period*i))),height/2+(200*sin(-(b+2*pi/ period*i))))
	a=a+0.1
	b=b+0.15
	c=c+0.025
	period=sin(period/2) + period/2 +0.01


# custom function definition
def display(x,y):	
	push()
	translate(x,y)
	color(1,1,0,1)
	ellipse(-1.5 * radiusX,-1.5 * radiusY, 3 * radiusX, 3 * radiusY)
	color(1,0,0,1)
	ellipse(-radiusX,-radiusY, 2 * radiusX, 2 * radiusY)
	color(1,1,0,1)
	ellipse(0.5*-radiusX,0.5*-radiusY, radiusX, radiusY)
	pop()
#
#  PictureXSQubert.py
#  E15
#
#  Created by blackaller on 10/30/07.
#  Copyright (c) 2007 MITPLW. All rights reserved.
#

from staticwriter import *

from random import random
from math import *

envcolor(0.1,0.1,0.1)


start=12885
iconsize=20
monton=8
id=0
position=2
offset=0
x, y, z = (0, 0, -1)
#x, z = (position, -position)


for k in range(monton):	
	x, z = (position, -offset-k*0.640)
	for i in range(monton):
		#id= start + (monton*k) + i #palante
		id= start - (monton*k) - i #reversa
		iconurl = 'http://pixs.media.mit.edu/pictures/small/' + str(id)
		iconurl_1 = 'http://pixs.media.mit.edu/pictures/small/' + str(id-3333)
		iconurl_2 = 'http://pixs.media.mit.edu/pictures/small/' + str(id-6666)
		print iconurl
		print iconurl_1
		print iconurl_2

		elem_begin(256,256, "3000-" + str(id))
		elem_pos(x, (y), (z+0.640))
		background(1,1,1,1)
		push()
		
		scale(1.3,1.3)
		placeimg(iconurl_1,0,0)
		pop()
		elem_end()


		elem_begin(256,256, "0000-" + str(id))
		elem_xform(-90, 0, 0)
		elem_pos(x, (y), (z))
		background(1,1,1,1)
		push()
		scale(1.3,1.3)
		placeimg(iconurl,0,0)
		pop()
		elem_end()

		#imgload(iconurl_1, "tn", x, (y+0.305), (z-0.305), -90, 0, 0)
		#imgload(iconurl_2, "tn", (x+0.305), y, (z-0.305), 0, 90, 0)

		elem_begin(256,256, "6000-" + str(id))
		elem_xform(0, 90, 0)
		elem_pos((x+0.640), (y),  (z+0.640))
		background(1,1,1,1)
		push()
		scale(1.3,1.3)
		placeimg(iconurl_2,0,0)
		pop()
		elem_end()

		x += float(iconsize)/31.3
		z -= float(iconsize)/31.3
	y += float(iconsize)/31.3
	
	

def onHit(e_id):
  print(e_id)
  camera_goto(e_id)
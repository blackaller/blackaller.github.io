#
#  browse.py
#  E15
#
#  Created by buza on 11/8/07.
#  Copyright (c) 2007 MITPLW. All rights reserved.
#

from staticwriter import *

browse("http://www.google.com")

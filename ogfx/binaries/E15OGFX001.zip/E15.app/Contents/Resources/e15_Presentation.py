#
#  e15_Presentation.py
#  E15
#
#  Created by Takashi Okamoto on 02/04/08.
#  Copyright (c) 2008 PLW. All rights reserved.
#
import os
from math import *
from staticwriter import *
from random import random

"""

E15 Presentation README.

One instance of Presentation class should be created with instances of 
Slides. To create a slide, all you need to do is instantiate, then 
redefine draw().

To redefine an instance method of a class, instantiate the class then:

# create object of instance method type
instancemethod = type(Slide.draw)

# define a new method
def new_draw(self):
  # redefinition of draw

# map new_draw() to slide.draw()
slide.draw = instancemethod(new_draw, slide, Slide)

"""

global_camera_speed(1.0/15.0)
global_elem_speed(1.0/30.0)

class Presentation:
  """
  Collection of Slides
  
  ----------------------------------------------------------------------
  
  Class Variables:
  
  DEFAULT_IMAGE:
    url to E15 application image
  
  RESOURCE_URL:
    url to resource directory containing all images
  
  ----------------------------------------------------------------------
  
  Instance Variables:
  
  slides:
    (list) list of Slide instances
  
  length:
    (int) number of slides
  
  index:
    (int) internal index number for current slide instance
  
  draw_slide_numbers:
    (bool) if True, draws slide numbers. Default: False
  
  ----------------------------------------------------------------------
  
  """
  
  DEFAULT_IMAGE = "http://buza.mitplw.com/plw/E15.png"
  RESOURCE_URL = "http://e15.media.mit.edu/E15SupportMaterial/E15Presentation/"
  
  def __init__(self, slides, draw_numbers=False):
    self.slides = slides
    self.length = len(slides)
    self.index = -1
    self.draw_slide_numbers = draw_numbers
    self.draw()
  
  def draw(self):
    """
    Draw all slides.
    """
    for slide in self.slides:
      slide.draw()
      if self.draw_slide_numbers:
        slide.draw_slide_number()
  
  def next(self):
    """
    Move to next slide. If last, goes back to the first.
    """
    if self.index < self.length-1:
      self.index += 1
    else:
      self.index = 0
    camera_goto(self.slides[self.index].key_element, -.3, .32, 0)
  
  def prev(self):
    """
    Move to the previous slide. If first, goes back to last.
    """
    if self.index > 0:
      self.index -= 1
    else:
      self.index = self.length-1
    camera_goto(self.slides[self.index].key_element, -.3, .32, 0)


class Slide:
  """
  Slide Class
  
  ----------------------------------------------------------------------
  
  Class Variables:
  
  NUM_SLIDES:
    Number of slides created. Must be incremented in __init__
  
  ----------------------------------------------------------------------
  
  Instance Variables:
  
  slide_number:
    (int) slide number relative to other slides in Presentation
  
  key_element:
    (str) id of element in which camera will focus on
  
  ----------------------------------------------------------------------
  
  """
  
  NUM_SLIDES = 0
  
  
  def __init__(self, x, y, z, rx, ry, rz):
    self.set_position(x, y, z)
    self.set_rotation(rx, ry, rz)
    self.slide_number = Slide.NUM_SLIDES
    self.key_element = 'key_' + `Slide.NUM_SLIDES`
    Slide.NUM_SLIDES += 1
  
  def draw(self):
    """
    Override this method for drawing slide. Make sure one element is named with id self.key_element.
    Slide will face this element when using Presentation.next() and Presentation.prev()
    """
    font("ApexNew-Book", 72)
    fontcolor(.6, .1, .8, .95)
    textbox(self.key_element, 'Need to override draw()', 400, self.x, self.y, self.z, self.rx, self.ry, self.rz)
  
  def draw_slide_number(self):
    fontsize = 24
    font("ApexNew-Heavy", fontsize)
    fontcolor(.25, .25, .25, .95)
    # elem_begin(255, 255, 'slide_' + `self.slide_number`)
    # elem_pos(self.x, self.y+.2, self.z-.0001)
    # elem_xform(self.rx, self.ry, self.rz)
    # text('Slide: ' + `self.slide_number`, 0, fontsize)
    # elem_end()
    textbox('slide_' + `self.slide_number`, 'Slide: ' + `self.slide_number`, 200, self.x, self.y+.2, self.z-.001, self.rx, self.ry, self.rz)

  """
  Properties
  """

  def set_position(self, x, y, z):
    self.x, self.y, self.z = (x, y, z)
  
  def get_position(self):
    return (self.x, self.y, self.z)
  
  def set_rotation(self, rx, ry, rz):
    self.rx, self.ry, self.rz = (rx, ry, rz)
  
  def get_rotation(self):
    return (self.rx, self.ry, self.rz)
    
  position = property(set_position, get_position)
  rotation = property(set_rotation, get_rotation)


"""
-------------------------------------------------------------------------------

Create and position slides

"""
slides = []
for i in range(8):
  slides.append(Slide(random()*20, random()*20, -12*i, 0, (random() - .5)*90, 0))


"""
-------------------------------------------------------------------------------

Define Slides by overriding draw()

"""
# Redefining instance methods in Python is confusing and dumb...But this way works.
instancemethod = type(Slide.draw)

"""
*******************************************************************************
Slide 0: Introduction
*******************************************************************************
"""
# def slide_0(self):
#   # font properties
#   fontsize = 42
#   font("ApexNew-Book", fontsize)
#   fontcolor(.1, .9, .8, .95)
#   
#   # geometry change
#   # this is really confusing. When you calculate, it's simple to fix rotation 
#   # along one axis and reduce it to a two-dimensional problem.
#   x_offset = cos(self.ry*pi/180.0)
#   z_offset = sin(self.ry*pi/180.0)
#   
#   # dummy frame
#   elem_begin(512, 128, self.key_element)
#   elem_pos(self.x + 256/400.0*x_offset - .25*z_offset, self.y - 256/800.0, self.z - 256/400.0*z_offset - .25*x_offset)
#   elem_xform(self.rx, self.ry, self.rz)
#   #background(1, 1, 1, 0.5)
#   elem_end()
#   
#   elem_begin(512, 512, 'E15_logo')
#   elem_pos(self.x, self.y, self.z)
#   elem_xform(self.rx, self.ry, self.rz)
#   placeimg(Presentation.DEFAULT_IMAGE, 0, 0)
#   elem_end()
#   
#   text = "E15 is a three-dimensional OpenGL-based web environment, enabling new interactions with web content beyond the traditional browser."
#   h = textbox('slide_0_texta', text, 512, self.x+552/400.0*x_offset, self.y, self.z-552/400.0*z_offset, self.rx, self.ry, self.rz)
#   
#   fontsize = 24
#   font("ApexNew-Ultra", fontsize)
#   fontcolor(.9, .1, .8, .99)
#   text = "Continue >>"
#   textbox('slide_0_textb', text, 512, self.x+552/400.0*x_offset, self.y - h[1]/400.0, self.z-552/400.0*z_offset, self.rx, self.ry, self.rz)
# 
# slides[0].draw = instancemethod(slide_0, slides[0], Slide)

"""
*******************************************************************************
Slide 0: Introduction
*******************************************************************************
"""
def slide_0(self):
  # font properties
  fontsize = 28
  font("ApexNew-Book", fontsize, lineheight=fontsize+6.0)
  fontcolor(.9, .9, .8, .95)
  
  # geometry change
  # this is really confusing. When you calculate, it's simple to fix rotation 
  # along one axis and reduce it to a two-dimensional problem.
  x_offset = cos(self.ry*pi/180.0)
  z_offset = -sin(self.ry*pi/180.0) # watch out for the phase shift!
  
  # add x_offset to x and z_offset to z to move right
  # subtract x_offset to x and z_offset to z to move left
  # add z_offset to x and subtract x_offset to z to move into screen
  # subtract z_offset to x and add x_offset to z to move back out
  
  # dummy frame
  key = (768, 512)
  elem_begin(key[0], key[1], self.key_element)
  elem_pos(self.x  - 256/800.0*x_offset + .25*z_offset, self.y - 128.0/800.0, self.z  - 256/800.0*z_offset - .25*x_offset)
  elem_xform(self.rx, self.ry, self.rz)
  #background(1, 1, 1, 0.5)
  elem_end()
  
  elem_begin(512, 512, 'E15_logo')
  elem_pos(self.x, self.y, self.z)
  elem_xform(self.rx, self.ry, self.rz)
  placeimg(Presentation.DEFAULT_IMAGE, 0, 0)
  elem_end()
  
  text = "E15 is a three-dimensional OpenGL-based web environment, enabling new interactions with web content beyond traditional web browsers."
  h = textbox('slide_0_texta', text, 512, self.x - .3*z_offset, self.y - 600/800.0, self.z + .3*x_offset, self.rx, self.ry, self.rz)
  
  fontsize = 16
  font("ApexNew-Bold", fontsize, lineheight=fontsize+6.0)
  fontcolor(.9, .9, .8, .95)
  text = "Physical Language Workshop\n2008 MIT Media Lab"
  textbox('slide_0_textc', text, 512, self.x - .4*z_offset, self.y - (300+h[1])/400.0, self.z + .4*x_offset, self.rx, self.ry, self.rz)
  
  fontsize = 24
  font("ApexNew-Bold", fontsize)
  fontcolor(.9, .9, .8, .95)
  text = "Continue >>"
  textbox('slide_0_textb', text, 512, 10, self.y - (540.0-h[1])/400.0, 10, self.rx, self.ry, self.rz)
  global cx, cy, cz, crx, cry, crz
  cx, cy, cz, crx, cry, crz = (self.x + key[0]/800.0*x_offset - .5*z_offset, self.y - (356.0+h[1])/400.0, self.z + key[0]/800.0*z_offset + .5*x_offset, self.rx, self.ry, self.rz)
  callback("elem_moveto('slide_0_textb', cx, cy, cz, crx, cry, crz)", 10)

slides[0].draw = instancemethod(slide_0, slides[0], Slide)


"""
*******************************************************************************
Slide 1: Components
*******************************************************************************
"""
def slide_1(self):
  # font properties
  fontsize = 48
  font("ApexNew-Bold", fontsize)
  fontcolor(230/255.0, 20/255.0, 120/255.0, 0.95)
  
  # geometry change
  x_offset = cos(self.ry*pi/180.0)
  z_offset = -sin(self.ry*pi/180.0)
  key = (768, 512)
  
  # dummy frame
  elem_begin(key[0], key[1], self.key_element)
  elem_pos(self.x + key[0]/1600.0*x_offset + .25*z_offset, self.y - key[1]/1600.0, self.z + key[0]/1600.0*z_offset - .25*x_offset)
  elem_xform(self.rx, self.ry, self.rz)
  #background(1, 1, 1, 0.5)
  elem_end()
  
  text = "1. Components"
  h = textbox('slide_1_texta', text, 512, self.x - .22*z_offset, self.y + .1, self.z + .22*x_offset, self.rx, self.ry, self.rz)
  
  # images
  imgload(Presentation.RESOURCE_URL + '1_mainwindow.png', 'slide_1_mainwindow', self.x + x_offset + .2*z_offset, self.y + 20/400.0, self.z + z_offset - .2*x_offset, self.rx, self.ry, self.rz)
  imgload(Presentation.RESOURCE_URL + '1_console.png', 'slide_1_console', self.x + 700/400.0*x_offset - .05*z_offset, self.y - .5, self.z + 700/400.0*z_offset + .05*x_offset, self.rx, self.ry - 5, self.rz)
  imgload(Presentation.RESOURCE_URL + '1_webview.png', 'slide_1_webview', self.x - .15*x_offset, self.y - .25, self.z - .15*z_offset, self.rx, self.ry + 5, self.rz)
  
  # font properties
  fontsize = 27
  font("ApexNew-Book", fontsize, lineheight=fontsize+6.0)
  fontcolor(.9, .9, .8, .95)
  text = "E15 consists of a Python console, an OpenGL-enabled three-dimensional view and a web view. Users interact with E15 by writing Python scripts on the Python console. The main window displays graphical results of the executed code."
  h = textbox('slide_1_textb', text, 512, self.x + 1/40.0*x_offset - .4*z_offset, self.y - 1.125, self.z - 1/40.0*z_offset + .4*x_offset, self.rx, self.ry, self.rz)

slides[1].draw = instancemethod(slide_1, slides[1], Slide)


"""
*******************************************************************************
Slide 2: Web Browsing
*******************************************************************************
"""
def slide_2(self):
  # font properties
  fontsize = 48
  font("ApexNew-Bold", fontsize)
  fontcolor(230/255.0, 20/255.0, 120/255.0, 0.95)
  
  # geometry change
  x_offset = cos(self.ry*pi/180.0)
  z_offset = -sin(self.ry*pi/180.0)
  
  # dummy frame
  elem_begin(768, 256, self.key_element)
  elem_pos(self.x + .25*z_offset, self.y - 256/800.0, self.z - .25*x_offset)
  elem_xform(self.rx, self.ry, self.rz)
  #background(1, 1, 1, 0.5)
  elem_end()
  
  text = "2. Web Browsing"
  h = textbox('slide_2_texta', text, 512, self.x, self.y, self.z, self.rx, self.ry, self.rz)
  
  imgload(Presentation.RESOURCE_URL + '2_browser.png', 'slide_2_browser', self.x - 256/800.0*x_offset - .25*z_offset, self.y - .5, self.z - 256/800.0*z_offset + .25*x_offset, self.rx, self.ry + 10, self.rz)
  
  # font properties
  fontsize = 27
  font("ApexNew-Book", fontsize, lineheight=fontsize+6.0)
  fontcolor(.9, .9, .8, .95)
  text = "E15 has a built in web browser. In addition to traditional web interaction through web pages, visualizations are created in the three dimensional view. A visualization of navigation history is created, and the image representing the web page is the actual image of the page."
  h = textbox('slide_2_textb', text, 512, self.x + 512/400.0*x_offset, self.y - .1, self.z + 512/400.0*z_offset, self.rx, self.ry - 10, self.rz)

slides[2].draw = instancemethod(slide_2, slides[2], Slide)


"""
*******************************************************************************
Slide 3: Graphics
*******************************************************************************
"""
def slide_3(self):
  # font properties
  fontsize = 48
  font("ApexNew-Bold", fontsize)
  fontcolor(230/255.0, 20/255.0, 120/255.0, 0.95)
  
  # geometry change
  x_offset = cos(self.ry*pi/180.0)
  z_offset = -sin(self.ry*pi/180.0)
  
  # dummy frame
  elem_begin(1024, 768, self.key_element)
  elem_pos(self.x + .5*z_offset, self.y - 256/800.0, self.z - .5*x_offset)
  elem_xform(self.rx, self.ry, self.rz)
  #background(1, 1, 1, 0.5)
  elem_end()
  
  text = "3. Graphics: E15:oGFx"
  h = textbox('slide_3_texta', text, 512, self.x, self.y, self.z, self.rx, self.ry, self.rz)
  
  imgload(Presentation.RESOURCE_URL + '3_graphic_0.png', 'slide_3_0', self.x - .5*x_offset, self.y - .2, self.z - .5*z_offset, self.rx, self.ry + 10, self.rz)
  imgload(Presentation.RESOURCE_URL + '3_graphic_1.png', 'slide_3_1', self.x + 1050/400.0*x_offset, self.y - .7, self.z + 1050/400.0*z_offset, self.rx, self.ry - 10, self.rz)
  imgload(Presentation.RESOURCE_URL + '3_graphic_2.png', 'slide_3_2', self.x - 512/400.0*x_offset - .25*z_offset, self.y - .5, self.z - 512/400.0*z_offset + .25*x_offset, self.rx, self.ry + 10, self.rz)
  imgload(Presentation.RESOURCE_URL + '3_graphic_3.png', 'slide_3_3', self.x + 800/400.0*x_offset - .25*z_offset, self.y - 1.6, self.z + 800/400.0*z_offset + .25*x_offset, self.rx, self.ry, self.rz)
  imgload(Presentation.RESOURCE_URL + '3_graphic_4.png', 'slide_3_4', self.x - 50/400.0*x_offset - .3*z_offset, self.y - 1.5, self.z - 50/400.0*z_offset + .3*x_offset, self.rx, self.ry, self.rz)
  imgload(Presentation.RESOURCE_URL + '3_graphic_5.png', 'slide_3_5', self.x + x_offset - .4*z_offset, self.y - .75, self.z + z_offset + .4*x_offset, self.rx, self.ry, self.rz)
  
  # font properties
  fontsize = 27
  font("ApexNew-Book", fontsize, lineheight=fontsize+6.0)
  fontcolor(.9, .9, .8, .95)
  text = "E15 is a dynamic OpenGL texture engine, with its graphics engine, E15:oGFx. E15:oGFx can generate advanced 2D drawing through Apple's Quartz 2D, and provide rich graphics with support for CoreImage filters and GLSL shaders."
  h = textbox('slide_3_textb', text, 512, self.x + 512/400.0*x_offset - .3*z_offset, self.y - .1, self.z + 512/400.0*z_offset + .3*x_offset, self.rx, self.ry, self.rz)

slides[3].draw = instancemethod(slide_3, slides[3], Slide)


"""
*******************************************************************************
Slide 4: Typography
*******************************************************************************
"""
def slide_4(self):
  # font properties
  fontsize = 48
  font("ApexNew-Bold", fontsize)
  fontcolor(230/255.0, 20/255.0, 120/255.0, 0.95)
  
  # geometry change
  x_offset = cos(self.ry*pi/180.0)
  z_offset = -sin(self.ry*pi/180.0)
  
  # dummy frame
  elem_begin(1024, 512, self.key_element)
  elem_pos(self.x + .5*z_offset, self.y - 256/800.0, self.z - .5*x_offset)
  elem_xform(self.rx, self.ry, self.rz)
  #background(1, 1, 1, 0.5)
  elem_end()
  
  text = "4. Typography"
  h = textbox('slide_4_texta', text, 512, self.x, self.y, self.z, self.rx, self.ry, self.rz)
  
  imgload(Presentation.RESOURCE_URL + '4_type_0.png', 'slide_4_0', self.x + 256/400.0*x_offset - .2*z_offset, self.y - .2, self.z + 256/400.0*z_offset + .2*x_offset, self.rx, self.ry - 10, self.rz)
  
  # font properties
  fontsize = 32
  font("ApexNew-Book", fontsize, lineheight=fontsize+6.0)
  fontcolor(.9, .9, .8, .95)
  text = "E15 can render type beautifully, with automatic ligatures, kerning and full unicode support. Works with all major font formats including Truetype, PostScript and OpenType."
  h = textbox('slide_4_textb', text, 512, self.x - 256/400.0*x_offset - .4*z_offset, self.y - .75, self.z -256/400.0*z_offset + .4*x_offset, self.rx, self.ry, self.rz)

slides[4].draw = instancemethod(slide_4, slides[4], Slide)


"""
*******************************************************************************
Slide 5: Web Content
*******************************************************************************
"""
def slide_5(self):
  # font properties
  fontsize = 48
  font("ApexNew-Bold", fontsize)
  fontcolor(230/255.0, 20/255.0, 120/255.0, 0.95)
  
  # geometry change
  x_offset = cos(self.ry*pi/180.0)
  z_offset = -sin(self.ry*pi/180.0)
  
  # dummy frame
  elem_begin(1024, 512, self.key_element)
  elem_pos(self.x + .25*z_offset, self.y - 512/800.0, self.z - .25*x_offset)
  elem_xform(self.rx, self.ry, self.rz)
  #background(1, 1, 1, 0.5)
  elem_end()
  
  text = "5. Web Content"
  h = textbox('slide_5_texta', text, 512, self.x + .2*z_offset, self.y, self.z - .2*x_offset, self.rx, self.ry, self.rz)
  
  imgload(Presentation.RESOURCE_URL + '5_fb_mud.png', 'slide_5_mud', self.x + 460/400.0*x_offset, self.y - .2, self.z + 460/400.0*z_offset, self.rx, self.ry + 20, self.rz)
  imgload(Presentation.RESOURCE_URL + '5_fb_kate.png', 'slide_5_kate', self.x + 660/400.0*x_offset, self.y - .2, self.z + 660/400.0*z_offset, self.rx, self.ry + 20, self.rz)
  imgload(Presentation.RESOURCE_URL + '5_fb_black.png', 'slide_5_black', self.x + 870/400.0*x_offset + .1*z_offset, self.y - .2, self.z + 870/400.0*z_offset - .1*x_offset, self.rx, self.ry - 20, self.rz)
  imgload(Presentation.RESOURCE_URL + '5_fb_buza.png', 'slide_5_buza', self.x + 1060/400.0*x_offset - .3*z_offset, self.y - .5, self.z + 1060/400.0*z_offset + .3*x_offset, self.rx, self.ry - 20, self.rz)
  
  imgload(Presentation.RESOURCE_URL + '5_fb.png', 'slide_5_fb', self.x, self.y - 1.4, self.z, self.rx, self.ry, self.rz)
  imgload(Presentation.RESOURCE_URL + '5_wikipedia.png', 'slide_5_wp', self.x + 512/400.0*x_offset, self.y - 1, self.z + 512/400.0*z_offset, self.rx, self.ry, self.rz)
  
  print "hello", self.x, self.y - 1.4, self.z, self.rx, self.ry, self.rz

  # font properties
  fontsize = 32
  font("ApexNew-Book", fontsize, lineheight=fontsize+6.0)
  fontcolor(.9, .9, .8, .95)
  text = "E15 creates new opportunities to access data on the web. Beyond pages, many web applications provide data through REST based web services. Using data from various sources, E15 can mash disconnected web accessible information and visualize it in the three dimensional window. Users can take advantage of Python libraries that already exist for many popular web services."
  h = textbox('slide_5_textb', text, 512, self.x - 256/400.0*x_offset - .4*z_offset, self.y - .25, self.z - 256/400.0*z_offset + .4*x_offset, self.rx, self.ry, self.rz)

slides[5].draw = instancemethod(slide_5, slides[5], Slide)


"""
*******************************************************************************
Slide 6: Platform
*******************************************************************************
"""
def slide_6(self):
  # font properties
  fontsize = 48
  font("ApexNew-Bold", fontsize)
  fontcolor(230/255.0, 20/255.0, 120/255.0, 0.95)
  
  # geometry change
  x_offset = cos(self.ry*pi/180.0)
  z_offset = -sin(self.ry*pi/180.0)
  
  # dummy frame
  elem_begin(1024, 512, self.key_element)
  elem_pos(self.x + .5*z_offset, self.y - 256/800.0, self.z - .5*x_offset)
  elem_xform(self.rx, self.ry, self.rz)
  #background(1, 1, 1, 0.5)
  elem_end()
  
  text = "6. Platform"
  h = textbox('slide_6_texta', text, 512, self.x, self.y, self.z, self.rx, self.ry, self.rz)
  
  imgload(Presentation.RESOURCE_URL + '6_inspector.png', 'slide_6_0', self.x + .4*x_offset - .2*z_offset, self.y - .3, self.z + .4*z_offset + .2*x_offset, self.rx, self.ry + 10, self.rz)
  
  # font properties
  fontsize = 32
  font("ApexNew-Book", fontsize, lineheight=fontsize+6.0)
  fontcolor(.9, .9, .8, .95)
  text = "E15 can take full advantage of PyObjC. By bridging Python to the Cocoa Framework, users can create applications on top of E15."
  h = textbox('slide_6_textb', text, 512, self.x + 512/400.0*x_offset, self.y - .1, self.z  + 512/400.0*z_offset, self.rx, self.ry, self.rz)

slides[6].draw = instancemethod(slide_6, slides[6], Slide)


"""
*******************************************************************************
Slide 7: Presentation
*******************************************************************************
"""
def slide_7(self):
  # font properties
  fontsize = 48
  font("ApexNew-Bold", fontsize)
  fontcolor(230/255.0, 20/255.0, 120/255.0, 0.95)
  
  # geometry change
  x_offset = cos(self.ry*pi/180.0)
  z_offset = -sin(self.ry*pi/180.0)
  
  # dummy frame
  elem_begin(1024, 512, self.key_element)
  elem_pos(self.x + .5*z_offset, self.y - 256/800.0, self.z - .5*x_offset)
  elem_xform(self.rx, self.ry, self.rz)
  #background(1, 1, 1, 0.5)
  elem_end()
  
  text = "7. Presentation"
  h = textbox('slide_7_texta', text, 512, self.x, self.y, self.z, self.rx, self.ry, self.rz)
  
  imgload(Presentation.DEFAULT_IMAGE, 'slide_7_0', self.x - .3*z_offset, self.y - .5, self.z + .3*x_offset, self.rx, self.ry + 10, self.rz)
  
  # font properties
  fontsize = 32
  font("ApexNew-Book", fontsize, lineheight=fontsize+6.0)
  fontcolor(.9, .9, .8, .95)
  text = "As seen in this demo script, E15 can function as a presentation software as well. All materials in this presentation is web accessible, meaning anyone with access to E15 can run this script to view the presentation anywhere."
  h = textbox('slide_7_textb', text, 512, self.x + 532/400.0*x_offset - .4*z_offset, self.y - .2, self.z + 532/400.0*z_offset + .4*x_offset, self.rx, self.ry, self.rz)
  
  fontsize = 24
  font("ApexNew-Bold", fontsize, lineheight=fontsize+6.0)
  fontcolor(.9, .9, .8, .95)
  text = "For more information, please visit:\nhttp://e15.media.mit.edu"
  h = textbox('slide_7_textc', text, 512, self.x + 532/400.0*x_offset - .4*z_offset, self.y - .2 - h[1]/400.0, self.z + 532/400.0*z_offset + .4*x_offset, self.rx, self.ry, self.rz)

slides[7].draw = instancemethod(slide_7, slides[7], Slide)


"""
-------------------------------------------------------------------------------

Begin presentation by creating Presentation object

"""
presentation = Presentation(slides, False)


"""
-------------------------------------------------------------------------------

Define MouseEvents

"""
def onRight():
  global presentation
  presentation.next()

def onLeft():
  global presentation
  presentation.prev()

def onHit(e_id):
  print(e_id)
  camera_goto(e_id)
  

  
  
  

glisten(1)
start = 1


def myrand():
  if random() < 0.5: 
    return random()
  else:
    return -random() 

def callphp(s, length):
  #The parameters we send to the php file.
  pdict = {"username":"curiouslee", "tag":"gigantor", "count":str(length), "page":str(s)}
  print "Calling web service."
  #Send our request to the remote php file, and get a callback full of data on completion.
  rservice("http://buza.mitplw.com/gspeak/index.php", pdict, "myCallback")

  rid()

def rid():
  elem_moveto("slide_5_textb", -10, 0, -150)
  elem_moveto("slide_5_fb", 0, 10, -150)
  elem_moveto("slide_5_wp", 0, 20, 100)
  elem_moveto("slide_5_buza", 50, 0, 100)
  elem_moveto("slide_5_black", 0, 90, 100)
  elem_moveto("slide_5_kate", 0, 0, -200)
  elem_moveto("slide_5_mud", 0, 0, -150)


zz = 0
zzzz = 0
ids = []

#This gets called when we get our data. This will always be a dictionary, but may only have keys, no values.
def myCallback(dat):
  global zz
  global start
  global zzzz
  print "callback!", dat
  global ids
  fnames =[]
  idnames = []
  opos = []
  dpos = []
  ot = []
  dt = []
  owh = []
  dwh = []
  x = 10
  y = 0
  zzz = 0

  print slides[5].x, slides[5].y, slides[5].z
  browse("http://www.wired.com", "sdf", slides[5].x, slides[5].y, slides[5].z + 0.1)
  
  for imgid in dat.keys():
    print "ID:", imgid
    ids.append(imgid)
    zzz = zzz + 0.0001
    imgurl = dat[imgid] 
    fnames.append(imgurl)
    idnames.append(imgid)
    opos.append([myrand()*60,myrand()*40, myrand()*70])
    dpos.append([slides[5].x + x,slides[5].y - y, slides[5].z + random() + idx])
    ot.append([0,0,0])
    dt.append([slides[5].rx,slides[5].ry,slides[5].rz])
    owh.append([0,0])
    dwh.append([80,80])
    zzzz = zzzz + 1
    x = x + .6
    if x > 5:
      x = 0
      y = y + .6
      
  zz -= 1
  imgloada(fnames, idnames, opos, dpos, ot, dt, owh, dwh, 1)

  if -zz < 1:
    callback("callphp("+str(-zz)+", 40)", 1)


idx = 1

def onDown():
  global idx
  callphp(idx, 20)
  idx = idx + 1

def onShake():
  print "shake!"

def onSelect(e):
  dp = dpos(e)
  elem_moveto(e, dp[0], dp[1], dp[2]+0.2) 

  

#
#  Newspapers.py
#  E15
#
#  Created by Kate Hollenbach on 3/11/08.
#  Copyright (c) 2008 __MyCompanyName__. All rights reserved.
#

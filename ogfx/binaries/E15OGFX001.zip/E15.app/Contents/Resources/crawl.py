#
#  crawl.py
#  E15
#
#  Created by buza on 11/9/07.
#  Copyright (c) 2007 MITPLW. All rights reserved.
#


from staticwriter import *
i = 0
pageurl = "http://plw.media.mit.edu/people/buza/"
foo = weburls(pageurl)
load(pageurl, "foobase", 0, 0, i, -15, 0, 0)
for url in foo:
  if url.startswith(pageurl):
    if url.endswith("php") or url.endswith("/") or url.endswith("html"):
      print "LOADING", "==============", url
      i -= 2
      load(url, "foo"+str(i), 0, 0, i, -15, 0, 0)
      
      
browse("http://flickr.com/photo_zoom.gne?id=1552498518&context=set-72157602382146174&size=o")
browse("http://flickr.com/photo_zoom.gne?id=1552519810&context=set-72157602382146174&size=o")
browse("http://flickr.com/photo_zoom.gne?id=1551648387&context=set-72157602382146174&size=o")
browse("http://flickr.com/photo_zoom.gne?id=1552510208&context=set-72157602382146174&size=o")

browse("http://flickr.com/photo_zoom.gne?id=1884212560&size=l")
browse("http://flickr.com/photo_zoom.gne?id=1884212022&size=l")
browse("http://flickr.com/photo_zoom.gne?id=1883388543&size=l")
browse("http://flickr.com/photo_zoom.gne?id=1884213564&context=photostream&size=l")




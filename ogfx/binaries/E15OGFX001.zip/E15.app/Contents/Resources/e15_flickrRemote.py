
#
#  e15_flickrRemote.py
#  E15
#
#  Created by buza on 07/16/08.
#  Copyright 2007 buza. All rights reserved.
#

from staticwriter import *
from random import random

start = 1

def myrand():
  if random() < 0.5: 
    return random()
  else:
    return -random() 

def callphp(s, length):
  #The parameters we send to the php file.
  pdict = {"tag":"cigarette", "count":str(length), "page":str(s)}

  #Send our request to the remote php file, and get a callback full of data on completion.
  rservice("http://buza.mitplw.com/gspeak/flickr.php", pdict, "myCallback")
  


global_elem_speed(0.08)

zz = 0
zzzz = 0
ids = []

#This gets called when we get our data. This will always be a dictionary, but may only have keys, no values.
def myCallback(dat):
  global zz
  global start
  global zzzz
  print "callback!", dat
  global ids
  fnames =[]
  idnames = []
  opos = []
  dpos = []
  ot = []
  dt = []
  owh = []
  dwh = []
  x = 10
  y = 0
  zzz = 0
  for imgid in dat.keys():
    print "ID:", imgid
    ids.append(imgid)
    zzz = zzz + 0.0001
    imgurl = dat[imgid] 
    fnames.append(imgurl)
    idnames.append(imgid)
    opos.append([myrand()*60,myrand()*40, myrand()*70])
    dpos.append([x-6.0,y-5.0,zz + zzz])
    ot.append([0,0,0])
    dt.append([0,0,0])
    owh.append([0,0])
    dwh.append([80,80]).
    zzzz = zzzz + 1
    x = x + .7
    if x > 5:
      x = 0
      y = y + .5
      
  zz -= 1
  imgloada(fnames, idnames, opos, dpos, ot, dt, owh, dwh, 1)
  indsss = 0
  for xablle in idnames:
    animate(xablle, "scale", [.005, 300, 1])
    animate(xablle, "slide", [random()/10.0, 4*myrand(), myrand()*4, myrand()/10.0 + .5])
    animate(xablle, "alpha", [0.005, 1.0])
    indsss = indsss + 1

  if -zz < 1:
    callback("callphp("+str(-zz)+", 40)", 1)

callphp(1, 30)

callphp(2, 30)

  
def onHit(e):
  print e
  #headsup(e)
  camera_goto(e, -.3, .3, 0)
  pdict = {"id":e}
  rservice("http://buza.mitplw.com/gspeak/phototags.php", pdict, "foo")


def onShake():
  print "shake!"

def onSelect(e):
  print e


def foo(e):
  print "hello tags", e
#
#  Pulse.py
#  E15
#
#  Created by blackaller + buza on 7/28/07.
#  Copyright (c) 2007 MITPLW. All rights reserved.
# 

from drawengine import *
from math import *

#Size of the texture
size = 512

tsize(size)

#history(300,0.0001)

k = 4
a = 0

def draw():
	global k, a
	#push()
	#translate(256,256)
	for i in range(1024/(k*2)):
		for j in range(1024/(k*2)):
			col = ((i*i*a+j*j*a)*a  % 255)/255.0
			color(col, col, col, 0.5)
			rect(i*k,j*k,k,k)
			rect(-i*k,j*k,k,k)
			rect(i*k,-j*k,k,k)
			rect(-i*k,-j*k,k,k)
	#pop()	
	a = a+.01

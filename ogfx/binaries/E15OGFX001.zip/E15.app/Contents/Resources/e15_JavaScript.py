#
#  e15_JavaScript.py
#  E15
#
#  Created by Takashi Okamoto on 4/9/08.
#  Copyright (c) 2008 PLW. All rights reserved.
#

from staticwriter import *

jscript = """

// --------------------------- NAMESPACING ----------------------------------//
// edu.mit.media.plw.E15
var edu;
if (!edu)
  edu = {};
else if (typeof edu != "object")
  throw new Error("edu already exists and is not an object");

if (!edu.mit)
  edu.mit = {};
else if (typeof edu.mit != "object")
  throw new Error("edu.mit already exists and is not an object");

if (!edu.mit.media)
  edu.mit.media = {};
else if (typeof edu.mit.media != "object")
  throw new Error("edu.mit.media already exists and is not an object");

if (!edu.mit.media.plw)
  edu.mit.media.plw = {};
else if (typeof edu.mit.media.plw != "object")
  throw new Error("edu.mit.media.plw already exists and is not an object");

edu.mit.media.plw.E15 = {
  Version: '1.0',
  
  toggleVisibilityOfTag: function(tag) {
    var a = $$(tag);
    for (var i = 0; i < a.length; i++) {
      switch(a[i].getStyle('visibility')) {
        case 'hidden':
          a[i].setStyle({visibility: 'visible'});
          break;
        default:
          a[i].setStyle({visibility: 'hidden'});
          break;
      }
    }
  },
  
  toggleVisibilityOfTags: function(tags) {
    tags.each(function(tag) {
      edu.mit.media.plw.E15.toggleVisibilityOfTag(tag);
    });
  },
  
  toggleImages: function() {
    edu.mit.media.plw.E15.toggleVisibilityOfTags(['img', 'object', 'iframe', '[type="image"]']);
  },
  
  greekText: function(parentElement) {
    edu.mit.media.plw.E15.extractTextNodesAndReplaceWith(parentElement.childNodes, '_');
  },
  
  clearText: function(parentElement) {
    edu.mit.media.plw.E15.extractTextNodesAndReplaceWith(parentElement.childNodes, '\u00A0');
  },
  
  extractTextNodesAndReplaceWith: function(nodes, replaceString) {
    var n = new Array();
    for (var i = 0, l = nodes.length; i < l; ++i) {
      if (nodes[i].nodeType == 3) {
        var s = nodes[i].nodeValue.replace(/\S/gi, replaceString);
        nodes[i].replaceData(0, s.length, s);
        n.push(nodes[i]);
      }
      if (nodes[i].childNodes.length > 0) {
        var ns = edu.mit.media.plw.E15.extractTextNodesAndReplaceWith(nodes[i].childNodes, replaceString);
        if (ns.length > 0)
          n.push(ns);
      }
    }
    return n;
  },
  
  printAllNodeTypes: function() {
    var a = $$('*');
    var b = new Array();
    for (var i = 0; i < a.length; i++) {
      if (a[i].childNodes.length == 0) {
        if (a[i].nodeName != 'IMG' && a[i].nodeName != 'IFRAME') {
          a[i].setStyle({visibility: 'hidden'});
          b.push(a[i].nodeName);
        }
      }
    }
    return b;
  }
}

function setMasthead() {
  var masthead = $('NYTLogo');
  if (masthead) {
    $('NYTLogo').src = "http://localhost/nytimes.gif";
  }
  var wideSpan = $('wideSpan');
  var aColumn = wideSpan.down().down();

    var headline = aColumn.down();
    var story = aColumn.down(2);

    var byline = story.down();
    var storySummary = story.down('p.summary');



    headline.down().update("The Pope Chanllenge President; To Arm Wrestling");
    var bylineText = "By TAKASHI OKAMOTO " + '<span class="timestamp">' + "53 minutes ago" + "</span>";
    byline.update(bylineText);
    storySummary.update("Pope Benedict XVI began a six-day visit to the United States after a flight during which he made his most extensive remarks about declaring his challenge to the President.");
}

"""

# This turns off the automatic loading of web page textures.
autopageload(0)

#The routine stuff.
def onHit(e):
  camera_goto(e)

#jscriptrun(jscript, "edu.mit.media.plw.E15.toggleVisibilityOfTags(['img', 'object', 'iframe', '[type=\"image\"]'])")
#jscriptrun(jscript, "edu.mit.media.plw.E15.clearText(document.body)")
#jscriptrun(jscript, "edu.mit.media.plw.E15.toggleImages()")
#jscriptrun(jscript, "setMasthead()")
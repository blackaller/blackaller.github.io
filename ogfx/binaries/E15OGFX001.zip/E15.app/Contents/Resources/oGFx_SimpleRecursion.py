#
#  SimpleRecursion.py
#  E15
#
#  simple recursion example
#  Created by  blackaller on 13/11/07.
#  Copyright (c) 2007 MITPLW. All rights reserved.

from drawengine import *
from math import *

#Size of the texture
size = 512

tsize(size)

a=0
def draw():
	background(1,1,1,0)
	stroke(1,1,1,0)
	ring(0,0,512,5)

def ring(x,y,radius,step):
	global a
	if step>1:
		step=step-1
		push()	
		
		translate(x/2,y/2)	
		rect(0,0,radius/2,radius/2)
		beginline()
		line(radius*cos(a),radius*sin(a))
		line(radius*sin(a),radius*cos(a))
		line(radius*cos(pi/2+a),-radius*sin(a))
		line(-radius*sin(a),radius*cos(pi/2+a/2))

		

		# try this
		#line(radius*cos(a*a),radius*sin(a))
		#line(radius*sin(a),radius*cos(a*a))
		#line(radius*cos(a*a),-radius*sin(a))
		#line(-radius*sin(a),-radius*cos(a*a))	
		endline()
		stroke(1,1,0,0.5)
		#color(1,1,0,0.2)

		push()	
		ring(radius,0,radius/2,step)
		pop()
		
		stroke(1,0,1,0.5)
		color(1,0,1,0.2)

		push()	
		ring(radius,radius,radius/2,step)
		pop()

		stroke(0,1,1,0.5)
		color(0,1,1,0.1)

		push()	
		ring(0,radius,radius/2,step)
		pop()

		stroke(1,1,1,0.5)
		#color(0,1,1,0.1)

		push()	
		ring(0,0,radius/2,step)
		pop()

		radius=radius/2
		
		pop()
		a=a+0.0001
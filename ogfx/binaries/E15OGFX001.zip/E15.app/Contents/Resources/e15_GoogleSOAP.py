#
#  e15_GoogleSOAP.py
#  E15
#
#  Created by Kate Hollenbach on 2/12/08.
#  Copyright (c) 2008 MITPLW. All rights reserved.
#
from staticwriter import *
from SOAPpy import WSDL
import os

search_terms = ['barack obama', 'hillary clinton', 'john edwards', 'mitt romney', 'john mccain', 'mike huckabee', 'ron paul']
#search_terms = ['barack obama']
#search_terms = ['physical language workshop']
url_results = {}
raw_results = {}

# get the wsdl file from google at: http://api.google.com/GoogleSearch.wsdl
# and adjust local path accordingly
# TIP: when you save the file, make sure you select "all files" not some xml format.
# otherwise, this won't work, for some reason or another, and I already wasted time
# figuring that out so you shouldn't have to. yay!
WSDL_FILE = '/Users/kjhollen/Desktop/GoogleSearch.wsdl'
API_KEY = 'GAm68NRQFHJ23LrylU1iqjY9b69M7LE1' # Kyle's Google SOAP API key


# define a search term / result set
class SearchResult:
    
    def __init__(self, term, results, x, y, z):
      self.position(x, y, z)
      self.term = term
      self.results = results
    
    def position(self, x, y, z):
      self.x, self.y, self.z = (x, y, z)
      
    def draw(self):
      # draw search term
      fontsize = 16.0
      font("Helvetica", fontsize)
      fontcolor(.25, .95, .8, 0.95)
      textbox(self.term, self.term, 256, self.x, self.y, self.z-.8, 0, -45, 0, flush=1.0)
      
      
      font("Helvetica", fontsize - 6.0)
      fontcolor(.375, .7, .9, 0.95)
      # draw search results
      y_offset = -0.2
      for result in self.results:
        fontcolor(.375, .7, .9, 0.95)
        textbox(result.URL.encode('utf-8'), result.URL.encode('utf-8'), 256, self.x, self.y + y_offset, self.z-.8, 0, -45, 0, flush=1.0)
        fontcolor(.96, .94, .09, 0.95)
        textbox(result.summary.encode('utf-8'), result.summary.encode('utf-8'), 256, self.x, self.y + y_offset - .1, self.z-.8, 0, -45, 0, flush=1.0)
        y_offset -= 0.2

server = WSDL.Proxy(WSDL_FILE)


x, y, z = (0.0, 0.0, 0.0)
for term in search_terms:
  results = server.doGoogleSearch(
        API_KEY, term, 0, 10, False, "", False, "", "utf-8", "utf-8")
  #raw_results[term] = results
  raw_results[term] = SearchResult(term, results.resultElements, x, y, z)
  x += 2
  z += 0.01

for key in raw_results.keys():
  raw_results[key].draw()
    
def onHit(e_id):
  print(e_id)
  url = e_id
  browse(url, url, 0, 0, 0, 0, 0, 0)
#x, y, z = (0.0, 0.0, 0.0)
#for term in search_terms:
#  x = 0
#  for result in raw_results[term].resultElements:
#    url = result.URL.encode('utf-8')
#    print url
#    load(url, url, x, y, z, 0, 0, 0)
#    x += 2
#    z += 0.01
#  y += 2


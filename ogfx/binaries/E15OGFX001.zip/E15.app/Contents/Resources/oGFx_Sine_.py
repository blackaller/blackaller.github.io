#
#  Sine.py
#  E15
#
#  Created by  blackaller on 8/8/07.
#  Copyright (c) 2007 MITPLW. All rights reserved.
#  Simple example of the moveto line function
# 


from drawengine import *
from math import *

a=0
b=0

tsize(512)

def draw():
	global a,b
	background(1,1,1,0)
	linewidth(10)
	stroke(1,0,0,1)
	for i in range(50):
		stroke(i%2,0,(i+1)%2,0.5)
		moveto(i*10,i*10*b)
		beginline()
		line(i*10*b,512-i*10)
		line(512-i*10,512-i*10*b)
		line(512-i*10*b,i*10)
		closeline()
	a = a+0.1
	b = sin(a)
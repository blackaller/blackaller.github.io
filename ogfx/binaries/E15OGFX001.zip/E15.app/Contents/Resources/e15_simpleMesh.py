#
#  e15_simpleMesh.py
#  E15
#
#  Created by Kate Hollenbach on 3/21/08.
#  Copyright (c) 2008 MIT PLW. All rights reserved.
#

from staticwriter import *

URL_PREFIX = 'http://e15.media.mit.edu/_E15'

vertices = [0.0, 0.0, 0.0, 1.0, 0.0, 0.5, 0.0, -1.0, 0.5, 1.0, -1.0, 0.0, 2.0, 0.0, 0.0, 2.0, -1.0, 0.5]
normals = [0.0, 0.0, 1.0, 0.0, 0.0, 1.0, 0.0, 0.0, 1.0, 0.0, 0.0, 1.0, 0.0, 0.0, 1.0, 0.0, 0.0, 1.0]
textureCoords = [0.0, 0.0, 100.0, 0.0, 0.0, 100.0, 100.0, 100.0, 200.0, 0.0, 200.0, 100.0]
indices = [0, 1, 2, 1, 2, 3, 1, 3, 4, 3, 4, 5]
x, y, z = (0.0, 0.0, 0.0)

mesh("http://web.mit.edu/kjhollen/www/splash-top.jpg", "MESH", x, y, z, vertices, normals, textureCoords, indices)

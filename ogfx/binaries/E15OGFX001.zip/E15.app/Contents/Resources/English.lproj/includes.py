from drawengine import *
from inspect import *
from random import *
from math import *

import weakref, inspect

class Redirect:
	def __init__(self, stdout):
		self.stdout = stdout
	def write(self, s):
		capture(s)

sys.stderr = Redirect(sys.stdout)
sys.stdout = Redirect(sys.stdout)

def myrand():
  if random() < 0.5: 
    return random()
  else:
    return -random() 
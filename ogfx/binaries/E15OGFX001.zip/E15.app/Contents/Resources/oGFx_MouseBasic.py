#
#  MouseBasics.py
#  OpenGFX
#
#  Created by blackaller on 10/24/07.
#  Copyright (c) 2007 MITPLW. All rights reserved.
#

from drawengine import *

history(1,0.001)
#Size of the texture
size = 512

tsize(size)

mx = 0
my = 0

mouse()

def draw():
	global mx, my
	background(1,1,1,0.5)
	print(mx,my)
	ellipse(mx,my,20,20)
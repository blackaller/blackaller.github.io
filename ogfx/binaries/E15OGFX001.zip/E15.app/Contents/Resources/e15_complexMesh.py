#
#  e15_complexMesh.py
#  E15
#
#  Create a mesh from a .obj file. obj file loading code adapted from Pygame example: 
#  http://www.pygame.org/wiki/OBJFileLoader?parent=CookBook
#
#  Created by Kate Hollenbach on 4/10/08.
#  Copyright (c) 2008 MIT PLW. All rights reserved.
#

from staticwriter import *
#from numpy import *
import array
import urllib



URL_PREFIX = "http://e15.media.mit.edu/_E15/mesh/"  # <- where we'll get the files and images from.
FILE_NAME = "newspaper.obj"                         # <- rectangular mesh that's been deformed, like a piece of paper.
LOCAL_FILE = "/tmp/" + FILE_NAME                    # <- where we'll cache the file locally

# Read the file from the web and cache it locally.
remotefile = urllib.urlopen(URL_PREFIX + "newspaper.obj")
localfile = open(LOCAL_FILE, 'w')
localfile.write(remotefile.read())
remotefile.close()
localfile.close()

print "Downloaded Mesh"

# Class for representing an OBJ file in memory,
# in a form that is easily passed to the E15 mesh function.
# NOTE(kjhollen): this implementation is incomplete, as it does not 
# handle materials (it ignores them).
class OBJ:
    def __init__(self, filename, swapyz=False, xTextureScale=1, yTextureScale=1, scaleFactor = 1.0):
        """
        Loads a Wavefront OBJ file. 
        
        The OBJ file contains arrays of vertices, vertex normals, and vertex texture coordinates
        (and possibly some other information, which is ignored in this implementation).
        
        Elements are placed into the arrays in the order they are read from the file,
        and referenced by indices starting from 1.
        """
        
        # temporary variables to hold info as it is read from the file.
        vertices = []               # an array of vertex coordinates (as x, y, z tuples), as they are read from the file
        normals = []                # an array of normal coordinates (as x, y, z tuples), as they are read from the file
        texcoords = []              # an array of texture coordinates (as s, t tuples), as they are read from the file.
        faces = []                  # an array of tuples, where each tuple contains integer indices into the vertices array,
                                    # defining a face. indices start from 0.
        normalMap = { }             # map vertex index -> normal index.
        texCoordMap = { }      # map vertex index -> texture coordinate index.
        numFaceVertices = 0    # the number of vertices in faces so far.

 
        # Parsing the Obj file.
        for line in open(filename, "r"):
            # Skip comments.
            if line.startswith('#'): continue
            # Skip empty lines.
            values = line.split()
            if not values: continue
            
            # Handle vertex coordinate:
            # Line format for vertices is:
            #   v x y z
            # where x, y, and z are the coordinates as floats.
            if values[0] == 'v':
                v = map(float, values[1:4])
                if swapyz:
                    v = v[0], v[2], v[1]
                vertices.append(v)
                
            # Handle vertex normal coordinates:
            # Line format for vertex normals is:
            #   vn x y z
            # where x, y, and z are the coordinates as floats.
            elif values[0] == 'vn':
                v = map(float, values[1:4])
                if swapyz:
                    v = v[0], v[2], v[1]
                normals.append(v)
                
            # Handle texture coordinates:
            # NOTE(kjhollen): assumes 2D textures.
            # Line format for vertex texture coordinates is:
            #   vt s t
            # where s, t are the coordinates as floats, valued between 0.0 and 1.0
            elif values[0] == 'vt':
                texcoords.append(map(float, values[1:3]))
                
            # NO MATERIAL SUPPORT IN E15 MESHES YET.
            #elif values[0] in ('usemtl', 'usemat'):
            #    material = values[1]
            #elif values[0] == 'mtllib':
            #    self.mtl = MTL(values[1])
            # Handle faces:
            # Line format for faces varies, as do the number of vertices in each line.
            #   f v v v ...                     integer indices into the vertex array that compose one face.
            #   f v/vt v/vt v/vt ...            integer indices into the vertex/texture coordinate array
            #   f v/vt/vn v/vt/vn v/vt/vn ...   integer indices into the vertex/texture coordinate/normal array.
            elif values[0] == 'f':
                face = []
                #texcoords = []
                #norms = []
                # we're counting the number of face vertices.
                # if a line has 3 vertices, it's a triangle, so we add 3 vertices to the mesh.
                if (len(values) == 4):
                    numFaceVertices += 3
                # if a line has 4 vertices, it's a quad, which we divide into 2 triangles,
                # thus adding 6 vertices to the mesh.
                elif(len(values) == 5):
                    numFaceVertices += 6
                # iterate over the faces:
                for v in values[1:]:
                    w = v.split('/')
                    # record the vertex index -- convert to python index by subtracting 1, so it starts from 0.
                    face.append(int(w[0]) - 1)
                    # record the python index of the texture coordinate for this vertex
                    if len(w) >= 2 and len(w[1]) > 0:
                        #texcoords.append(int(w[1]))
                        texCoordMap[int(w[0]) - 1] = int(w[1]) - 1
                    #else:
                    #    texcoords.append(0)
                    # record the python index of the normal coordinate for this vertex
                    if len(w) >= 3 and len(w[2]) > 0:
                    #    norms.append(int(w[2]))
                        normalMap[int(w[0]) - 1] = int(w[2]) - 1
                    #else:
                    #    norms.append(0)
                #self.faces.append((face, norms, texcoords, material))
                #print face
                faces.append(face)

        # pre-allocate a bunch of arrays that we will copy the values into.
        # uses the python array module, though we could also use plain arrays,
        # or anything else that is a python Sequence type.
        # these are flat arrays -- ie: the first vertex is in vertexArray[0:3]
        self.vertexArray = array.array('f', range(len(vertices) * 3))           # 3 values for each vertex (x, y, z)
        self.normalArray = array.array('f', range(len(vertices) * 3))           # 3 values for each normal (x, y, z), 1 normal for each vertex.
        self.textureCoordArray = array.array('f', range(len(texcoords) * 2))    # each texture coordinate is in 2d.
        self.faceArray = array.array('I', range(numFaceVertices))               # we counted the # of vertices before.
        
        # set the values for the vertices, normals, and texture coordinates.
        for i in range(len(vertices)):
            v = vertices[i]
            self.vertexArray[i * 3] = v[0] * scaleFactor
            self.vertexArray[i * 3 + 1] = v[1] * scaleFactor
            self.vertexArray[i * 3 + 2] = v[2] *scaleFactor
            
            n = normals[normalMap[i]]
            self.normalArray[i * 3] = n[0]
            self.normalArray[i * 3 + 1] = n[1]
            self.normalArray[i * 3 + 2] = n[2]
            
            t = texcoords[texCoordMap[i]]
            self.textureCoordArray[i * 2] = t[0] * xTextureScale        # scale for NPOT textures.
            self.textureCoordArray[i * 2 + 1] = t[1] * yTextureScale    #
        # define the polygons/faces. NOTE(kjhollen) this only works if ALL the polygons in the file are triangles or quads
        # in particular, the quads are hard coded in this example to consist of 2 triangles, the first with indices 0 1 2 and
        # the second with indices 0 2 3
        fi = 0
        for f in range(len(faces)):
            face = faces[f]
            if (len(face) == 3):
            #print face
                # if it's a triangle, just record the indices that compose that triangle
                self.faceArray[fi] = face[0]
                self.faceArray[fi + 1] = face[1]
                self.faceArray[fi + 2] = face[2]
                fi += 3
            elif (len(face) == 4):
                # if it's a quad, break it down into 2 triangles.
                # this is probably dependent on MODO's implementation.
                self.faceArray[fi] = face[0]
                self.faceArray[fi + 1] = face[1]
                self.faceArray[fi + 2] = face[2]
                self.faceArray[fi + 3] = face[0]
                self.faceArray[fi + 4] = face[2]
                self.faceArray[fi + 5] = face[3]
                fi += 6

# load the mesh -- and shrink it down a little.
scaleValues = [(800.0, 1350.0), (990.0, 3208.0), (1025.0, 2025.0), (993.0, 2428.0), (974.0, 3125.0)]

meshObj = OBJ(LOCAL_FILE, xTextureScale = 820, yTextureScale = 175, scaleFactor = 0.5)
print "Created Mesh"

# set up the lighting
lightenable()

# set a position and direction in scene coordinates
lightposition(0,0,35,1,"scene")
lightdirection(0,0,-1,1)

# or, set relative to the camera
#lightposition(0,0,5,1,"camera")
#lightdirection(0,0,-1,1)

# light material parameters
lightdiffuse(1,1,1,1)
lightspecular(1,1,1,1)
lightambient(0,0,0,1)

# geometry material parameters
materialdiffuse(1,1,0.9,1)
materialspecular(1,1,1,1)
materialambient(1,1,1,1)
materialshine(25) # Luis says this one ranges from 0 to 128

# for testing:
#mesh("http://web.mit.edu/kjhollen/www/splash-top.jpg" , "MESH", x, y, z, meshObj.vertexArray, meshObj.normalArray, meshObj.textureCoordArray, meshObj.faceArray)

x, y, z = (0.0, 0.0, 0.0)
# Render some news sites.
for i in range(5):
    xscale, yscale = scaleValues[i]
    meshObj = OBJ(LOCAL_FILE, xTextureScale = xscale, yTextureScale = yscale, scaleFactor = 0.5)
    mesh(URL_PREFIX + "news" + str(i+1) + ".png" , "MESH", x, y, z, meshObj.vertexArray, meshObj.normalArray, meshObj.textureCoordArray, meshObj.faceArray)
    x += 1.0
    z += 5.0

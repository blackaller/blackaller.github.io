#
#  Balls.py
#  OpenGFX
#
#  Created by buza on 10/24/07.
#  Copyright (c) 2007 MITPLW. All rights reserved.
#
from drawengine import *

sv1 = 0
sv2 = 0
sv3 = 0
sv4 = 0
sv5 = 0
sv6 = 0
mx = 0
my = 0

numBalls = 50
balls = []

#Size of the texture
size = 256

tsize(size)

class Ball(AutoReloader):
	def __init__(self, xin, yin, din, idin, oin, r, g, b, a):
		self.x = xin
		self.y = yin
		self.diameter = din
		self.id = idin
		self.others = oin
		self.spring = 0.05
		self.gravity = 0.01
		self.vx = 0
		self.vy = 0
		self.r = r
		self.a = a
		self.g = g
		self.b = b
		
	def collide(self):
		i = self.id + 1
		while i < numBalls:
			dx = self.others[i].x - self.x
			dy = self.others[i].y - self.y
			distance = sqrt(dx*dx + dy*dy)
			minDist = self.others[i].diameter/2 + self.diameter/2
			if (distance < minDist):
				angle = atan2(dy, dx)
				targetX = self.x + cos(angle) * minDist
				targetY = self.y + sin(angle) * minDist
				ax = (targetX - self.others[i].x) * self.spring
				ay = (targetY - self.others[i].y) * self.spring
				self.vx -= ax
				self.vy -= ay
				self.others[i].vx += ax
				self.others[i].vy += ay
			i = i + 1

	def move(self):
		self.vy += self.gravity
		self.x += self.vx
		self.y += self.vy
		if (self.x  >  size - self.diameter):
			self.x = size - self.diameter
			self.vx *= -0.9
		elif (self.x  < 0):
			self.x = 0
			self.vx *= -0.9
		
		if (self.y  > size - self.diameter):
			self.y = size - self.diameter
			self.vy *= -0.9 
		elif (self.y  < 0):
			self.y = 0
			self.vy *= -0.9
     
	def display(self):
		color(self.r, self.g, self.b, self.a)
		rect(self.x, self.y, self.diameter, self.diameter)

		
for i in range(numBalls):
	balls.append(Ball(random()*size, random()*size, randrange(size/16, size/8), i, balls, random(), random(), random(), random()+0.7))

a=0

def draw():
	global balls, numBalls, sv1, sv2, sv3, sv4, sv5, sv6, a
	stroke(0,0,0,1)
	for i in range(numBalls):
		balls[i].gravity=sin(a)
		balls[i].collide()
		balls[i].move()
		balls[i].display()
	a+=0.01

def onRight():
  print "Drawing the past 100 animation frames..."
  history(100, 0.05, 0)
  print " To continue, press Right arrow."
  
history(150, 0.05, 0)


# but this is not
kaleidoscope("mykaleidoscope", { "center" : [128. 128] })
gaussianblur("myblur", {"radius" : 3.0})
removeFilter("mykaleidoscope")



kaleidoscope("mykaleidoscope", {"center" : [150, 150]})
gaussianblur("myblur", {"radius" : 5.0})
filterParams("mykaleidoscope", {"center" : [50, 50]})
removeFilter("myblur")

root.dotscreen("width", 2)  

fragshadercode = """
const float C_PI    = 3.1415;
const float C_2PI   = 2.0 * C_PI;
const float C_2PI_I = 1.0 / (2.0 * C_PI);
const float C_PI_2  = C_PI / 2.0;

varying float LightIntensity;

uniform float StartRad;
uniform vec2 Freq;
uniform vec2 Amplitude;

uniform sampler2D WobbleTex;

void main (void)
{
    vec2  perturb;
    float rad;
    vec4  color;a

    // Compute a perturbation factor for the x-direction
    rad = (gl_TexCoord[0].s + gl_TexCoord[0].t - 1.0 + StartRad) * Freq.x;

    // Wrap to -2.0*PI, 2*PI
    rad = rad * C_2PI_I;
    rad = fract(rad);
    rad = rad * C_2PI;

    // Center in -PI, PI
    if (rad >  C_PI) rad = rad - C_2PI;
    if (rad < -C_PI) rad = rad + C_2PI;

    // Center in -PI/2, PI/2
    if (rad >  C_PI_2) rad =  C_PI - rad;
    if (rad < -C_PI_2) rad = -C_PI - rad;

    perturb.x  = (rad - (rad * rad * rad / 6.0)) * Amplitude.x;

    // Now compute a perturbation factor for the y-direction
    rad = (gl_TexCoord[0].s - gl_TexCoord[0].t + StartRad) * Freq.y;

    // Wrap to -2*PI, 2*PI
    rad = rad * C_2PI_I;
    rad = fract(rad);
    rad = rad * C_2PI;

    // Center in -PI, PI
    if (rad >  C_PI) rad = rad - C_2PI;
    if (rad < -C_PI) rad = rad + C_2PI;

    // Center in -PI/2, PI/2
    if (rad >  C_PI_2) rad =  C_PI - rad;
    if (rad < -C_PI_2) rad = -C_PI - rad;

    perturb.y  = (rad - (rad * rad * rad / 6.0)) * Amplitude.y;

    color = texture2D(WobbleTex, perturb + gl_TexCoord[0].st);

    gl_FragColor = vec4(color.rgb * LightIntensity, color.a);
}
"""

vertshadercode = """
varying float LightIntensity;
uniform vec3 LightPosition;

const float specularContribution = 0.1;
const float diffuseContribution  = 1.0 - specularContribution;

void main(void)
{
    vec3 ecPosition = vec3 (gl_ModelViewMatrix * gl_Vertex);
    vec3 tnorm      = normalize(gl_NormalMatrix * gl_Normal);
    vec3 lightVec   = normalize(LightPosition - ecPosition);
    vec3 reflectVec = reflect(-lightVec, tnorm);
    vec3 viewVec    = normalize(-ecPosition);

    float spec      = clamp(dot(reflectVec, viewVec), 0.0, 1.0);
    spec            = pow(spec, 16.0);

	gl_FrontColor	= gl_Color;
    gl_TexCoord[0]  = gl_MultiTexCoord0;
    gl_Position     = ftransform();
    LightIntensity  = diffuseContribution * max(dot(lightVec, tnorm), 0.0)
                      + specularContribution * spec;
}
"""


#First, make the shader program.
make_program("kernel_program")

#Now, make a shader. We can make any number of shaders that we'll ultimately
# attach to the shader program.
make_shader("kernel_program", "vk_shader", "vertex", vertshadercode)
make_shader("kernel_program", "fg_shader", "fragment", fragshadercode)


#Now that the shader has been created, attach it to the program, and attach
# the program to a DisplayableObject, specified by ID.
attach_program("demo", "kernel_program")

shader_param("kernel_program", "fg_shader", "Freq", [4.0, 4.0])
shader_param("kernel_program", "fg_shader", "Amplitude", [.05, .05])
shader_param("kernel_program", "vk_shader", "LightPosition", [0.0, 0.0, 4.0])

#for x in range(800):
shader_param("kernel_program", "fg_shader", "StartRad", [float(x)/100.0])

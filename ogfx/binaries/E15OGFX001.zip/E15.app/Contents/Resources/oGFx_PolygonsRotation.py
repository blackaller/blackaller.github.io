#
#  PolygonsRotation.py
#  OpenGFX
#
#  Created by blackaller on 10/24/07.
#  Copyright (c) 2007 MITPLW. All rights reserved.


from drawengine import *
from math import *

#Size of the texture
size = 512

tsize(size)



class Polygon:
	def __init__(self, numVertices, radius):
		self.n = numVertices
		self.r = radius		
		
	def displayPolygon(self):
		moveto(self.r,0)
		beginline()
		for i in range(self.n):
			line(self.r * cos((i*2*pi)/self.n), self.r * sin((i*2*pi)/self.n))
		closeline()

a=0

def draw():
	global size, a, b 
	color(1,1,1,0.0)
	stroke(1,1,1,0.2)
	linewidth(4)
	push()
	translate(size/2,size/2)
	for i in range(10):
		push()
		if (i % 2) == 0:
			rotate(a*(i+1)/2)
		else:
			rotate(-a*(i+1)/2)
		p= Polygon(i+3,(i+1)*15)
		p.displayPolygon()
		
		pop()
	pop()
	a=a+0.003
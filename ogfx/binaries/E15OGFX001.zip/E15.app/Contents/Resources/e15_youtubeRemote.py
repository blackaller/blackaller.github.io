#
#  e15_youtubeRemote.py
#  E15
#
#  Created by buza on 07/16/08.
#  Copyright 2007 buza. All rights reserved.
#

from staticwriter import *
from random import random

start = 1

def myrand():
  if random() < 0.5: 
    return random()
  else:
    return -random() 

def callphp(s, length):
  global start 
  #The parameters we send to the php file.
  pdict = {"tag":"ass", "start":str(start), "numresults":str(length)}

  #Send our request to the remote php file, and get a callback full of data on completion.
  rservice("http://buza.mitplw.com/gspeak/yt.php", pdict, "myCallback")
  start = start + length

global_elem_speed(0.08)

zz = 0

#This gets called when we get our data. This will always be a dictionary, but may only have keys, no values.
def myCallback(dat):
  global zz
  global start
  print "callback!"
  
  fnames =[]
  idnames = []
  darray = []
  opos = []
  dpos = []
  ot = []
  dt = []
  owh = []
  dwh = []
  x = 0
  y = 0
  zzz = 0
  if start < 500:
    callback("callphp(1, 20)", 1)

  if dat == None:
    return
  for iurl in dat.keys():
    zzz = zzz + 0.0001
    fnames.append(iurl)
    idnames.append(dat[iurl])
    darray.append(str(zz))
    opos.append([myrand()*60,myrand()*40, myrand()*70])
    dpos.append([x-6.0,y-5.0,zz + zzz])
    ot.append([0,0,0])
    dt.append([0,0,0])
    owh.append([0,0])
    dwh.append([80,80])
    x = x + .4
    if x > 5:
      x = 0
      y = y + .6
      
  zz -= 1
  imgloada(fnames, idnames, opos, dpos, ot, dt, owh, dwh, 1)
  
  ixx = 0
  for xablle in idnames:
    animate(str(plo), "alpha", [0.005, .9])
    animate(str(plo), "scale", [.5, 200, 1])
    animate(str(plo), "slide", [50, myrand()*2, -random()*3 - 2, -random()*5 - 1])
    ixx = ixx + 1

callphp(1, 20)
  
def onHit(e):
  camera_goto(e, -.3, .3, 0)


def onShake():
  print "shake!"

def onSelect(e):
  print e
  
def onSelect(e_id):
    pos = []
    rot = []
    dp = dpos(e_id)
    for x in range(1):
      pos.append([dp[0], dp[1], dp[2] + 1])
      rot.append([0, 0, 0])


    print "Loading ", e_id+"_X"
    loadmovie(e_id+"_X", idDict[e_id].gp)
    startmovie(e_id+"_X", pos, rot)

    pos = []
    rot = []
    for x in range(1):
      pos.append([dp[0], dp[1], dp[2] + 2 + random()])
      rot.append([0, 0, 0])

    moviepos(e_id+"_X", pos, rot)
    
    
{'Entertainment': ''}
{'Music': ''}
{'Comedy': ''}
{'Film': ''}
{'Autos': ''}
{'Music': ''}
{'Travel': ''}
{'Music': ''}
{'Music': ''}
{'People': ''}
{'Film': ''}
{'Comedy': ''}
{'Music': ''}
{'Comedy': ''}
{'Entertainment': ''}
{'Comedy': ''}
{'Film': ''}
{'Sports': ''}
{'Music': ''}
{'Comedy': ''}


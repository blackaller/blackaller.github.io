#
#  googlesearch.py
#  E15
#
#  Created by buza on 11/1/07.
#  Copyright (c) 2007 MITPLW. All rights reserved.
#

import google
from staticwriter import *

google.LICENSE_KEY = 'GAm68NRQFHJ23LrylU1iqjY9b69M7LE1'
data = google.doGoogleSearch('link:http://www.mmonoplayer.com')

for i in range(len(data.results)):
  load(data.results[i].URL, "foo"+str(i), i+2.0, 0, i+2.0, 0, -35, 0)
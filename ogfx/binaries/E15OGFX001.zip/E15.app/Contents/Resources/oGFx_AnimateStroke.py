#
#  AnimateStroke.py
#  OpenGFX
#
#  Created by blackaller on 10/24/07.
#  Copyright (c) 2007 MITPLW. All rights reserved.
#


from drawengine import *

sv1 = 0
sv2 = 0
sv3 = 0
sv4 = 0
sv5 = 0
sv6 = 0
mx = 0
my = 0

numBalls = 50
balls = []

#Size of the texture
size = 512

tsize(size)

class Ball(AutoReloader):
	def __init__(self, xin, yin, din, idin, oin, r, g, b, a):
		self.x = xin
		self.y = yin
		self.diameter = din
		self.id = idin
		self.others = oin
		self.spring = 0.05
		self.gravity = 0.03
		self.vx = 0
		self.vy = 0
		self.r = r
		self.a = a
		self.g = g
		self.b = b
		
	def collide(self):
		i = self.id + 1
		while i < numBalls:
			dx = self.others[i].x - self.x
			dy = self.others[i].y - self.y
			distance = sqrt(dx*dx + dy*dy)
			minDist = self.others[i].diameter/2 + self.diameter/2
			if (distance < minDist):
				angle = atan2(dy, dx)
				targetX = self.x + cos(angle) * minDist
				targetY = self.y + sin(angle) * minDist
				ax = (targetX - self.others[i].x) * self.spring
				ay = (targetY - self.others[i].y) * self.spring
				self.vx -= ax
				self.vy -= ay
				self.others[i].vx += ax
				self.others[i].vy += ay
			i = i + 1

	def move(self):
		self.vy += self.gravity
		self.x += self.vx
		self.y += self.vy
		if (self.x  >  size - self.diameter):
			self.x = size - self.diameter
			self.vx *= -0.9
		elif (self.x  < 0):
			self.x = 0
			self.vx *= -0.9
		
		if (self.y  > size - self.diameter):
			self.y = size - self.diameter
			self.vy *= -0.9 
		elif (self.y  < 0):
			self.y = 0
			self.vy *= -0.9
     
	def display(self):
		color(self.r, self.g, self.b, self.a)
		rect(self.x, self.y, self.diameter, self.diameter)

		
for i in range(numBalls):
	balls.append(Ball(random()*size, random()*size, randrange(size/64, size/16), i, balls, random(), random(), random(), random()+0.7))

history(10,0.1)
blendmode(0,8)

a = 0

def draw():
	global balls, numBalls, sv1, sv2, sv3, sv4, sv5, sv6, a
	stroke(0,0.7,0.7,0.6)
	linejoin(2)
	linewidth(2 + 16*abs(sin(a)))
	
	for i in range(numBalls):
		#balls[i].gravity=sin(a)
		balls[i].collide()
		balls[i].move()
		balls[i].display()
	a+=0.01
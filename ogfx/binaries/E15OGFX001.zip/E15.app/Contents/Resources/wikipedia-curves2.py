#
#  wikipedia-curves.py
#  script that gets a series of images from a list of wikipedia pages.
#  E15
#
#  Created by Kate Hollenbach on 10/2/07.
#  Copyright (c) 2007 mit media lab plw. All rights reserved.
#

import urllib
import simplejson
from staticwriter import *
from math import *
from numpy import polyfit

RESULT_FORMAT = 'json'
PAGE_LIMIT = 20

rootPage = "List of curves"

def get_title(e):
  return e['title']

# -----------------------------------------------------------------------
# WIKIPEDIA QUERY MAKING
# -----------------------------------------------------------------------

# for constructing queries to wikipedia
# lang is the language (en for english)
# params are the parameters for the query, in a dictionary
# 
def format_wikipedia_query(lang, params):
  url = "http://%(lang)s.wikipedia.org/w/api.php?action=query&%(params)s" % \
    { 'lang' : lang, 'params' : params}
  return url.encode('utf8') # need to encode escaped characters ...

# format an array of strings as an argument to the query
# -- for a query on pages "Cat" and "Dog" the title argument should be
#    "Cat|Dog". 
# arg_array is an array of arguments (strings) to be formatted in this way.
def wikipedia_format_multiple(arg_array):
  return "|".join(arg_array)

# returns JSON from running the query at the specified url
def run_query(query_url):
  socket = urllib.urlopen(query_url)
  json = simplejson.loads(socket.read())
  socket.close()
  return json

# -----------------------------------------------------------------------
# GET ALL IMAGES FROM A "LIST" OF PAGES
# -----------------------------------------------------------------------

# get all pages linked to from url

# parameters -- title of list page, data to fetch (prop), and result format
query_params = urllib.urlencode( {
  'titles' : rootPage,
  'prop' : 'links',
  'format' : RESULT_FORMAT
} )

url = format_wikipedia_query('en', query_params)
json = run_query(url)

# get all images linked from those pages
pages = json['query']['pages']
# iterate over pages by key, because the property names in json are page id's
# it's actually just one page, but we don't know what the id is, so we have to
# do it this way.
for key in pages.keys():
  page = pages[key] 
  
  # get names of all pages linked to from this page, and format them for a query url
  titles_raw = wikipedia_format_multiple(map(get_title, page['links']))
  query_params = urllib.urlencode( {
    'titles' : titles_raw.encode('utf8'),
    'prop': 'images',
    'format' : RESULT_FORMAT    
  } )
  
  # run query to get images on all the pages
  url = format_wikipedia_query('en', query_params) 
  json = run_query(url)
  
  linked_pages = json['query']['pages'] # get all the pages
  
  # keep set of image titles (just need each title once -- we'll use this as a list
  # of images to fetch url data for)
  image_titles = set()

  # for each linked page, get extract which images are on that page.
  for lkey in linked_pages.keys():
    linked_page = linked_pages[lkey]
    # if there actually were images on that page, append their titles to our list of titles.
    if linked_page.has_key('images') and get_title(linked_page).lower().find("indifference") == -1 and get_title(linked_page).lower().find("semi") == -1:
      titles = map(get_title, linked_page['images'])
      image_titles.update(titles) # add all images
  
  # keep mapping of image name to url
  image_url_dict = {}
  
  # need to stagger these requests because the urls get too long
  SUBSET_SIZE = 25
  image_subset = []
  
  # send requests for subsets of the total image list until there are
  # no images left to request
  while len(image_titles) > 0:
  
    # pick an arbitrary title to remove from the set
    t = image_titles.pop();
    image_subset.append(t) 

    # if we have enough titles or this is the last run of the loop, make a request.
    if len(image_titles) == 0 or len(image_subset) > SUBSET_SIZE:

      # format a subset of the image urls 
      image_title_subset = wikipedia_format_multiple(image_subset)
      
      #ok now get the image urls -- set up a query to do so.
      query_params = urllib.urlencode( {
        'titles' : image_title_subset.encode('utf8'),
        'prop' : 'imageinfo',
        'format' : RESULT_FORMAT,
        'iiprop' : 'url' # force it to return the image url as part of the image info
      } )
      query_url = format_wikipedia_query('en', query_params)
      q = run_query(query_url)
      #print q
      ii_json = q['query']['pages'] # get query results and strip off container objects

      for iikey in ii_json.keys():
        image_info = ii_json[iikey]
        if (image_info.has_key('imageinfo')): # there's only image info if the image actually still exists.
          image_url_dict[image_info['title']] = image_info['imageinfo'][0]['url']
      image_subset = [] # clear subset

  #ok, now draw each...
  
  # ---------------
  # RENDERING
  # ---------------
  
  #TODO add delay
  x, y, z = (0, 0, 0)
  xo, yo, zo = (-1, 8, -20)
  a = 4
  i = 0
  div = len(linked_pages)
  
  # render page title -- BIG!
  elem_begin(3000, 300, str(1))
  elem_pos(xo, yo, zo)
  fontcolor(1, 1.0, 0.1, 0.9)
  font("ApexSansBookT", 300.0) #HUGE!
  fontcolor(.5, .81, 1.0, 0.9)
  elem_xform(0, 0, -90) # vertical text
  text(rootPage, 0, 300)
  elem_end()
  
  
  xvec = []
  yvec = []
  slopes = []
  num_points = len(linked_pages.keys())
  a = 4
  for i in range(num_points):
    theta = 2.0 * pi * i / num_points
    r = a * sin(4.0 * theta)
    x = r * cos(theta) + xo
    y = r * sin(theta) + yo
    xvec += [x]
    yvec += [y]
    
  # calculate the tangents
  ws = 3 # window size
  for i in range(num_points):
    s = max(0, i - ws)
    e = min(i + ws, num_points)
    m, b = polyfit(xvec[s:e], yvec[s:e], 1) #1st order polynomial
    slopes += [m]
  
  i = 0
  for lkey in linked_pages.keys():
    a = 4
    linked_page = linked_pages[lkey]
    page_title = linked_page['title'].encode('utf8')
    
    #theta = 2.0 * pi * i / div

    #r = a * sin(4.0 * theta)
    x = xvec[i]
    y = yvec[i]
    z = i/2.0 + zo

    
    # render the page title
    elem_begin(1000, 200, page_title)
    elem_pos(x, y, z)
    font("ApexSansBookT", 50.0)
    fontcolor(.5, .81, 1.0, 0.9)
    elem_xform(0, -45, 0)
    text(page_title, 0, 50)
    elem_end()
        
    f = .2 # fudge factor for 300 pixels
    # render the images that go with it
    if linked_page.has_key('images'):
      images = linked_page['images']
      x_inc = slopes[i] * f
      y_inc = 1/slopes[i] *f
      for image in images:
        a += 0.5
        #print image
        #r = a * sin(4.0 * theta)
        x += x_inc
        y += y_inc
        #z = i/2.0 + zo
        image_title = get_title(image)
        #print t.encode('utf8')
        if (image_url_dict.has_key(image_title.encode('utf8'))):
          image_url = image_url_dict[image_title]
          # can't do svg yet -- save ourselves the trouble of fetching them.
          # also, don't render icon that appears next to "this article is a geometry stub"
          #print image_url
          if (not image_url.endswith("svg") and not image_title == "Image:Dodecahedron.jpg" and not image_title == ""):
            imgload(image_url.encode('utf8'), str(image_title), x, y, z, 0, -35, 0, 300, 300)
          z -= 0.1
    i += 1
    if (i > PAGE_LIMIT):
        break
    
def onHit(e):
    url = "http://en.wikipedia.org/wiki/" + urllib.quote(e)
    print url
    browse(url, url, 0, 0, 0, 0, 0, 0)

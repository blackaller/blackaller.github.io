#
#  oGFx_vertigoSequence.py
#  OpenGFX
#
#  Created by blackaller+buza on 12/01/08.
#  Copyright (c) 2007 MITPLW. All rights reserved.
#  

from drawengine import *
from math import *
#Size of the texture
size = 256

tsize(size)


#setup globals
a=0
b=0
c=250
width=256
height=256
radiusX=0
radiusY=0
period=7



# filters
#root.gaussianblur("radius",10)
#root.colorcontrols("saturation",20)
#root.edges("intensity",6)
#root.pixellate("scale",6)

# filter removals
#root.removeFilter("gaussianblur", lambda: del_gaussianblur())
#root.removeFilter("colorcontrols", lambda: del_colorcontrols())
#root.removeFilter("edges", lambda: del_edges())
#root.removeFilter("pixellate", lambda: del_pixellate())

blendmode(0,2)
envcolor(1,1,1)

numCircles = 1

colorExterior = [0,1,1,1]
colorMiddle = [1,0,1,1]
colorInterior = [1,1,0,1]

def draw():
	global numCircles
	#lightdirection(20*cos(a/10),20*sin(a/10),60,1)
	global a,b,c, width, height, radiusX, radiusY, period
	background(1,1,1,0)
	linewidth(5)
	stroke(0,0,1,0.3)
	radiusX=5+abs(10*sin(c))
	radiusY=5+abs(10*sin(c))
	
	# custom function calls
	for i in range(numCircles):
		radiusX=i+5+abs(10*sin(c))
		radiusY=i+5+abs(10*sin(c))
		display (width+(200*sin((a))),height+(200*sin((b))))
		display (width+(200*sin((a+pi/ period*i))),height+(200*sin((b+pi/ period*i))))
		display (width+(200*sin(-(a+2*pi/ period*i))),height+(200*sin((b+2*pi/ period*i))))
		display (width+(200*sin((-a))),height+(200*sin((-b))))
		display (width+(200*sin(-(a+pi/ period*i))),height+(200*sin(-(b+pi/ period*i))))
		display (width+(200*sin((a+2*pi/ period*i))),height+(200*sin(-(b+2*pi/ period*i))))
	a=a+0.1
	b=b+0.15
	c=c+0.025
	period=sin(period/2) + period/2 +0.01

# custom function definition
# custom function definition
def display(x,y):	
	push()
	translate(x/2,y/2)
	color(colorExterior[0],colorExterior[1],colorExterior[2],colorExterior[3])
	ellipse(-1.5 * radiusX,-1.5 * radiusY, 3 * radiusX, 3 * radiusY)
	color(colorMiddle[0],colorMiddle[1],colorMiddle[2],colorMiddle[3])
	ellipse(-radiusX,-radiusY, 2 * radiusX, 2 * radiusY)
	color(colorInterior[0],colorInterior[1],colorInterior[2],colorInterior[3])
	ellipse(0.5*-radiusX,0.5*-radiusY, radiusX, radiusY)
	pop()
	
state = 0

doArray = []
doArray.append(lambda : doStep1())
doArray.append(lambda : doStep2())
doArray.append(lambda : doStep3())
doArray.append(lambda : doStep4())
doArray.append(lambda : doStep5())
doArray.append(lambda : doStep6())
doArray.append(lambda : doStep7())
doArray.append(lambda : doStep8())
doArray.append(lambda : doStep9())
doArray.append(lambda : doStep10())

undoArray = []
undoArray.append(lambda : undoStep1())
undoArray.append(lambda : undoStep2())
undoArray.append(lambda : undoStep3())
undoArray.append(lambda : undoStep4())
undoArray.append(lambda : undoStep5())
undoArray.append(lambda : undoStep6())
undoArray.append(lambda : undoStep7())
undoArray.append(lambda : undoStep8())
undoArray.append(lambda : undoStep9())
undoArray.append(lambda : undoStep10())

print "Use the left & right arrow keys to step through this animation sequence of spinning discs.\n"

def onRight():
  global state, doArray
  if state == 10:
    print "Nothing happens after Step 10."
    return
  func = doArray[state]
  state = state + 1 % 10
  func()

def onLeft():
  global state, undoArray
  if state == 0:
    print "Nothing happens before Step 1."
    return
  func = undoArray[state-1]
  state = state - 1 % 10
  if state < 0:
    state = 0
  func()

def doStep1():
  print "Doing Step 1 :: Adding more circles to the animation."
  global numCircles
  numCircles = 5

def undoStep1():
  print "Undoing Step 1 :: Removing additional circles."
  global numCircles
  numCircles = 1

def doStep2():
  print "Doing Step 2 :: Applying this history command of 200 frames and incremental rotation."
  history(150, 0.05, 1.0)

def undoStep2():
  print "Undoing Step 2 :: Removing the history command. Displaying only one animation frame."
  history(1, 0.05, 0)

def doStep3():
  #Angle the camera to see perspective.
  print "Doing Step 3 :: Changing the perspective. Note you can also use the scroll wheel and holding down the cmd key to navigate the scene."
  #camera(-1.0, 0.0, -1.0, 7.0, 0.0, 1.0)
  camera(-1.0, 0.0, -1.0, 6.3849544525146484, 0.0, 0.054950624704360962)

def undoStep3():
  #Straighten out the camera.
  print "Undoing Step 3 :: Resetting the perspective."
  camera(0.0, 0.0, -1.0, 0.0, 0.0, 1.8)

def doStep4():
  print "Doing Step 4 :: Applying a Gaussian blur filter."
  root.gaussianblur("radius",10)

def undoStep4():
  print "Undoing Step 4 :: Removing the Gaussian blur filter."
  root.removeFilter("gaussianblur", lambda: del_gaussianblur())

def doStep5():
  print "Doing Step 5 :: Applying a saturation effect."
  root.colorcontrols("saturation",20)

def undoStep5():
  print "Undoing Step 5 :: Removing the saturation effect."
  root.removeFilter("colorcontrols", lambda: del_colorcontrols())

def doStep6():
  print "Doing Step 6 :: Setting the background color to black."
  envcolor(0, 0, 0)

def undoStep6():
  print "Undoing Step 6 :: Setting the background color to white."
  envcolor(1, 1, 1)
	
#def doStep7():
  #print "Doing Step 7 :: Applying an edge filter."
  #root.edges("intensity",6)

#def undoStep7():
  #print "Undoing Step 7 :: Removing the edge filter."
  #root.removeFilter("edges", lambda: del_edges())

def doStep7():
  print "Doing Step 7 :: Changing the blending."
  #camera(0.0, 0.0, -1.0, 0.0, 0.0, 1.8)
  camera(0.0, 0.0, -1.0, 0.0, 0.0, -3.8) # going in
  blendmode(3,0)

def undoStep7():
  print "Undoing Step 7 :: Reverting the blending."
  camera(-1.0, 0.0, -1.0, 6.3849544525146484, 0.0, 0.054950624704360962)
  blendmode(0,2)

def doStep8():
  print "Doing Step 8 :: Applying an edge and edgeworks combo filter."
  root.edgework("radius", 8)
  root.edges("intensity",6)
  #camera(-1.0, 0.0, -1.0, 7.0, 0.0, -1.0) # closer
  camera(-2.0, 0.0, -2.0, 4.1494903564453125, 0.0, -2.0644171237945557) # closer

def undoStep8():
  print "Undoing Step 8 :: Removing the edge and edgeworks filter."
  root.removeFilter("edges", lambda: del_edges())
  root.removeFilter("edgework", lambda: del_edgework())
  camera(0.0, 0.0, -1.0, 0.0, 0.0, -3.8)

def doStep9():
  print "Doing Step 9 :: Reverting the blending."
  blendmode(0,2)

def undoStep9():
  print "Undoing Step 9 :: Changing back to  custom blending."
  blendmode(3,0)

def doStep10():
  print "Doing Step 10 :: Back to origin."
  undoStep9()
  undoStep8()
  undoStep7()
  undoStep5()
  undoStep4()
  undoStep3()
  undoStep2()


def undoStep10():
  print "Undoing Step 10 :: Back to 10."
  doStep2()
  doStep3()
  doStep4()
  doStep5()
  doStep7()
  doStep8()
  doStep9()

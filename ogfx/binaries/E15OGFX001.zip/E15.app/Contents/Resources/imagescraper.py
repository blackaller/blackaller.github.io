#
#  imagescraper.py
#  E15
#
#  Created by buza on 3/29/08.
#  Copyright (c) 2007-2008 MITPLW. All rights reserved.
#

# This script displays images scraped from web pages randomly.
# Usage: Load a page into the webview, and evaluate this script.
# Works particularly well going fullscreen on pages from http://ffffound.com

from staticwriter import *
from random import random
import math

#glisten(1)

def myrand():
  if random() < 0.5: 
    return random()
  else:
    return -random() 

#This turns off the automatic loading of web page textures.
autopageload(1)

#The routine stuff.
def onHit(e):
  camera_goto(e)
  
envcolor(1, 1, 1)

#This is the javascript we want to run in the webview.
# This simply gets all DOM img tags, and returns an array of the "src" attributes
# for those tags.
jscript = """
function pyeval() {
    l = document.getElementsByTagName("img")
    var myArray = [];
    for (var i = 0; i < l.length; i++)
        myArray[i] = l[i].src;
    
    return myArray;
}
"""

#This function gives the javascript to the webview.
imagelist = jscripteval(jscript, "pyeval", [])
id = 0
#Get the images, and load them into E15.
for img in imagelist:
    #imgload(img, img, 3.5+myrand(), myrand(), myrand(), 0, random()*360, 0)
    id = id + 1
    imgload(str(id), img, 1+myrand(), myrand(), myrand(), 0, random()*360, 0)
    animate(str(id), "scale", [1, 300, 1])
    animate(str(id), "slide", [random()/10.0, 4*myrand(), myrand()*4, myrand()/100.0 + .5])
    animate(str(id), "alpha", [0.005, 1.0])
    
def onSelect(e):
  print e


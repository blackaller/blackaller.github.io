#
#  Polylines.py
#  OpenGFX
#
#  Created by blackaller on 10/24/07.
#  Copyright (c) 2007 MITPLW. All rights reserved.


from drawengine import *

size = 512

tsize(size)

class Point2D:
	def __init__(self, px, py):
		self.x = px
		self.y = py

def draw():
	background(1,1,1,0.5)
	linewidth(10)
	push()
	translate(100,100)
	color(0,0,1,0.5)
	stroke(1,1,1,0.8)
	polyline ([Point2D(0,0), Point2D(0,256), Point2D(256,256), Point2D(256,0)])
	translate(100,100)
	color(1,0,0,0.5)
	stroke(0,0,0,0.8)
	polygon ([Point2D(0,0), Point2D(0,256), Point2D(256,256), Point2D(256,0)])
	pop()

def polyline(doodle):
	moveto(doodle[0].x, doodle[0].y)
	beginline()
	if len(doodle) > 0:
		for p2D in doodle:	
			line(p2D.x, p2D.y)
	endline()
	
def polygon(doodle):
	moveto(doodle[0].x, doodle[0].y)
	beginline()
	if len(doodle) > 0:
		for p2D in doodle:	
			line(p2D.x, p2D.y)
	closeline()
#
#  e15_light_basics.py
#  E15
#
#  Created by Luis Blackaller on 4/14/08.
#  Modified by Kate Hollenbach on 4/17/08 to reflect API changes.
#  Copyright (c) 2008 MITPLW. All rights reserved.
#

# use this commands to specify light parameters on a scene.

from staticwriter import *

# set up the lighting
lightenable()
#lightdisable() #turn off lighting

# set a position and direction in scene coordinates
# if we wanted the light located relative to the camera,
# we'd set the laste parameter in lightpostion to "camera"
lightposition(0,0,35,1,"scene")
lightdirection(0,0,-1,1)

# or, set relative to the camera
#lightlock("camera")
# or 
#lightposition(0,0,5,1,"camera")
#lightdirection(0,0,-1,1)

# light material parameters
lightdiffuse(1,1,1,1)
lightspecular(1,1,1,1)
lightambient(0,0,0,1)

# geometry material parameters
materialdiffuse(1,1,0.9,1)
materialspecular(1,1,1,1)
materialambient(1,1,1,1)
materialshine(25) # Luis says this one ranges from 0 to 128


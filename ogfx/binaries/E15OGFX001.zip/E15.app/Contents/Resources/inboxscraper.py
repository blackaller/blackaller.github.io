#
#  inboxscraper.py
#  E15
#
#  Created by buza on 3/29/08.
#  Copyright (c) 2007-2008 MITPLW. All rights reserved.
#

# This script further demonstrates the jscripteval functionality through the use of pattern-based callbacks.

from staticwriter import *

#This turns off the automatic loading of web page textures.
autopageload(0)

jscriptload("http://www.prototypejs.org/assets/2008/1/25/prototype-1.6.0.2.js")

#The routine stuff.
def onHit(e):
  camera_goto(e)
  
envcolor(0, 0, 0)

#This is the javascript we want to run in the webview.
# This script searches for all elements with the specified class name,
# and returns an array of the innerHTML from these elements.
jscript = """
function pyeval(s) {
	l = document.getElementsByClassName(s)
    var myArray = [];
    for (var i = 0; i < l.length; i++)
        myArray[i] = l[i].childNodes[0].innerHTML;
    
    return myArray;
}
"""

#for x in displayables():
#  idparam(x, "mapscaler", 2500)

#This call can be interpreted as follows:
# When a web page is visited that contains the pattern "inbox" in the URL (the Facebook inbox, for example),
# evaluate the specified javascript, and pass the results back through the callback function named
# "namecallback". This scrapes the current inbox page, and collects the names of the people that have sent you
# facebook messages. 
jscripteval(jscript, "pyeval", ["name"], "inbox", "namecallback")

names = []
def namecallback(e):
  global names
  names = e

#This function behaves in a way similar to the previous function, but collects the 
# actual message snippet text from the inbox. We can use this to augment the E15 
# facebook layout.
jscripteval(jscript, "pyeval", ["snippet_wrap"], "inbox", "msgheader")

#The message callback. Here, we take each person's image icon that has send me a message,
# make it bigger, and change it's z index. With each subsequent page of messages, users that
# have sent more messages will be farther removed from the general group.
messages = []
def msgscale(e):
  global messages
  messages = e

  for x in names:
    ss =  friend_with_fullname(x)
    if ss == None:
        pass
    else:
      idn = ss.user['uid']
      idparam(str(idn), "mapscaler", 200)
      elem_moveto(str(idn), ss.x, ss.y, ss.z + 15)
      ss.z = ss.z + 15
      
def msgheader(e):
  global messages
  print "hello"
  messages = e
  for i in range(len(messages)):
    ss =  friend_with_fullname(names[i])
    print ss
    if ss == None:
        pass
    else:
      #print messages[i], ss.x, ss.y, ss.z, ss.rx, ss.ry, ss.rz
      idn = ss.user['uid']
      idparam(str(idn), "mapscaler", 500)
      elem_moveto(str(idn), ss.x, ss.y, ss.z + 1.1)
      ss.z = ss.z + .5
      fontsize = 26.0
      font("Stag", fontsize)
      fontcolor(1, 1, 1, 0.95)
      textbox(names[i], messages[i], 956, ss.x, ss.y, ss.z, ss.rx, ss.ry, ss.rz, flush=1.0)
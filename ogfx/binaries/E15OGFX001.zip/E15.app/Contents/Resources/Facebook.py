#
#  Facebook.py
#  E15
#
#  Created by Takashi Okamoto on 12/08/07.
#  Copyright (c) 2007 PLW. All rights reserved.
#
import os
import sys
import math
from types import NoneType
from staticwriter import *
from facebook import Facebook
from random import random, shuffle
from string import *
from time import sleep
import feedparser
import re

# Facebook Application Keys
# App: MudFeeder
MudFeeder = {
  'api'          : '2bc138324422cfe7490ccfdc22f50824',
  'secret'       : '93abe13f797d3e41592405418015fd26',
  'notification' : 'http://mit.facebook.com/feeds/notifications.php?id=713154&viewer=713154&key=b6d0f0e5d4&format=rss20',
  'POKE_TYPE'    : re.compile("poke"),
  'MESSAGE_TYPE' : re.compile("message"),
  'PHOTO_TYPE'   : re.compile("photo"),
  'FRIEND_TYPE'  : re.compile("friend"),
  'entries'      : [],
  'CAMERA_SPEED' : 40.0,
  'ELEM_SPEED'   : 10.0,
  'CUBE'         : 8
}

SEARCH_FIELDS = ['name', 'pic_square', 'status', 'pic', 'affiliations', 'current_location']


def myrand():
  if random() < 0.5: 
    return random()
  else:
    return -random() 
    
class FacebookUser:
  """
  FacebookUser represents each user in the environment.
  
  ----------------------------------------------------------------------
  
  Class Variables:
  
  DEFAULT_IMAGE
    Url of profile image if none provided by user.
  
  COLORS
    List of colors to be used.
  
  ----------------------------------------------------------------------

  Instance Variables:
  
  user
    User object returned by PyFacebook.
    
  x
    Float x position.

  y
    Float y position.
  
  z
    Float z position.

  connections
    Number of networks in common with logged in user.
  
  affiliations
    String of all networks user belongs to.
  
  ----------------------------------------------------------------------
  
  """
  
  DEFAULT_IMAGE = "http://buza.mitplw.com/plw/facebook_default.png"
  print DEFAULT_IMAGE
  COLORS = [[230/255.0, 20/255.0, 120/255.0, 0.95], [20/255.0, 190/255.0, 230/255.0, 0.95], [50/255.0, 230/255.0, 20/255.0, 0.95], [62/255.0, 62/255.0, 62/255.0, 0.95]]
  
  def __init__(self, user):
    self.user = user
    self.x, self.y, self.z = (0, 0, 0)
    self.rx, self.ry, self.rz = (0, 0, 0)
    self.alpha = 1.0
    self.affiliations()
    self.affil_y = 0
    
  def position(self, x, y, z):
    self.x = x
    self.y = y
    self.z = z
    
  def affiliations(self):
    in_common = 0
    if self.user.has_key('affiliations'):
      self.affiliations = ""
      for i in range(len(self.user['affiliations'])):
        for j in range(len(me['affiliations'])):
          if me['affiliations'][j]['nid'] == self.user['affiliations'][i]['nid']:
            in_common += 1
            
        self.affiliations += self.user['affiliations'][i]['name'].encode('utf8') + "\n"
    self.location = ""
    if self.user.has_key('current_location') and type(self.user['current_location']) != NoneType:
      if self.user['current_location'].has_key('city'):
        self.location += capitalize(self.user['current_location']['city'].encode('utf8'))
      if self.user['current_location'].has_key('state'):
        self.location += ", " + upper(self.user['current_location']['state'].encode('utf8'))
      if self.user['current_location'].has_key('country'):
        self.location += " (" + capitalize(self.user['current_location']['country'].encode('utf8')) + ")"
    self.connections = in_common
  
  def draw(self):
    global me
    # draw image
    if self.user['pic']:
      imgload(`self.user['uid']`, self.user['pic'], 0, 0, 0, self.rx, self.ry, self.rz)
      animate(`self.user['uid']`, "scale", [1, 300, 1])
      animate(`self.user['uid']`, "slide", [random()/10.0, 6*myrand(), myrand()*4, myrand()/100.0])
      animate(`self.user['uid']`, "alpha", [0.005, 1.0])
    else:
      imgload(`self.user['uid']`, FacebookUser.DEFAULT_IMAGE, 0, 0, 0, self.rx, self.ry, self.rz)
      animate(`self.user['uid']`, "scale", [1, 300, 1])
      animate(`self.user['uid']`, "slide", [random()/10.0, 6*myrand(), myrand()*4, myrand()/100.0])
      animate(`self.user['uid']`, "alpha", [0.005, 1.0])
    """
    # draw name
    width, height = (256, 256)
    fontsize = 16.0
    font("Stag-Bold", fontsize)
    if self.connections == 0:
      fontcolor(FacebookUser.COLORS[2][0], FacebookUser.COLORS[2][1], FacebookUser.COLORS[2][2], FacebookUser.COLORS[2][3])
    elif self.connections == 1:
      fontcolor(FacebookUser.COLORS[1][0], FacebookUser.COLORS[1][1], FacebookUser.COLORS[1][2], FacebookUser.COLORS[1][3])
    else:
      fontcolor(FacebookUser.COLORS[0][0], FacebookUser.COLORS[0][1], FacebookUser.COLORS[0][2], FacebookUser.COLORS[0][3])
    
    h = textbox(`self.user['uid']`+"_details", self.user['name'].encode('utf8'), width, self.x, self.y, self.z-.7, self.rx, self.ry-90, self.rz, flush=1.0)
    # draw networks
    if self.affiliations:
      fontcolor(FacebookUser.COLORS[3][0], FacebookUser.COLORS[3][1], FacebookUser.COLORS[3][2], FacebookUser.COLORS[3][3])
      fontsize = 12.0
      font("Stag-Bold", fontsize)
      self.affil_y = h[1]/400.0
      textbox(`self.user['uid']`+"_affiliations", self.affiliations, width, self.x, self.y - self.affil_y, self.z-.701, self.rx, self.ry-90, self.rz, flush=1.0)
    """
    
  def moveto(self, x, y, z):
    global albums
    self.position(x, y, z)
    elem_moveto(`self.user['uid']`, x, y, z)
    elem_moveto(`self.user['uid']`+"_details", x, y, z-.7)
    if self.affiliations:
        elem_moveto(`self.user['uid']`+"_affiliations", x, y - self.affil_y, z-.71)
    for album in albums:
      if album.uid == self.user['uid']:
        album.moveto(x, y, z)
  
  def set_alpha(self, alpha):
    if alpha > 1.0:
      alpha = 1.0
    elif alpha < 0.0:
      alpha = 0.0
    self.alpha = alpha
    elem_alpha(`self.user['uid']`, self.alpha)


class FacebookAlbum:
  """Facebook Album Object, represent group of FacebookPhotos for FacebookUser."""
  def __init__(self, uid, x, y, z):
    self.uid = uid
    self.position(x, y, z)
    self.photos = []
    
  def get_photos(self):
    """Grabs photos from FB. Call sparingly."""
    photos = facebook.photos.get(self.uid)
    self.photos = []
    for photo in photos:
      self.photos.append(FacebookPhoto(photo, self))
      
  def position(self, x, y, z):
    self.x, self.y, self.z = (x, y, z)
  
  def draw(self):
    offset_x, offset_y, offset_z = (256/400.0, -256/400.0, 0)
    for i in range(len(self.photos)):
      j = i+1
      self.photos[i].position(self.x+j%5*offset_x, self.y+math.floor(j/5.0)*offset_y, self.z+j*offset_z)
      self.photos[i].draw()
  
  def moveto(self, x, y, z):
    self.position(x, y, z)
    for photo in self.photos:
      photo.moveto(self.x, self.y, self.z)
      
class FacebookPhoto:
  """Facebook Photo Object, represents photo from Facebook."""
  def __init__(self, photo, album):
    self.src = photo['src']
    print photo['src']
    self.caption = photo['caption'].encode('utf8')
    
    self.album = album
    self.position(self.album.x+(random()-0.5)*2, self.album.y+(random()-0.5)*2, self.album.z+(random()-0.5)*2)
  
  def position(self, x, y, z):
    self.x, self.y, self.z = (x, y, z)
  
  def draw(self):
    imgload(self.src, self.src, 0,0,0, 0, 0, 0)
    animate(self.src, "scale", [1, 500, 1])
    animate(self.src, "ybounce", [0, -.05, .9])
    animate(self.src, "alpha", [0.005, 1.0])
    if self.caption != "":
      fontsize = 16.0
      font("Stag", fontsize)
      fontcolor(.25, .95, .8, 0.95)
      textbox(self.src + "_details", self.caption, 256, self.x, self.y, self.z-.8, 0, -90, 0, flush=1.0)

  def moveto(self, x, y, z):
    self.position(x, y, z)
    elem_moveto(self.src, self.x, self.y, self.z)
    if self.caption != "":
      elem_moveto(self.src + "_details", self.x, self.y, self.z-.6)


"""
Friend Methods
"""
def get_friends(uid):
  friends = facebook.friends.get()
  if len(friends) > 0:
    return facebook.users.getInfo(friends, SEARCH_FIELDS)
  return []

def friend_with_uid(uid):
  friend = None
  for i in range(len(fbusers)):
    if fbusers[i].user['uid'] == uid:
      friend = fbusers[i]
      break
  return friend

def friend_with_fullname(fullname):
  friend = None
  for f in fbusers:
    if upper(f.user['name'].encode('utf8')) == upper(fullname):
      friend = f
      break
  return friend

def print_friends():
  sort_by_name(fbusers)
  for i in range(len(fbusers)):
    print fbusers[i].user['name'].encode('utf8') + ":" + `fbusers[i].user['uid']` + ":" + `fbusers[i].connections` + ":" + fbusers[i].location + ":" + ';'.join(fbusers[i].affiliations.split("\n"))


def me(uid):
  return facebook.users.getInfo([uid], SEARCH_FIELDS)[0]
  
def spread(radius):
  # move friends
  for i in range(len(fbusers)):
    x, y, z = ((random()-0.5)*radius, (random()-0.5)*radius, (random()-0.5)*radius)
    fbusers[i].moveto(x, y, z)
  # move me
  x, y, z = ((random()-0.5)*radius, (random()-0.5)*radius, (random()-0.5)*radius)
  me_fb.moveto(x, y, z)

def get_notification_entries(limit=100):
  feed = feedparser.parse(MudFeeder['notification'])
  # limit
  if (len(feed.entries) > limit):
    feed.entries = feed.entries[0:limit]
  if len(MudFeeder['entries']) > limit and MudFeeder['entries'][limit]['id'] == feed.entries[0].id:
    return
  MudFeeder['entries'] = []
  for entry in feed.entries:
    # extract who
    uid = re.sub("^.*id=", '', entry.summary_detail.value)
    uid = re.sub("\".*$", '', uid)
    type = ""
    if MudFeeder['POKE_TYPE'].search(entry.summary_detail.value) != None:
      type = "poke"
    elif MudFeeder['MESSAGE_TYPE'].search(entry.summary_detail.value) != None:
      type = "message"
    elif MudFeeder['PHOTO_TYPE'].search(entry.summary_detail.value) != None:
      type = "photo"
    elif MudFeeder['FRIEND_TYPE'].search(entry.summary_detail.value) != None:
      type = "friend"
    if type != "":
      MudFeeder['entries'].append({'id': entry.id, 'uid': uid, 'type': type})
  MudFeeder['entries'].reverse()


"""
Sorting Methods
"""
def sort_by_name(friends):
  friends.sort(lambda x, y: cmp(x.user['name'].encode('utf8').lower(), y.user['name'].encode('utf8').lower()))
  
def sort_by_connections(friends):
  friends.sort(cmp=lambda x, y: x.connections-y.connections, reverse=True)

def sort_by_random(friends):
  shuffle(friends)

def sort_and_draw_by_name():
  x, y, z = (0, 0, 0)
  # sorting by name
  sort_by_name(fbusers)
  for i in range(len(fbusers)):
    fbusers[i].moveto(x, y, z)
    z -= 1

def sort_and_draw_by_random():
  x, y, z = (0, 0, 0)
  # sorting by random
  sort_by_random(fbusers)
  for i in range(len(fbusers)):
    fbusers[i].moveto(x, y, z)
    z -= 1
    
def sort_and_draw_by_name_connections():
  # sorting by name, then number of connections to me
  sort_by_name(fbusers)
  sort_by_connections(fbusers)
  # move me to center
  me_fb.moveto(2, 2, 24)
  for i in range(len(fbusers)):
    x = random()*4
    y = random()*4
    z = fbusers[i].connections*8 + (random()*2 - 1)
    fbusers[i].moveto(x, y, z)


"""
Notification Methods
"""
def notify(notification):
  global fbusers
  friend = friend_with_uid(int(notification['uid']))
  print notification['type'] + ' by ' + `notification['uid']`
  if friend != None:
    x, y, z = set_region(notification['type'])
    # set alpha to 1.0
    friend.set_alpha(1.0)
    # send a callback to return to original location
    callback('move_uid(' + `friend.user['uid']` + ', ' + `friend.x` + ', ' + `friend.y` + ', ' + `friend.z` + ')', 3)
    friend.moveto(x, y, z)

def move_uid(uid, x, y, z):
  global f
  friend = friend_with_uid(int(uid))
  if friend != None:
    friend.moveto(x, y, z)

def set_region(type):
  offset_x = (random()-0.5)*2
  offset_y = (random()-0.5)*2
  offset_z = (random()-0.5)*2
  x, y, z = (0, 0, 0)
  if type == 'poke':
    x, y, z = (10+offset_x, 10+offset_y, 10+offset_z)
  elif type == 'message':
    x, y, z = (-10+offset_x, 10+offset_y, 10+offset_z)
  elif type == 'photo':
    x, y, z = (10+offset_x, -10+offset_y, 10+offset_z)
  elif type == 'friend':
    x, y, z = (-10+offset_x, -10+offset_y, 10+offset_z)
  return (x, y, z)

def notification_update():
  # draw some labels
  fontsize = 150.0
  font("Stag-Bold", fontsize)
  fontcolor(.9, .9, .1, .95)

  elem_begin(1024, 300, 'label_poke')
  elem_pos(10, 10, 7)
  text('POKE', 0, fontsize, flush=0.5)
  elem_end()

  elem_begin(1024, 300, 'label_message')
  elem_pos(-10, 10, 7)
  text('MESSAGE', 0, fontsize, flush=0.5)
  elem_end()

  elem_begin(1024, 300, 'label_photo')
  elem_pos(10, -10, 7)
  text('PHOTO TAG', 0, fontsize, flush=0.5)
  elem_end()

  elem_begin(1024, 300, 'label_friend')
  elem_pos(-10, -10, 7)
  text('NEW FRIEND', 0, fontsize, flush=0.5)
  elem_end()
  
  get_notification_entries()
  count = 0
  for entry in MudFeeder['entries']:
    print entry
    delay = count
    callback('notify({"id": ' + `entry['id']` + ', "uid": ' + `entry['uid']` + ', "type": "' + entry['type'] + '"})', delay)
    count += 1
  # make all elements lose alpha
  fade_friends()

def notification_update2():
  get_notification_entries()
  count = 0
  for entry in MudFeeder['entries']:
    delay = count
    callback('notify({"id": ' + `entry['id']` + ', "uid": ' + `entry['uid']` + ', "type": "' + entry['type'] + '"})', delay)
    count += 1
  # make all elements lose alpha
  pushback_friends()

def move_friends():
  for i in range(len(fbusers)):
    x, y, z = ((random()-.5)*2+fbusers[i].x, (random()-.5)*2+fbusers[i].y, (random()-.5)*2+fbusers[i].z)
    callback('fbusers[' + `i` + '].moveto('+`x`+','+`y`+','+`z`+')', i*0.2)
  callback('move_friends()', i*0.2+2)

def fade_friends():
  for friend in fbusers:
    if friend.alpha > 0:
      friend.set_alpha(friend.alpha - 0.05)
  callback('fade_friends()', 3)

def pushback_friends():
  global fbusers
  for friend in fbusers:
    friend.moveto(friend.x, friend.y, friend.z - random()*0.3)
  callback('pushback_friends()', 3)

def init():
  global me, me_fb, friends, fbusers
  facebook.auth.getSession()

  # me is primary Facebook user (which is YOU!!!)
  me = me(facebook.uid)
  me_fb = FacebookUser(me)
  me_fb.position(0, 0, 1)
  me_fb.draw()

  # lets get friends
  friends = get_friends(facebook.uid)
  for friend in friends:
    fbusers += [FacebookUser(friend)]

  for i in range(len(fbusers)):
    x, y, z = ((random()-0.5)*MudFeeder['CUBE'], (random()-0.5)*MudFeeder['CUBE'], (random()-0.5)*MudFeeder['CUBE'])
    fbusers[i].position(x, y, z)
    fbusers[i].draw()


def load_picture(fullname, x, y, z):
  joanie = friend_with_fullname(fullname)
  joanie.moveto(x, y, z)

  albums.append(FacebookAlbum(joanie.user['uid'], joanie.x, joanie.y, joanie.z))
  albums[0].get_photos()
  albums[0].draw()


# Begin by logging in
if not globals().has_key('facebook'):
  facebook = Facebook(MudFeeder['api'], MudFeeder['secret'])
  facebook.auth.createToken()
  facebook.login()
  
  fbusers = []
  albums = []
  
  """
  Mouse Events
  """
  nav_counter = -1
  def onRight():
    global nav_counter
    nav_counter += 1
    if nav_counter < len(fbusers):
      camera_goto(`fbusers[nav_counter].user['uid']`)
    else:
      nav_counter = 0

  def onLeft():
    global nav_counter
    nav_counter -= 1
    if nav_counter > 0:
      camera_goto(`fbusers[nav_counter].user['uid']`)
    else:
      nav_counter = len(fbusers) - 1

  def onHit(e_id):
    print(e_id)
    camera_goto(e_id)
    url = "http://www.facebook.com/profile.php?id=" + e_id
    browse(url, url, 1, 1, random()*5, 0, 0, 0)
    z = 0
  
  """
  Speeds
  """
  global_camera_speed(1/MudFeeder['CAMERA_SPEED'])
  global_elem_speed(1/MudFeeder['ELEM_SPEED'])

  # Login to the window, then press enter
  console_input("After logging into Facebook, type 'Yes' to continue...", 'Yes')
  init()

def onShake():
  spread(10)
  
elem_begin(200, 300, "demo")
elem_pos(-.2, .1, .5)
background(1, 0, 0, 1)
elem_end()
animate("demo", "alpha", [0.005, .9])
animate("demo", "scale", [.5, 200, 1])
animate("demo", "slide", [50, myrand()*2, -random()*3 - 2, -random()*5 - 1])

# sort_and_draw_by_name()
# spread(10)
# sort_and_draw_by_name_connections()
# load_picture('Joanie Wolkoff', 0, 10, 30)

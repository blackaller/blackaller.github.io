#
#  ogfx_ballSequence.py
#  OpenGFX
#
#  Created by buza+blackaller on 12/01/08.
#  Copyright (c) 2007 MITPLW. All rights reserved.
#

from drawengine import *

sv1 = 0
sv2 = 0
sv3 = 0
sv4 = 0
sv5 = 0
sv6 = 0
mx = 0
my = 0
#include <OpenAL/al.h>

numBalls = 1
balls = []

#Size of the texture
size = 256

tsize(size)

class Ball(AutoReloader):
	def __init__(self, xin, yin, din, idin, oin, r, g, b, a):
		self.x = xin
		self.y = yin
		self.diameter = din
		self.id = idin
		self.others = oin
		self.spring = 0.05
		self.gravity = 0.03
		self.vx = 1.5
		self.vy = 0
		self.r = r
		self.a = a
		self.g = g
		self.b = b
		
	def collide(self):
		i = self.id + 1
		while i < numBalls:
			dx = self.others[i].x - self.x
			dy = self.others[i].y - self.y
			distance = sqrt(dx*dx + dy*dy)
			minDist = self.others[i].diameter/2 + self.diameter/2
			if (distance < minDist):
				angle = atan2(dy, dx)
				targetX = self.x + cos(angle) * minDist
				targetY = self.y + sin(angle) * minDist
				ax = (targetX - self.others[i].x) * self.spring
				ay = (targetY - self.others[i].y) * self.spring
				self.vx -= ax
				self.vy -= ay
				self.others[i].vx += ax
				self.others[i].vy += ay
			i = i + 1

	def move(self):
		self.vy += self.gravity
		self.x += self.vx
		self.y += self.vy
		if (self.x  >  size - self.diameter):
			self.x = size - self.diameter
			self.vx *= -0.9
		elif (self.x  < 0):
			self.x = 0
			self.vx *= -0.9
		
		if (self.y  > size - self.diameter):
			self.y = size - self.diameter
			self.vy *= -0.9 
		elif (self.y  < 0):
			self.y = 0
			self.vy *= -0.9
     
	def display(self):
		color(self.r, self.g, self.b, self.a)
		stroke(self.r/4, self.g/4, self.b/4, self.a/2)
		rect(self.x, self.y, self.diameter, self.diameter)

		
for i in range(numBalls):
	balls.append(Ball(random()*size, random()*size, randrange(size/16, size/8), i, balls, random(), random(), random(), random()+0.7))

balls[0].r = 0.8
balls[0].g = 0.0
balls[0].b = 0.0
balls[0].a = 0.8

a=0
linewidth(4)
blendmode(0,2)
envcolor(0,0,0)

def draw():
	global balls, numBalls, sv1, sv2, sv3, sv4, sv5, sv6, a
	stroke(1,1,1,1)
	for i in range(numBalls):
		balls[i].gravity=sin(a)
		balls[i].collide()
		balls[i].move()
		balls[i].display()
	a+=0.02

state = 0

doArray = []
doArray.append(lambda : doStep1())
doArray.append(lambda : doStep2())
doArray.append(lambda : doStep3())
doArray.append(lambda : doStep4())
doArray.append(lambda : doStep5())
doArray.append(lambda : doStep6())
doArray.append(lambda : doStep7())
doArray.append(lambda : doStep8())

undoArray = []
undoArray.append(lambda : undoStep1())
undoArray.append(lambda : undoStep2())
undoArray.append(lambda : undoStep3())
undoArray.append(lambda : undoStep4())
undoArray.append(lambda : undoStep5())
undoArray.append(lambda : undoStep6())
undoArray.append(lambda : undoStep7())
undoArray.append(lambda : undoStep8())

print "Use the left & right arrow keys to step through this animation sequence of a simple bouncing ball animation.\n"

def onRight():
  global state, doArray
  if state == 8:
    return
  func = doArray[state]
  state = state + 1
  func()

def onLeft():
  global state, undoArray
  if state == 0:
    return
  func = undoArray[state-1]
  state = state - 1
  if state < 0:
    state = 0
  func()

def doStep1():
  print "Doing Step 1 :: Applying this history command of 100 frames."
  history(150, 0.033, 0)

def undoStep1():
  print "Undoing Step 1 :: Removing the history command. Displaying only one animation frame."
  history(1, 0.05, 0)

def doStep2():
  print "Doing Step 2 :: Adding 4 balls to the animation."
  global numBalls, balls
  numBalls = 5
  for i in range(numBalls):
    balls.append(Ball(random()*size, random()*size, randrange(size/16, size/8), i, balls, random(), random(), random(), random()+0.7))

def undoStep2():
  print "Undoing Step 2 :: Leaving only one ball in the animation."
  global numBalls, balls
  numBalls = 1
  balls = balls[:1]

def doStep3():
  #Angle the camera to see perspective.
  print "Doing Step 3 :: Changing the perspective. Note you can also use the scroll wheel and shift key to navigate the scene."
  #camera(-1.0, 0.0, -1.0, 7.0, 0.0, 1.0)
  camera(-0.80760204792022705, 0.0, -0.58972787857055664, 5.6867275238037109, 0.0, -1.8575317859649658)

def undoStep3():
  #Straighten out the camera.
  print "Undoing Step 3 :: Resetting the perspective."
  camera(0.0, 0.0, -1.0, 0.0, 0.0, 1.8)

def doStep4():
  print "Doing Step 2 :: Adding 20 balls to the animation."
  global numBalls, balls
  numBalls = 25
  for i in range(numBalls):
    balls.append(Ball(random()*size, random()*size, randrange(size/16, size/8), i, balls, random(), random(), random(), random()+0.7))

def undoStep4():
  print "Undoing Step 2 :: Leaving only 10 balls in the animation."
  global numBalls, balls
  numBalls = 5
  balls = balls[:5]

def doStep5():
  print "Doing Step 4 :: Applying a kaleidoscope filter."
  camera(-1.0, 0.0, -1.0, 3.5501196384429932, 0.0, -2.1374876499176025)
  root.kaleidoscope("center", [128, 128])

def undoStep5():
  print "Undoing Step 4 :: Removing the kaleidoscope filter."
  root.removeFilter("kaleidoscope", lambda: del_kaleidoscope())
  camera(-0.80760204792022705, 0.0, -0.58972787857055664, 5.6867275238037109, 0.0, -1.8575317859649658)

def doStep6():
  print "Doing Step 5 :: Applying a Gaussian blur, edges and saturation filters."
  root.gaussianblur("radius", 3)
  root.edges("intensity",8)
  root.colorcontrols("saturation",4)
  camera(-0.53461432456970215, -0.00065044168150052428, -0.84509599208831787, 2.0860831737518311, 0.059564251452684402, -1.2621114253997803)

def undoStep6():
  print "Undoing Step 5 :: Removing the Gaussian blur, edges and saturation filters."
  root.removeFilter("gaussianblur", lambda: del_gaussianblur())
  root.removeFilter("edges", lambda: del_edges())
  root.removeFilter("colorcontrols", lambda: del_colorcontrols())
  camera(-1.0, 0.0, -1.0, 3.5501196384429932, 0.0, -2.1374876499176025)

def doStep7():
  print "Doing Step 6 :: Applying a Pixellation filter."
  root.pixellate("scale",12)

def undoStep7():
  print "Undoing Step 6 :: Removing the Pixellation filter."
  root.removeFilter("pixellate", lambda: del_pixellate())

def doStep8():
  print "Doing Step 10 :: Back to origin."
  undoStep7()
  undoStep6()
  undoStep5()
  undoStep4()
  undoStep3()
  undoStep2()
  undoStep1()

def undoStep8():
  print "Undoing Step 10 :: Back to 10."
  doStep1()
  doStep2()
  doStep3()
  doStep4()
  doStep5()
  doStep6()
  doStep7()

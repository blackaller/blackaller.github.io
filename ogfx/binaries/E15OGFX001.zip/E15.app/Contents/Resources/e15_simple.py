#
#  sipmle.py
#  E15
#
#  Created by buza on 1/20/08.
#  Copyright (c) 2007-2008 MITPLW. All rights reserved.
#

from staticwriter import *
from random import random

def myrand():
  if random() < 0.5: 
    return random()
  else:
    return -random() 

elem_begin(1000, 1000, "demo")
elem_pos(0, 0, 0)
background(0, 0, 1, 0.5)
for i in range(250):
  stroke(random()*0.6, random()*0.5, 0.4, 0.8)
  linewidth(1)
  radius = random()*50
  ellipse(random()*1000, random()*1000, radius, radius)
elem_end()



from staticwriter import *
from random import random

def myrand():
  if random() < 0.5: 
    return random()
  else:
    return -random() 
    
elem_begin(400, 600, "demo")
elem_pos(0, 0, .5)
background(0, 0, 1, 0.5)
elem_end()
animate("demo", "scale", [1, 300, 1])
animate("demo", "slide", [random()/10.0, 4*myrand(), myrand()*4, myrand()/100.0 + .5])
animate("demo", "alpha", [0.005, 1.0])

#=====================================================================
# Evaluate everything above this line before evaluating what is below.
#=====================================================================

shadercode = """
uniform sampler2D tex2D;
uniform vec2 Offset[25];
uniform vec4 scaleFactor;
uniform vec4 kernel[25];

void main()
{
    int i;
    vec4 sum = vec4(0.0);
    for (i=0; i<25; i++) {
        vec4 tmp = texture2D(tex2D, gl_TexCoord[0].st + Offset[i]);
        sum += tmp * kernel[i];
    }
        
    gl_FragColor = sum * scaleFactor;

}
"""

#First, make the shader program.
make_program("kernel_program")

#Now, make a shader. We can make any number of shaders that we'll ultimately
# attach to the shader program.
make_shader("kernel_program", "kernel_shader", "fragment", shadercode)

#Now that the shader has been created, attach it to the program, and attach
# the program to a DisplayableObject, specified by ID.
attach_program("demo", "kernel_program")

#Create the array of texture offsets.
offsetcoords = []

#Generate the texture offsets for a 5x5 kernel. We're using texture coordinates.
for y in range(5):
  for x in range(5):
    offsetcoords.append((x - 2) / 256.0)
    offsetcoords.append((y - 2) / 256.0)

#This is how we update uniforms from Python.
shader_param("kernel_program", "kernel_shader", "Offset", offsetcoords)

#This uniform amplifies the (r, g, b, a) values.
shader_param("kernel_program", "kernel_shader", "scaleFactor", [10.5, 1.5, 1.5, 1.5])

#Create the kernel.
kernel = []

#This produces the Gaussian kernel for a blur effect.  First make the appropriately sized list.
for j in range(100):
  kernel.append(0.0)

#Now fill the list with a Gaussian kernel.
divisor = 331.0

for j in range(4): 
  kernel[j] = kernel[j+80] = kernel[j+16] = kernel[j+96] = 1.0/divisor
for j in range(4): 
  kernel[j+4] = kernel[j+84] = kernel[j+12] = kernel[j+92] = kernel[j+20] = kernel[j+60] = kernel[j+36] = kernel[j+76] = 4.0/divisor
for j in range(4): 
  kernel[j+8] = kernel[j+88] = kernel[j+40] = kernel[j+56] = 7.0/divisor
for j in range(4): 
  kernel[j+24] = kernel[j+64] = kernel[j+32] = kernel[j+72] = 20.0/divisor
for j in range(4): 
  kernel[j+28] = kernel[j+68] = kernel[j+44] = kernel[j+52] = 33.0/divisor
for j in range(4): 
  kernel[j+48] = 55.0/divisor

#Update the kernel uniform.
shader_param("kernel_program", "kernel_shader", "kernel", kernel)
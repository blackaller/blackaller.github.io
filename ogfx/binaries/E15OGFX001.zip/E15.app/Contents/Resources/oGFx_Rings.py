#
#  Rings.py
#  E15
#
#  Created by blackaller on 7/28/07.
#  Copyright (c) 2007 MITPLW. All rights reserved.
# 

from drawengine import *
from math import *

#Size of the texture
size = 512

tsize(size)

blendmode(0,0)

history(200,0.00005)

a=0

def draw():
	push()
	translate(256,256)
	global a
	linewidth(10*cos(a)+20)
	stroke(1,cos(a),sin(a),0.6)
	color(0,0,0,0)
	ellipse(-128*abs(sin(a))-50,-128*abs(sin(a))-50, 256*abs(sin(a))+100,256*abs(sin(a))+100)
	pop()
	a+=0.1
    
fragshadercode = """
const float C_PI    = 3.1415;
const float C_2PI   = 2.0 * C_PI;
const float C_2PI_I = 1.0 / (2.0 * C_PI);
const float C_PI_2  = C_PI / 2.0;

varying float LightIntensity;

uniform float StartRad;
uniform vec2 Freq;
uniform vec2 Amplitude;

uniform sampler2D WobbleTex;

void main (void)
{
    vec2  perturb;
    float rad;
    vec4  color;a

    // Compute a perturbation factor for the x-direction
    rad = (gl_TexCoord[0].s + gl_TexCoord[0].t - 1.0 + StartRad) * Freq.x;

    // Wrap to -2.0*PI, 2*PI
    rad = rad * C_2PI_I;
    rad = fract(rad);
    rad = rad * C_2PI;

    // Center in -PI, PI
    if (rad >  C_PI) rad = rad - C_2PI;
    if (rad < -C_PI) rad = rad + C_2PI;

    // Center in -PI/2, PI/2
    if (rad >  C_PI_2) rad =  C_PI - rad;
    if (rad < -C_PI_2) rad = -C_PI - rad;

    perturb.x  = (rad - (rad * rad * rad / 6.0)) * Amplitude.x;

    // Now compute a perturbation factor for the y-direction
    rad = (gl_TexCoord[0].s - gl_TexCoord[0].t + StartRad) * Freq.y;

    // Wrap to -2*PI, 2*PI
    rad = rad * C_2PI_I;
    rad = fract(rad);
    rad = rad * C_2PI;

    // Center in -PI, PI
    if (rad >  C_PI) rad = rad - C_2PI;
    if (rad < -C_PI) rad = rad + C_2PI;

    // Center in -PI/2, PI/2
    if (rad >  C_PI_2) rad =  C_PI - rad;
    if (rad < -C_PI_2) rad = -C_PI - rad;

    perturb.y  = (rad - (rad * rad * rad / 6.0)) * Amplitude.y;

    color = texture2D(WobbleTex, perturb + gl_TexCoord[0].st);

    gl_FragColor = vec4(color.rgb * LightIntensity, color.a);
}
"""

vertshadercode = """
varying float LightIntensity;
uniform vec3 LightPosition;

const float specularContribution = 0.1;
const float diffuseContribution  = 1.0 - specularContribution;

void main(void)
{
    vec3 ecPosition = vec3 (gl_ModelViewMatrix * gl_Vertex);
    vec3 tnorm      = normalize(gl_NormalMatrix * gl_Normal);
    vec3 lightVec   = normalize(LightPosition - ecPosition);
    vec3 reflectVec = reflect(-lightVec, tnorm);
    vec3 viewVec    = normalize(-ecPosition);

    float spec      = clamp(dot(reflectVec, viewVec), 0.0, 1.0);
    spec            = pow(spec, 16.0);

	gl_FrontColor	= gl_Color;
    gl_TexCoord[0]  = gl_MultiTexCoord0;
    gl_Position     = ftransform();
    LightIntensity  = diffuseContribution * max(dot(lightVec, tnorm), 0.0)
                      + specularContribution * spec;
}
"""


#First, make the shader program.
make_program("kernel_program")

#Now, make a shader. We can make any number of shaders that we'll ultimately
# attach to the shader program.
make_shader("kernel_program", "vk_shader", "vertex", vertshadercode)
make_shader("kernel_program", "fg_shader", "fragment", fragshadercode)


#Now that the shader has been created, attach it to the program, and attach
# the program to a DisplayableObject, specified by ID.
attach_program("demo", "kernel_program")

shader_param("kernel_program", "fg_shader", "Freq", [4.0, 4.0])
shader_param("kernel_program", "fg_shader", "Amplitude", [.05, .05])
shader_param("kernel_program", "vk_shader", "LightPosition", [0.0, 0.0, 4.0])

#for x in range(800):
shader_param("kernel_program", "fg_shader", "StartRad", [float(x)/100.0])

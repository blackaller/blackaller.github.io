#
#  e15_subpageimg.py
#  E15
#
#  Created by buza on 11/22/08.
#  Copyright 2007 buza. All rights reserved.
#fff

from staticwriter import *
from random import random

def onHit(e):
  dprint(e)

def myrand():
  if random() < 0.5: 
    return random()
  else:
    return -random() 

jscriptload("http://www.prototypejs.org/assets/2008/9/29/prototype-1.6.0.3.js")

jscript = """
function pyeval(s) {
    l = document.getElementsByTagName(s);

    var myArray = []; 
    var mindex = 0;
    for (var i = 0; i < l.length; i++) {
      var w = Element.getWidth(l[i]);
      var h = Element.getHeight(l[i]);
      var ol = l[i].offsetLeft;
      var ot = l[i].offsetTop;
      var dm = Element.getDimensions(l[i]);

      myArray[mindex++] = ol;
      myArray[mindex++] = ot;
      myArray[mindex++] = dm['width'];
      myArray[mindex++] = dm['height'];
    }
    return myArray;
}
"""

regions = []
names = []

def scripty():
  global jscript
  global regions
  global names

  result =  jscripteval(jscript, "pyeval", ["a"])
 
  mind = 0

  for i in range(len(result)/4):
    reg = []
    reg.append(result[mind])
    mind = mind+1
    reg.append(result[mind])
    mind = mind+1
    reg.append(result[mind])
    mind = mind+1
    reg.append(result[mind])
    mind = mind+1
 
    regions.append(reg)
    names.append(str(i))

turl = "http://buza.mitplw.com/gspeak/test.html"
turl = "http://slashdot.org"
turl = "http://www.engadget.com/"
turl = "http:/wired.com"


def calle(e):
  global regions
  scripty()
  animate(e, "slide", [50, 0, 0, 0])
  animate(e, "alpha", [0.005, 1.0])
  subpageimg(names, turl, regions)
  offsetfromeye(e, 0,0,3)
  for eid in names:
    print eid
    animate(eid, "alpha", [0.005, .9])
    animate(eid, "scale", [.5, 200, 1])
    animate(eid, "slide", [50, myrand()*2, -random()*3 - 2, -random()*5 - 1])


browse("foo", turl, "calle")

envcolor(0,0,0)


for eid in names:
    print eid
    animate(eid, "alpha", [0.005, .9])
    #animate(eid, "scale", [.05, 800, 1])
    animate(eid, "slide", [.03, myrand()*2, -random()*3 - 2, -random()*5 - 1])


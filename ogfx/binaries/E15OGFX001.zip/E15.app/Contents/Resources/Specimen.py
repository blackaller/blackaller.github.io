#
#  Specimen.py
#  E15
#
#  Created by Takashi Okamoto on 10/5/07.
#  Copyright (c) 2007 PLW. All rights reserved.
#
from staticwriter import *

global_camera_speed(50)

class Specimen:
  texts = (
    {'text': 'Grid systems', 'size': 130},
    {'text': 'Spaltenbreite', 'size': 120},
    {'text': 'Zeilendurchschuss', 'size': 90},
    {'text': 'Müller-Brockmann', 'size': 80},
    {'text': 'Die neue Typographie 1928', 'size': 60},
    {'text': 'Germany, Holland, Czechoslovakia, Switzerland', 'size': 32},
    {'text': 'Walter Dexel, El Lissitzky, Kurt Schwtters, Jan Tschichold', 'size': 24}
  )
  font = 'Kettler-Regular'
  fontsize = 12.0
  
  def __init__(self, font, fontname, foundry, x, y, z):
    self.font = font
    self.fontname = fontname
    self.foundry = foundry
    self.x = x
    self.y = y
    self.z = z
    self.vOffset = 60.0
    self.padding = 60.0
    self.width, self.height = (960.0, 1300.0)
  
  def draw(self):
    # draw background
    elem_begin(self.width + 2*self.padding, self.height + 2*self.padding, self.fontname)
    elem_pos(self.x, self.y, self.z)
    background(1, 1, 1, 1)

    fontsize = 24
    font(Specimen.font, fontsize)
    fontcolor(0, 0, 0, 1)
    text(self.fontname + ' ' + self.foundry, 0, fontsize+self.vOffset, padding=60, flush=0.5)
    self.vOffset += self.padding + fontsize
    font(self.font, 48)
    text('ABCDEFGHIJKLMNOPQRSTUVWXYZ\nabcdefghijklmnopqrstuvwxyz\n0123456789', 0, fontsize+self.vOffset, padding=60, flush=0.5)
    self.vOffset += fontsize*6
    self.vOffset += self.padding
    # draw lines
    for i in range(len(Specimen.texts)):
      self.line(i)
    
    elem_end() # end background
  
  def line(self, line):
    # draw label
    fontsize = Specimen.fontsize
    font(Specimen.font, fontsize)
    text(self.fontname + ' ' + `Specimen.texts[line]['size']` + 'pt', 0, self.vOffset, padding=60)
    self.vOffset += 4
    # draw sets
    fontsize = Specimen.texts[line]['size']
    font(self.font, fontsize)
    text(Specimen.texts[line]['text'], 0, fontsize+self.vOffset, padding=60, flush=0.5, justification=1.0)
    self.vOffset += fontsize + self.padding

specimens = [
  ('ApexNew-Thin',          'ApexNew Thin',           'Thirstype'),
  ('ApexNew-Light',         'ApexNew Light',          'Thirstype'),
  ('ApexNew-Book',          'ApexNew Book',           'Thirstype'),
  ('ApexNew-Medium',        'ApexNew Medium',         'Thirstype'),
  ('ApexNew-Bold',          'ApexNew Bold',           'Thirstype'),
  ('ApexNew-Ultra',         'ApexNew Ultra',          'Thirstype'),
  
  ('Stag-Thin',       'Stag Thin',         'Schwartzco'),
  ('Stag-ThinItalic', 'Stag Thin Italic',  'Schwartzco'),
  ('Stag-Medium',     'Stag Medium',       'Schwartzco'),
  ('Stag-Bold',       'Stag Bold',         'Schwartzco'),
  ('Stag-Black',      'Stag Black',        'Schwartzco'),
  ('Stag-BlackItalic','Stag Black Italic', 'Schwartzco')
]

#p = []
#for i in range(len(specimens)):
#  p += [Specimen(specimens[i][0], specimens[i][1], specimens[i][2], 0, 0, i*8)]

p = []
row, col = (0, 0)
for i in range(len(specimens)):
 x = col * 3
 y = row * 4
 p += [Specimen(specimens[i][0], specimens[i][1], specimens[i][2], x, -y, -50)]
 col += 1
 if col > 5:
   col = 0
   row += 1

for i in range(len(p)):
  p[i].draw()

def onHit(e_id):
  print e_id
  camera_goto(e_id)

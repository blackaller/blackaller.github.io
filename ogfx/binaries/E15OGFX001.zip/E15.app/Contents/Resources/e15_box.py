
#
#  e15_box.py
#  E15
#
#  Created by buza on 11/22/08.
#  Copyright 2008 buza. All rights reserved.
#

from staticwriter import *
from random import random

def myrand():
  if random() < 0.5: 
    return random()
  else:
    return -random() 

elem = "demo5"

elem_begin(512, 512, elem)
elem_pos(0, 0, 0)
background(0, 0, 0, 0.0)
linewidth(20)
strokecolor(1, 1, 1, 1)
stroke()
radius = 400
rect(50, 50, radius, radius)
elem_end()

animate(elem, "scale", [1, 300, 1])
animate(elem, "slide", [random()/10.0, 4*myrand(), myrand()*4, myrand()/100.0 + .5])
animate(elem, "alpha", [0.005, 1.0])

def onRight():
  animate(elem, "slide", [random()/100.0, 10*myrand(), myrand()*10, myrand()*10])
  
  
animate(elem, "scale", [1, 700, 1])
animate(elem, "slide", [.05, 0, 0, -5])


xp = -6
def onRight():
  global xp
  animate(elem, "slide", [.05, xp, -4.6, 0.1])
  xp = xp - 0.5
#
#  buza_flickr.py
#  E15
#
#  Created by buza on 11/12/07.
#  Copyright 2007 MITPLW. All rights reserved.
#

import flickrapi
from staticwriter import *

api_key = '28817caf4e1eed49d9649bff346ff0bf'
api_secret = '4743b76d2c0ce6a8'

flickr = flickrapi.FlickrAPI(api_key, api_secret)

(token, frob) = flickr.getTokenPartOne(perms='write')
if not token: raw_input("Press ENTER after you authorized this program")
flickr.getTokenPartTwo((token, frob))

img_small = 2
img_medium = 3
img_large = 4

collect_type = img_large

alltags = []
tagkeeper = {}

#Get all photosets
photosets  = flickr.photosets_getList().photosets[0].photoset

for setelem in photosets:
  setid = setelem['id']
  photos = flickr.photosets_getPhotos(photoset_id=setid)

  for id in photos.photoset[0].photo:
    photoid = id['id']
    photo = flickr.photos_getSizes(photo_id=photoid).sizes[0].size
    sourceurl = photo[collect_type]['source']
    taglist = flickr.tags_getListPhoto(photo_id=photoid).photo[0].tags
    for tag in taglist:
      for t in tag.tag:
        thetag = t['raw']
        if tagkeeper.has_key(thetag):
          tagkeeper[thetag].append(sourceurl)
        else:
          alltags.append(thetag)
          imagelist = []
          imagelist.append(sourceurl)
          tagkeeper[thetag] = imagelist


loaded = {}

i = 0
x = 0
yc = 0
y = 0
cx = 0

for key in tagkeeper.keys():
  i = 0
  chx = 0
  ld = {}
  for imgurl in tagkeeper[key]:
    if ld.has_key(imgurl) or cx == 0:
      pass
    else:
      i += 0.5
      ld[imgurl] = "t"
      imgload(imgurl, "goo", x, y, i, 0, 0, 0)
      if chx == 0:
        elem_begin(800, 500, str(1))
        elem_pos(x-.5, y+1, i+0.01)
        elem_xform(0, 90, 0)
        fontcolor(1, 1.0, 0.1, 0.9)
        font("Arial", 75.0)
        text(key, 0, 100)
        elem_end()
        chx = 1
  cx = 1
  if (yc % 4) == 0:
    x = 0
    y -= 4.5
  i = 0
  yc += 1
  x += 6.5
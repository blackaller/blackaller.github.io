#
#  e15_pdfload.py
#  E15
#
#  Created by buza on 1/24/08.
#  Copyright (c) 2008 MITPLW. All rights reserved.
#

from staticwriter import *
pdfname = "http://developer.apple.com/documentation/GraphicsImaging/Reference/CGDataProvider/CGDataProvider.pdf"

envcolor(1, 1, 0)

#Get the number of pages in the pdf.
num_pages = pdfnumpages(pdfname)

#Remember, page numbers start at 1
for i in range(num_pages):
  # pdfpage<id, url, page_number, x_pos, y_pos, z_pos, background_alpha>;
  pdfpage(str(i), "http://developer.apple.com/documentation/GraphicsImaging/Reference/CGDataProvider/CGDataProvider.pdf", i+1, -i, 0, -i, 1- i/(num_pages*1.0))
  

def onHit(e_id):
  camera_goto(e_id)
#
#  webview.py
#  E15
#
#  Created by buza on 1/13/08.
#  Copyright (c) 2007-2008 MITPLW. All rights reserved.

from staticwriter import *
import sys

import Foundation
import WebKit
import AppKit
import objc

app = AppKit.NSApplication.sharedApplication()

# Create a window
rect = Foundation.NSMakeRect(800,800,1000,1000)
win = AppKit.NSWindow.alloc()

props = AppKit.NSResizableWindowMask  | AppKit.NSTitledWindowMask | AppKit.NSMiniaturizableWindowMask | AppKit.NSClosableWindowMask
win.initWithContentRect_styleMask_backing_defer_ (rect, props, 2, 0)

# Create a webview object
webview = WebKit.WebView.alloc()
webview.initWithFrame_(rect)
webview.mainFrame().frameView().setAllowsScrolling_(objc.YES)

# Add the webview to the window
win.setContentView_(webview)
win.orderFront_(objc.nil)
#
#  TinyQubert.py
#  E15
#
#  Created by blackaller on 10/24/07.
#  Copyright (c) 2007 MITPLW. All rights reserved.
#


from staticwriter import *

from random import random
from math import *

envcolor(0.1,0.1,0.1)

start=5000
iconsize=20
monton=40
id=0
position=2
offset=0
x, y, z = (0, 0, -1)
#x, z = (position, -position)


for k in range(monton):	
	x, z = (position, -offset-k*0.650)
	for i in range(monton):
		id= start+ (monton*k) + i
		iconurl = 'http://tiny.media.mit.edu/render_icon/' + str(id) + '/' + str(iconsize)
		iconurl_1 = 'http://tiny.media.mit.edu/render_icon/' + str(id + 1)  + '/' + str(iconsize)
		iconurl_2 = 'http://tiny.media.mit.edu/render_icon/' + str(id + 2) + '/' + str(iconsize)
		print iconurl
		print iconurl_1
		print iconurl_2
		imgload(str(i)+str(k)+"1", iconurl, x, y, z, 0, 0, 0)
		imgload(str(i)+str(k)+"2", iconurl_1, x, y, z-0.650, -90, 0, 0)
		imgload(str(i)+str(k)+"3", iconurl_2, x+0.650, y, z, 0, 90, 0)	
		x += float(iconsize)/30
		z -= float(iconsize)/30
	y += float(iconsize)/30
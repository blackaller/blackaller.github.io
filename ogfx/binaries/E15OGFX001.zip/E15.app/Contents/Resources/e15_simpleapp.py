#
#  e15_simpleapp.py
#  E15
#
#  Created by buza on 1/23/08.
#  Copyright (c) 2007-2008 MITPLW. All rights reserved.
#

from AppKit import *
from Foundation import *
import WebKit
import objc

global win, mwebview, loaddelegate, shouldKeepRunning

class WinDelegate (NSObject):
	def windowShouldClose_(self, aNotification):
		pass
	def windowWillClose_(self, aNotification):
		pass

class WebkitLoadr (NSObject, WebKit.protocols.WebFrameLoadDelegate):
	def webView_didFailLoadWithError_forFrame_(self,webview,error,frame):
		pass
	def webView_didFailProvisionalLoadWithError_forFrame_(self,webview,error,frame):
		pass
	def didStartProvisionalLoadForFrame_(self,webview,frame):
		pass
	def webView_didFinishLoadForFrame_(self,webview,frame):
		url = frame.dataSource().request().URL().absoluteString()
		print "Loading url: ", url
		global shouldKeepRunning
		#shouldKeepRunning = False

		if url.hasSuffix_(".txt"):
			#shouldKeepRunning = False
			NSNotificationCenter.defaultCenter().postNotificationName_object_("drawScriptHandler", url)
			webview.goBack()

		
app = NSApplication.sharedApplication()

rect = NSMakeRect(800,800,600,600)
win = NSWindow.alloc()

props = NSResizableWindowMask  | NSTitledWindowMask | NSMiniaturizableWindowMask | NSClosableWindowMask
win.initWithContentRect_styleMask_backing_defer_ (rect, props, 2, 0)
win.setTitle_('WebView from Python')

# Create a webview object
mwebview = WebKit.WebView.alloc()
mwebview.initWithFrame_(rect)
loaddelegate = WebkitLoadr.alloc().init()
mwebview.setFrameLoadDelegate_(loaddelegate)

windelegate = WinDelegate.alloc().init()
win.setDelegate_(windelegate)

mwebview.mainFrame().frameView().setAllowsScrolling_(objc.YES)

# Add the webview to the window
win.setContentView_(mwebview)
win.orderFront_(objc.nil)

pool = NSAutoreleasePool.alloc().init()

shouldKeepRunning = True
mwebview.mainFrame().loadRequest_(NSURLRequest.requestWithURL_(NSURL.URLWithString_("http://plw.media.mit.edu/people/buza/ogfx/dir.html")))

while shouldKeepRunning:
	NSRunLoop.currentRunLoop().runMode_beforeDate_(NSDefaultRunLoopMode, NSDate.alloc().initWithTimeIntervalSinceNow_(4))

loaddelegate.release()
windelegate.release()
#mwebview.close() #this line crashes
win.close()
pool.release()

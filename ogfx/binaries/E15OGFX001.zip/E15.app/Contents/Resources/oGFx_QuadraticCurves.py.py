#
#  QuadraticCurves.py
#  OpenGFX
#
#  Created by blackaller on 10/24/07.
#  Copyright (c) 2007 MITPLW. All rights reserved.
# 


from drawengine import *
from math import *
import random 

size = 512

tsize(size)

history(100,0.05, 1)

linejoin(2)
linewidth(12)

pipi = 2*pi
a=2

# filters
#root.gaussianblur("radius",10)
#root.colorcontrols("saturation",20)
#root.edges("intensity",6)
#root.pixellate("scale",6)

# filter removals
#root.removeFilter("gaussianblur", lambda: del_gaussianblur())
#root.removeFilter("colorcontrols", lambda: del_colorcontrols())
#root.removeFilter("edges", lambda: del_edges())
#root.removeFilter("pixellate", lambda: del_pixellate())

envcolor(0,0,0)

#blendmode(4,0)
blendmode(0,8)

def draw():
	global a
	background(1,1,1,0)	
	color(cos(a),0,sin(a),0.01)
	stroke(1,cos(a),sin(a),0.1)

	push()
	translate(256,256)
	p= Polygon(24, 64*(1+sin(a)) + 20 )
	push()
	#rotate(float(random.randint(0,100)))
	rotate(a)
	p.displayPolygon()
	pop()
	pop()
	a+=0.01
	#print str(superFormulaRadius(a,2.0,2.0,2.0,2.0))
	#print radiusRandomizer(64.0,32.0)

class Polygon:
	global a, pipi
	def __init__(self, numVertices, radius):
		self.n = numVertices
		self.r = radius		
		
	def displayPolygon(self):
		oscillateradius = radiusOscillator(self.r, a, 16, 0)
		#oscillateradius =100
		

		moveto(oscillateradius,0)
		beginline()
		
		for i in range(self.n):
			k=1+i
			controlPointX = ((50*sin(a*k))+oscillateradius) * cos((k*pipi)/self.n - (pi)/self.n)
			controlPointY = ((50*sin(a*k))+oscillateradius) * sin((k*pipi)/self.n - (pi)/self.n)
			
			#randomradius = radiusRandomizer(self.r,16.0)
			#oscillateradius = radiusOscillator(self.r, a, 16, i)
			#line( randomradius * cos((i*2*pi)/self.n), randomradius* sin((i*2*pi)/self.n))
			#line( oscillateradius * cos((i*2*pi)/self.n), oscillateradius * sin((i*2*pi)/self.n))
			
			quadcurve(controlPointX, controlPointY, oscillateradius * cos(((k-1/2)*pipi)/self.n), oscillateradius * sin(((k-1/2)*pipi)/self.n))
			
		closeline()
		
		#for i in range(self.n):
		#	k=1+i
		#	stroke(0,0,0,0)
		#	color(float(i)/self.n,1,float(i)/self.n,1)
		#	controlPointX = ((50*sin(a*k))+oscillateradius) * cos((k*pipi)/self.n - (pi)/self.n)
		#	controlPointY = ((50*sin(a*k))+oscillateradius) * sin((k*pipi)/self.n - (pi)/self.n)
		#	ellipse(controlPointX, controlPointY,8,8)
			
	

def superFormulaRadius(angle, m, n1, n2, n3):
	rad = ( abs( cos(m*angle/4)**n2 ) + abs( cos(m*angle/4)**n3 ) )**(-1/n1)
	return rad

def radiusRandomizer(radius, range):
	rand = float(random.randint(0,100))
	rad = radius - range * cos(rand)  
	return rad

def radiusOscillator(radius, osc, range, var):
	rand = float(random.randint(0,var))
	rad = radius - radius * cos(osc+rand) /range 
	return rad

root.crystallize("radius", 100)
root.kaleidoscope("center", [150, 150])    
root.glasslozenge("radius", 500)
#
#  e15_youtube_grid.py
#  E15
#
#  Created by buza on 03/19/08.
#  Copyright (c) 2007-2008 MITPLW. All rights reserved.
#

from staticwriter import *
from random import random

import gdata.service, urllib

#glisten(1)

def myrand():
  if random() < 0.5: 
    return random()
  else:
    return -random() 

class YTThumbnail:

  def __init__(self):
    self.url = None
    self.x, self.y, self.z = (0, 0, 0)
    self.rx, self.ry, self.rz = (0, 0, 0)
    self.alpha = 1.0
    self.viewcount = 0
    self.duration = 0
    self.rating = 0
    self.gp = None
    
  def position(self, x, y, z):
    self.x = x
    self.y = y
    self.z = z


def search(searchstring, start, count):
  x = "http://gdata.youtube.com/feeds/api/videos?vq="
  pieces = searchstring.split(" ")
  for piece in range(len(pieces)):
    x += pieces[piece] + "+"
 
  #x += searchstring
  x += "&start-index="
  x += str(start)
  x += "&max-results="
  x += str(count)
  serv = gdata.service.GDataService()
  return serv.Get(x)

def printElements(ext_element):

   thumb = None

   if len(ext_element.children) != 0:
     thumbArray.append(YTThumbnail())
     for child in ext_element.children:
       printElements(child)
   else:
     thumb = thumbArray.pop()
     if ext_element.tag == 'content':
       urlurl = ext_element.attributes['url']
       if urlurl.startswith("http:"):
         thumb.gp = urlurl 

     #print ext_element.tag, ":::", ext_element.attributes
     if ext_element.tag == 'rating':
       thumb.rating = ext_element.attributes['average']
     elif ext_element.tag == 'statistics':
       thumb.viewcount = ext_element.attributes['viewCount']
     elif ext_element.tag == 'thumbnail':
       thumb.url = ext_element.attributes['url']

     thumbArray.append(thumb)

global_elem_speed(.2)

zz = 0
idx = 1
idDict = {}

hpos = []

dpos1 = []
darray1 = []

dpos2 = []
darray2 = []

dpos3 = []
darray3 = []

def run(z, dpos, darray):
 global zz, idx, thumbArray, idDict, hpos
 x = 0
 y = 0
 fnames = []
 idnames = []
 opos = []
 ot = []
 dt = []
 owh = []
 dwh = []

 thumbArray = []
 zzz = z

 for i in range(3):
   feed = search("gigantor", idx, 30)
   for entry in feed.entry:
     for ext_element in entry.extension_elements:
       printElements(ext_element)
   for thumb in thumbArray:
     if thumb.url != None and thumb.gp != None:
       zzz = zzz + 0.001
       setorigin(x, y, -5, 0, 0, 0)
       fnames.append(thumb.url)
       idnames.append(str(zz))
       darray.append(str(zz))
       opos.append([myrand()*60,myrand()*40, myrand()*70])
       dpos.append([x-6.0,y-5.0,zzz])
       ot.append([0,0,0])
       dt.append([0,0,0])
       owh.append([0,0])
       dwh.append([80,80])
       #imgload(thumb.url, str(zz), x, y, 0, 0, 0, 0, 0, 0)
       x = x + .8
       if x > 10:
         x = 0
         y = y + .6
       thumb.position(x, y, zzz)
       
       idDict[str(zz)] = thumb
       zz -= 1
   idx += 30

 imgloada(fnames, idnames, opos, dpos, ot, dt, owh, dwh, 1)

run(-9, dpos1, darray1)
run(-12, dpos2, darray2)
#run(-15, dpos3, darray3)


zval = 0.0
zz = 0
xx = -1
yy = 0

mark = 0

def onLeft():
  global mark
  mark = 0
  print "Mark:", mark


def drawPiclensStyle():
  x = displayables()
  xs = 0.0
  ys = 0
  count  = 0
  for i in x:
    if xs >= 104.0:
      xs = 0
      ys = ys + 0.62

    elem_moveto(i, xs, ys, 0)
    xs += .82
	
def onTap(tapcount):
  print "num taps", tapcount
  global dpos1, dpos2, dpos3, darray1, darray2, darray3
  idx = 0

  for i in darray1:
	elem_moveto(i, dpos1[idx][0], dpos1[idx][1], dpos1[idx][2])
	idx = idx + 1

  idx = 0	
  for i in darray2:
	elem_moveto(i, dpos2[idx][0], dpos2[idx][1], dpos2[idx][2])
	idx = idx + 1

  idx = 0
  for i in darray3:
	elem_moveto(i, dpos3[idx][0], dpos3[idx][1], dpos3[idx][2])
	idx = idx + 1

foo = 0
def onShake():
  global foo
  if foo == 1:
    foo = 0
    drawPiclensStyle()
    return
  x = displayables()
  foo = 1 
  for i in x:
    xs = 1.0
    ys = 1.0
    zs = 1.0

    if random() < 0.5:
      xs = -1.0 * xs
    if random() < 0.5:
      ys = -1.0 * ys
    if random() < 0.5:
      zs = -1.0 * zs 
    elem_moveto(i, xs * random()*6 + 1.0, ys * random()*6 * 1.0, zs *random()*6)


global_elem_speed(1/20.0)

def onRight():
  global mark
  mark = 1
  print "Mark:", mark

def onUp():
  x = displayables()
  xs = 0.0
  ys = 0
  count  = 0
  for i in x:
    if xs >= 34.0:
      xs = 0
      ys = ys + 0.6
	  
    elem_moveto(i, xs, ys, 0)
    xs += .8

def onDown():
  onTap(2)

def onHit(e_id):
  global idDict, zval, xx, yy, zz
  if mark == 1:
    camera_goto(e_id, -.3, .35, 0)
    return
  print "LOAD ", idDict[e_id].gp
  global_elem_speed(1.0/70.0)
  if idDict[e_id].gp == None:
    print "No file. Try again"
    pass
  else:
    print "3GP url:", idDict[e_id].gp
    print "ViewCount: ", idDict[e_id].viewcount
    #idparam(e_id, "mapscaler", float(idDict[e_id].viewcount*2))
    pos = []
    rot = []
    dp = dpos(e_id)
    for x in range(1):
      pos.append([dp[0], dp[1], dp[2] + 1])
      rot.append([0, 0, 0])

    print "Loading ", e_id+"_X"
    loadmovie(e_id+"_X", idDict[e_id].gp)
    #print "ghello"
    startmovie(e_id+"_X", pos, rot)

    pos = []
    rot = []
    for x in range(1):
      pos.append([dp[0], dp[1], dp[2] + 2 + random()])
      rot.append([0, 0, 0])

    moviepos(e_id+"_X", pos, rot)
    #elem_moveto(e_id, idDict[e_id].x, idDict[e_id].y, idDict[e_id].z + 1, 0, 0, 0)
    #elem_moveto(e_id+"_X", xx, yy, 5, 0, 0, 0)
    xx = xx + 2.5

def onFound(e):
  print "Found ", e

delta = 0

def onSelect(e):
  global delta
  p = dpos(e)
  elem_moveto(e, p[0], p[1], p[2]+0.9+delta)
  delta = delta + 0.0001

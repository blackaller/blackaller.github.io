
#
#  e15_flickrRemote.py
#  E15
#
#  Created by buza on 11/22/08.
#  Copyright 2008 buza. All rights reserved.
#

import sys, os, re
from staticwriter import *
from urllib2 import HTTPError
from BeautifulSoup import BeautifulSoup
from facebook import Facebook
from random import random

import mechanize
assert mechanize.__version__ >= (0, 0, 6, "a")

def myrand():
  if random() < 0.5: 
    return random()
  else:
    return -random() 

mech = mechanize.Browser()
mech.set_handle_robots(False)

def grab(n, p):
  global mech
  mech.open("http://www.facebook.com")

  # There's only one form on this page, so grab it.
  mech.select_form(nr=0)

  mech["email"] = n
  mech["pass"] = p

  try:
    mech.submit()
  except HTTPError, e:
    sys.exit("post failed: %d: %s" % (e.code, e.msg))

  return mech.response()

username = ""
password = ""
rawhtml = grab("trankelson@gmail.com", "fuckyou").read()



#Hardly generic
mech.follow_link(text_regex=re.compile("Inbox"))

#print mech.response().read()

"""
<li class="current"><a href="/inbox/?f=0&amp;start=0">1</a></li>
<li><a href="/inbox/?f=0&amp;start=20">2</a></li>
<li><a href="/inbox/?f=0&amp;start=40">3</a></li>
<li><a href="/inbox/?f=0&amp;start=20">Next</a></li>
"""
inboxstr = re.escape("f=0&start=")
links = mech.links(url_regex=re.compile(inboxstr))

numpages = 0
for link in links:
  numpages = numpages + 1

numpages = numpages - 1

print "Number of link pages", numpages

msgs = []

for page in range(numpages):
  links = mech.links(url_regex=re.compile(inboxstr))
  for link in links:
    if link.text  == "Next":
      mech.follow_link(link)
      msglinks = mech.links(url_regex=re.compile("readmessage"))
      #print mech.response().read()
      for msg in msglinks:
        msgs.append(msg.text)
      links = mech.links(url_regex=re.compile(inboxstr))
      break

def onHit(e):
  camera_goto(e)

plo = 0

for msg in msgs:
      fontsize = 26.0
      font("Stag", fontsize)
      fontcolor(1, 1, 1, 0.95)
      textbox(str(plo), msg, len(msg)*fontsize, 0,0,0,0,0,0, flush=1.0)
      animate(str(plo), "alpha", [0.005, .9])
      animate(str(plo), "scale", [.5, 200, 1])
      animate(str(plo), "slide", [50, myrand()*2, -random()*3 - 2, -random()*5 - 1])
      plo = plo + 1 
#
#  e15_jsoffsets.py
#  E15
#
#  Created by buza on 11/12/07.
#  Copyright 2007 buza. All rights reserved.
#

#http://buza.mitplw.com/gspeak/test.html

from staticwriter import *

jscriptload("http://www.prototypejs.org/assets/2008/9/29/prototype-1.6.0.3.js")

jscript = """
function pyeval(s) {
    l = document.getElementsByTagName(s);

    var myArray = []; 
    var mindex = 0;
    for (var i = 0; i < l.length; i++) {
      var w = Element.getWidth(l[i]);
      var h = Element.getHeight(l[i]);
      var ol = l[i].offsetLeft;
      var ot = l[i].offsetTop;
      var dm = Element.getDimensions(l[i]);

      myArray[mindex++] = l[i].text;

    }
    return myArray;
}
"""
result =  jscripteval(jscript, "pyeval", ["a"])

print result
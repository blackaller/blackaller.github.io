#
#  e15_PotNpotTest.py
#  E15
#
#  Created by Kate Hollenbach on 4/9/08.
#  Copyright (c) 2008 MIT PLW. All rights reserved.
#

from staticwriter import *
from math import *
from random import random


URL_PREFIX = 'http://e15.media.mit.edu/_E15'

x, y, z = (0, 0, -10)
imgload(URL_PREFIX + "/pages/openstudio.png", "os", x, y, z, 0, -10, 0)

fontcolor(1, 1.0, 0.1, 0.9)
font("ApexNew-Bold", 50.0)
textbox("openstudio", "http://openstudio.media.mit.edu", 768, x-.5, y+1.5, z+0.01,0, 20, 0)

vertices = [0.0, 0.0, 0.0, 1.0, 0.0, 0.5, 0.0, -1.0, 0.5, 1.0, -1.0, 0.0]
normals = [0.0, 0.0, 1.0, 0.0, 0.0, 1.0, 0.0, 0.0, 1.0, 0.0, 0.0, 1.0]
textureCoords = [0.0, 0.0, 100.0, 0.0, 0.0, 100.0, 100.0, 100.0]
indices = [0, 1, 2, 1, 2, 3]
x, y, z = (0.0, 0.0, 0.0)

mesh("http://web.mit.edu/kjhollen/www/splash-top.jpg", "MESH", x, y, z, vertices, normals, textureCoords, indices)

x, y, z = (2, 1.5, -12)
imgload(URL_PREFIX + "/pages/opencode.png", "oc", x, y, z, 0, -10, 0)
fontcolor(1, 1.0, 0.1, 0.9)
font("ApexNew-Bold", 50.0)
textbox("opencode", "http://opencode.media.mit.edu", 768, x-.5, y+1, z+0.01,0, 20, 0)
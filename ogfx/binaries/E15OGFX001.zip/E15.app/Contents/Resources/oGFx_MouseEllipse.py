#
#  MouseEllipse.py
#  OpenGFX
#
#  Created by blackaller on 10/24/07.
#  Copyright (c) 2007 MITPLW. All rights reserved.
#

from drawengine import *

history(1,0.0001)
#Size of the texture
size = 512

tsize(size)

mx = 0
my = 0

mouse()
linewidth(4)

class Point2D:
	def __init__(self, px, py):
		self.x = px
		self.y = py



def draw():
	global mx, my
	background(1,1,1,0)
	print(mx,my)
	stroke(1,1,1,0.4)
	color(0,0,0,0)
	push()
	translate(-mapScreenToQuad(Point2D(mx,my)).x/2,-mapScreenToQuad(Point2D(mx,my)).y/2)
	ellipse(mapScreenToQuad(Point2D(mx,my)).x,mapScreenToQuad(Point2D(mx,my)).y,mapScreenToQuad(Point2D(mx,my)).x,mapScreenToQuad(Point2D(mx,my)).y)
	pop()

def mapScreenToQuad(point):
	mapx = point.x * 512 / screenWidth
	mapy = point.y * 512 / screenHeight
	return Point2D(mapx,mapy)
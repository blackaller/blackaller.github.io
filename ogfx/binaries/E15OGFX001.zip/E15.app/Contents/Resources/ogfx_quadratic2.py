#
#  QuadraticCurves.py
#  E15:oGFx
#

from drawengine import *
from math import *
import random 

size = 256

tsize(size)

class Polygon:
	global a, pipi, lalpha, falpha
	def __init__(self, numVertices, radius):
		self.n = numVertices
		self.r = radius	
		
		
	def setFill(self,r,g,b,a):
		color(r,g,b,a)
	
	def setLine(self,r,g,b,a):
		stroke(r,g,b,a)
	
	def displayPolygon(self):
		
		oscillateradius = radiusOscillator(self.r, a, 16, 0)
		
		moveto(oscillateradius,0)
		beginline()
		
		for i in range(self.n):
			k=1+i
			controlPointX = ((50*sin(a*k))+oscillateradius) * cos((k*pipi)/self.n - (pi)/self.n)
			controlPointY = ((50*sin(a*k))+oscillateradius) * sin((k*pipi)/self.n - (pi)/self.n)
			quadcurve(controlPointX, controlPointY, oscillateradius * cos(((k-1/2)*pipi)/self.n), oscillateradius * sin(((k-1/2)*pipi)/self.n))
		closeline()
		
		for i in range(self.n):
			k=1+i
			stroke(0,0,0,0)
			color(float(i)/self.n,float(i)/self.n,0.8,0.4)
			controlPointX = ((50*sin(a*k))+oscillateradius) * cos((k*pipi)/self.n - (pi)/self.n)
			controlPointY = ((50*sin(a*k))+oscillateradius) * sin((k*pipi)/self.n - (pi)/self.n)

history(1,0.05, 1)

linejoin(2)
linewidth(4)

pipi = 2*pi
a=2

width = 256
height = 256

lalpha = 0.8
falpha = 0.2

p= Polygon(13, (width/8) * (1+sin(a)) + 10 )

envcolor(0, 0, 0)

blendmode(0,2)

def draw():
	global a, width, height, lalpha, falpha, p
	background(1,1,1,0)	

	push()
	translate(width/2,height/2)
	push()
	rotate(a)
	p.setFill(cos(sin(a)), sin(cos(a)), sin(a), falpha)
	p.setLine(1, cos(a/4), sin(a/4), lalpha)
	p.displayPolygon()
	pop()
	pop()
	a+=0.005

def superFormulaRadius(angle, m, n1, n2, n3):
	rad = ( abs( cos(m*angle/4)**n2 ) + abs( cos(m*angle/4)**n3 ) )**(-1/n1)
	return rad

def radiusRandomizer(radius, range):
	rand = float(random.randint(0,100))
	rad = radius - range * cos(rand)  
	return rad

def radiusOscillator(radius, osc, range, var):
	rand = float(random.randint(0,var))
	rad = radius - radius * cos(osc+rand) /range 
	return rad 

history(100, 0.045, 0.05)

camera(-0.40290796756744385, 0.013463336974382401, -0.9151415228843689, 2.0504593849182129, 0.0042628445662558079, -0.35059484839439392)
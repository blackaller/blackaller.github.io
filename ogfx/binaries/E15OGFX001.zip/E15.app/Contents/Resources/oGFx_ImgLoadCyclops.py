#
#  ImgLoadCyclops.py
#  OpenGFX
#
#  Created by blackaller on 10/24/07.
#  Copyright (c) 2007 MITPLW. All rights reserved.
#

from drawengine import *
from math import *

#Size of the texture
size = 512

tsize(size)

# filters
#root.gaussianblur("radius",10)
#root.colorcontrols("saturation",20)
#root.edges("intensity",6)
#root.pixellate("scale",6)

# filter removals
#root.removeFilter("gaussianblur", lambda: del_gaussianblur())
#root.removeFilter("colorcontrols", lambda: del_colorcontrols())
#root.removeFilter("edges", lambda: del_edges())
#root.removeFilter("pixellate", lambda: del_pixellate())

#history(300,0.001)

a=0
b=0
c=0
width=512
height=512
radiusX=0
radiusY=0
period=7

def draw():
	global a,b,c, width, height, radiusX, radiusY, period
	background(0,0,0,0.1)
	radiusX=50+abs(50*sin(c))
	radiusY=50+abs(50*sin(c))
	#stroke(0,0,0,(1+cos(a))/2)
	
	for k in range(1): #max de 6
		i=k+6
		radiusX=i+5+abs(20*sin(c))
		radiusY=i+5+abs(20*sin(c))
		display (width/2+(200*sin((a))),height/2+(200*sin((b))), 1,1,1,1)
		display (width/2+(200*sin((a+pi/ period*i))),height/2+(200*sin((b+pi/ period*i))), 0,0,0.6,1)
		display (width/2+(200*sin(-(a+2*pi/ period*i))),height/2+(200*sin((b+2*pi/ period*i))), 0.5+(1+sin(a))/4,0,0,1)
		#display (width/2+(200*sin((-a))),height/2+(200*sin((-b))), 1,1,1,1)
		#display (width/2+(200*sin(-(a+pi/ period*i))),height/2+(200*sin(-(b+pi/ period*i))), 0.6,0,0,1)
		#display (width/2+(200*sin((a+2*pi/ period*i))),height/2+(200*sin(-(b+2*pi/ period*i))), 0,0,0.5+(1+sin(a+pi))/4,1)
	
	a+=0.01
	b+=0.015
	#c+=0.025
	#period=sin(period/2) + period/2 +0.01
	
def display(x,y,r,g,b,a):	
	push()
	translate(x,y)

	color(0,0,0,1)
	#ellipse(-1.5 * radiusX,-1.5 * radiusY, 3 * radiusX, 3 * radiusY)
	
	color(r,g,b,a)
	
	#push()
	#rotate((x*y)/65532)
	#fontprops("Helvetica-Bold", 1.5 * radiusX, 0, 2)
	#text("TDC", - radiusX-8, 0.5*-radiusY)
	#fontprops("Helvetica-Bold", 1.5 * radiusX, 0, 0)
	#text("TDC", - radiusX-8, 0.5*-radiusY)
	#pop()


	push()
	#rotate((x*y)/65532)
	translate(-radiusX*4,-radiusY*4)
	scale(0.3,0.3)
	imgload("http://pixs.media.mit.edu/picture/image/5830/cyclops.png", radiusX, radiusY)
	#imgload("http://pixs.media.mit.edu/picture/image/5831/sanrio.png", radiusX, radiusY)
	pop()	
	
	#color(0.5,0.5,0.5,1)
	color(0.6,0,0,1)
 	#ellipse(0.8*-radiusX,0.8*-radiusY, 1.6 * radiusX, 1.6 * radiusY)
	
	color(1,1,1,1)
	#ellipse(0.2*-radiusX,0.2*-radiusY, 0.4 * radiusX, 0.4 * radiusY)
	pop()
#
#  SimpleOrbits_1.py
#  E15
#
#  Mondo Bizarro
#  A mini orbital system
#  Created by  blackaller on 8/11/07.
#  Copyright (c) 2007 MITPLW. All rights reserved.

from drawengine import *
from math import *

#Size of the texture
size = 512

tsize(size)

a=0
width=512
height=512
diamA=100
orbitA=width/2
diamB=80
orbitB=90
diamC=60
orbitC=70
diamD=40
orbitD=50

history(200, 0.12, 1.5)

def draw():
	global a,width,height,diamA, diamB, orbitA, orbitB, diamC, diamC, orbitD, orbitD
	background(0,0,1,0)
	color(1,1,1,1)
	a=a+0.05

	push()
	#rotate(cos(a)/3)
	translate(orbitA,orbitA)
	
	
	# orbits go first
	push()
	
	push()
	translate(-(orbitB*2+diamB)/2,-(orbitB*2+diamB)/2)
	color(1,1,1,0.3)
	ellipse(0,0,orbitB*2+diamB,orbitB*2+diamB)
	pop()
	
	rotate(a)
	translate(orbitB,orbitB)
	
	push()
	translate(-(orbitC*2+diamC)/2,-(orbitC*2+diamC)/2)
	color(1,1,0,0.3)
	ellipse(0,0,orbitC*2+diamC,orbitC*2+diamC)
	pop()
	
	rotate(-a*2)
	translate(orbitC,orbitC)
	
	push()
	translate(-(orbitD*2+diamD)/2,-(orbitD*2+diamD)/2)
	color(1,0,1,0.3)
	ellipse(0,0,orbitD*2+diamD,orbitD*2+diamD)
	pop()
	
	pop() # end of orbit transformation stack
	
		
	# sun	
	push()
	rotate(a)
	translate(-diamA/2,-diamA/2)
	color(1,1,1,1)
	rect(0,0,diamA,diamA)
	pop()	
	
	
	# planets
	rotate(a)
	translate(orbitB,orbitB)
	
	push()
	rotate(-a*2)
	translate(-diamB/2,-diamB/2)
	color(1,1,0,.9)
	rect(0,0,diamB,diamB)
	pop()

	rotate(-a*2)
	translate(orbitC,orbitC)

	push()
	rotate(a*2)
	translate(-diamC/2,-diamC/2)
	color(1,0,1,.9)
	rect(0,0,diamC,diamC)
	pop()

	rotate(-a*2)
	translate(orbitD,orbitD)

	push()
	rotate(-a*2)
	translate(-diamD/2,-diamD/2)
	color(0,1,1,.9)
	rect(0,0,diamD,diamD)
	pop()
	
	

	

	#orbitA=orbitA+s
	#orbitB=orbitB+s
	#orbitC=orbitC+s
	
	pop()
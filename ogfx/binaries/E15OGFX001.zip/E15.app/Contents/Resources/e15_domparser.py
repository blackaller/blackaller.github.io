#
#  e15_domparser.py
#  E15
#
#  Created by buza on 07/16/08.
#  Copyright 2007 buza. All rights reserved.
#

from staticwriter import *

x = 20

#The parameters we send to the php file.
pdict = {"tag":"gigantor"}

#Send our request to the remote php file, and get a callback full of data on completion.
rservice("http://buza.mitplw.com/gspeak/dom.php", pdict, "myCallback")

#This gets called when we get our data. This will always be a dictionary, but may only have keys, no values.
def myCallback(dat):
  print dat
  i = 0
  for iurl in dat:
    imgload(iurl, str(i), -i, -i, -i, 0, 0, 0)
    i = i + 1
  
def onHit(e):
  camera_goto(e, -.3, .3, 0)
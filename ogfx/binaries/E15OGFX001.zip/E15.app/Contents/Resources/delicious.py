#
#  delicious.py
#  E15Plus
#
#  Created by Kate Hollenbach on 2/8/08.
#  Copyright (c) 2008 MITPLW. All rights reserved.
#


import urllib
import demjson
import time

def utf8(s):
    return s.encode('utf8')

class Delicious:
    """
    Module for querying the del.icio.us JSON API -- auto-handles throttling,
    so that we don't violate the Terms of Service and get banned.
    
      ----------------------------------------------------------------------
  
    Class Variables:
  
    timeOfLastQuery
        system time that the last query was made; used to throttle queries
        so we don't query more often than we're allowed.
  
    QUERY_BASE
       URL base for del.icio.us JSON queries
    """
    
    timeOfLastQuery = 0 # TODO(kjhollen) use this to throttle requests
    
    QUERY_BASE = "http://del.icio.us/feeds/json/"
    
    def __init__(self):
        timeOfLastQuery = 0
    
    def getPosts(self, user):
        query = Delicious.QUERY_BASE + "%s/?raw" % utf8(user)
        return self.runQuery(query)
    
    def getNetwork(self, user):
        query = Delicious.QUERY_BASE + "network/%s" % utf8(user)
        return self.runQuery(query)
        
    def getFans(self, user):
        query = Delicious.QUERY_BASE + "fans/%s" % utf8(user)
        return self.runQuery(query)
    
    def getTags(self, user):
        query = Delicious.QUERY_BASE + "tags/%s/?raw" % utf8(user)
        return self.runQuery(query)
    
    def runQuery(self, query):
        # throttle calls, so we don't piss off yahoo
        while (time.time() - Delicious.timeOfLastQuery < 1.0):
            pass # hang out -- will this block?
            
        # now run the query
        results = urllib.urlopen(utf8(query)).read()
        print results
        json = demjson.decode(results)
        timeOfLastQuery = time.time()
        return json
	

delicious = Delicious()

posts = delicious.getPosts("kjhollen")
for post in posts:
    if (post.has_key('n')):
        print "%(u)s -- %(d)s \n\ttags: %(t)s\n\t%(n)s" % \
            { 'u': post['u'], 'd' : post['d'], 't': post['t'], 'n' :post['n'] }
    else:
        print "%(u)s -- %(d)s \n\ttags: %(t)s" % \
            { 'u': post['u'], 'd' : post['d'], 't': post['t'] }
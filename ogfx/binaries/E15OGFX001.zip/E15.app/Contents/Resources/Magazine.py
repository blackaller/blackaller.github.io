#
#  Magazine.py
#  E15
#
#  Created by Takashi Okamoto on 10/21/07.
#  Copyright (c) 2007 PLW. All rights reserved.
#
from staticwriter import *
import re
import glob, os

DIRECTION = 'horizontal'
IMAGE_PATH = "/Users/mud/Desktop/fader_issue49/images/"

def all_files(pattern, search_path, pathsep=os.pathsep):
    """ Given a search path, yield all files matching the pattern. """
    files = []
    for path in search_path.split(pathsep):
        for match in glob.glob(os.path.join(path, pattern)):
            files.append(match.split("/")[-1])
    return files

images = all_files('*.png', IMAGE_PATH)

# draw title
elem_begin(3000, 300, 'fader')
elem_pos(2.5*3.5 - 3000/800/2, 2, 8)
font('ApexNew-Book', 200.0)
fontcolor(1, 1, 1, 1)
text('FADER Magazine Issue 49', 0, 200, flush=0.5)
elem_end()

# draw pages
x, y, z, rx, ry, rz = (0, 0, 0, 0, 0, 0)
row, col = (0, 0)
for i in range(len(images)):
  if DIRECTION == 'horizontal':
    x = col * 4
    y = -row * 3
    imgload('file://' + IMAGE_PATH + images[i], images[i], x, y, z, rx, ry, rz)
    col += 1
    if col > 5:
      col = 0
      row += 1
  else:
    imgload('file://' + IMAGE_PATH + images[i], images[i], x, y, z, rx, ry, rz)
    z -= 4
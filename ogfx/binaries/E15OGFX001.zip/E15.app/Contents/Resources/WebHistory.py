#
#  WebHistory.py
#  E15
#
#  Created by Takashi Okamoto on 10/25/07.
#  Copyright (c) 2007 MIT. All rights reserved.
#
from staticwriter import *
import time
urls = ["http://nytimes.com", "http://web.mit.edu", "http://www.cnn.com"]

class WebPage:
  font = 'ApexNew-Bold'
  fontcolor = (1, 1, 0, 1)
  fontsize = 36.0
  
  def __init__(self, url, x, y, z):
    self.url = url
    self.x = x
    self.y = y
    self.z = z
    
  def draw(self):
    # draw page
    browse(self.url, self.url, self.x, self.y, self.z, 0, 0, 0)
    # draw text
    elem_begin(512, 256, "elem" + self.url)
    elem_pos(self.x, self.y+0.3, self.z+0.001)
    font(WebPage.font, WebPage.fontsize)
    fontcolor(WebPage.fontcolor[0], WebPage.fontcolor[1], WebPage.fontcolor[2], WebPage.fontcolor[3])
    elem_xform(0, -10, 0)
    text(self.url, 0, WebPage.fontsize, flush=1.0)
    elem_end()
  
x, y, z = (0, 0, 0)
for i in range(len(urls)):
  u = WebPage(urls[i], i*1.5, 0, -i*4)
  u.draw()

def onHit(elem_id):
  print elem_id
  camera_goto(elem_id)
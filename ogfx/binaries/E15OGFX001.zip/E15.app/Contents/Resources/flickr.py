		
# testing python beej's flickr api
# kjhollen 09/23/2007
# (c) mit media lab

from staticwriter import *

import flickrapi
import simplejson



# kjhollen's flickr api keys for E15
api_key = '2f8ba42693eb41518673794c401ae9c3'
api_secret = '2b77e0ff47c011aa'

# create flickr object
flickr = flickrapi.FlickrAPI(api_key, api_secret)

# do authorization
# NOTE -- after token part one, authorization needs to happen in the web browser.
# I've already done this for my account (kjhollen) but if you want to use a
# a different api key, you'll need ot make sure that happens in the browser.

(token, frob) = flickr.getTokenPartOne(perms='read')
if not token: raw_input("Press ENTER after you authorized this program")
flickr.getTokenPartTwo((token, frob))

# use json responses
RESPONSE_FORMAT = 'json'
# these are random people kate knows
users = ['arikan', 'kjhollen', 'swhitt', 'mooshinier', 'evhan55', 'burnto', 'laurynie']

def getPhotoUrl(photo):
	url = 'http://farm' + str(photo['farm']) + '.static.flickr.com/' + str(photo['server']) + '/' + photo['id'] + '_' + photo['secret'] + '_m.jpg'
	return url

elem_begin(200, 300, str(1))
elem_pos(x, y, z)
elem_xform(0, 0, -90)
fontcolor(1, 1.0, 0.1, 0.9)
font("ApexSansBookT", 300.0) #HUGE!
text("flickr contacts", 0, 300)
elem_end()


x, y, z = (0, 0, 0)
xo, yo, zo = ()
for user in users:

	# get nsid from user name
	response = flickr.people_findByUsername(username=user, format=RESPONSE_FORMAT, nojsoncallback='1')
	resp_json = simplejson.loads(response)


	# if username not found, don't do anything.
	if (resp_json['stat'] == 'ok'):
		nsid = resp_json['user']['nsid']

		# get user's public photos
		response = flickr.people_getPublicPhotos(user_id=nsid, format=RESPONSE_FORMAT, nojsoncallback='1')
		response = simplejson.loads(response)
		photos = response['photos']['photo']
		# just to test -- print the title of all photos found
		x, z = (0, 0)
		for i in range(min(len(photos), 10)):
			photourl = getPhotoUrl(photos[i])
			print photourl
			imgload(photourl, x + xo, y + yo, z + zo, 0, -35, 0)	
			x += .05;
			z -= .5;
		y += 1
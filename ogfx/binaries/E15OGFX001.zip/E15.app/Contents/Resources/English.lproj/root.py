

class FLT_I_6732:
	def __init__(self, name, params):
		self.name = name
		self.params = params
		
class SHD_I_6732:
	def __init__(self, uniforms):
		self.uniforms = uniforms

class ROOT_I_6732:
	def __init__(self):
		self.actions = []
		self.filters = {}
		self.shader = None
	
	#This procedure is invoked in secret by the runtime.
	def filter(self):
		for f in self.filters.keys():
			self.filters[f].name(self.filters[f].params)

	#This procedure is invoked in secret by the runtime.
	def act(self):
		for a in self.actions:
			a()
	
	#Filter creator is passed the initial parameter dictionary.
	def addFilter(self, name, filter_creator, filter_proc, param_dict=None):
		if(len(self.filters.keys()) == 0):
			start_filtering()
		filter_creator(param_dict)
		self.filters[name] = FLT_I_6732(filter_proc, param_dict)

	def applyFilter(self, filter_name, param_name, increment):
		if root.filters[filter_name] != None:
			if root.filters[filter_name].params[param_name] != None:
				root.filters[filter_name].params[param_name] += increment
		
	def removeFilter(self, name, filter_remover):
		if(self.filters.has_key(name) == False):
			print "Filter ", name, "has not yet been added."
			return
		filter_remover()
		if(len(self.filters.keys()) == 0):
			stop_filtering()
		del self.filters[name]
		
	def addAction(self, action):
		self.actions.append(action)
		
	def removeAction(self, action):
		self.actions.remove(action)

	#Convenience filter methods.
	def additioncompositing(self, param, value):
		root.addFilter("additioncompositing",lambda x: add_additioncompositing(x), lambda x: additioncompositing(param, x), {param : value})

	def affineclamp(self, param, value):
		root.addFilter("affineclamp",lambda x: add_affineclamp(x), lambda x: affineclamp(param, x), {param : value})

	def affinetile(self, param, value):
		root.addFilter("affinetile",lambda x: add_affinetile(x), lambda x: affinetile(param, x), {param : value})

	def affinetransform(self, param, value):
		root.addFilter("affinetransform",lambda x: add_affinetransform(x), lambda x: affinetransform(param, x), {param : value})

	def areaaverage(self, param, value):
		root.addFilter("areaaverage",lambda x: add_areaaverage(x), lambda x: areaaverage(param, x), {param : value})

	def areahistogram(self, param, value):
		root.addFilter("areahistogram",lambda x: add_areahistogram(x), lambda x: areahistogram(param, x), {param : value})

	def areamaximum(self, param, value):
		root.addFilter("areamaximum",lambda x: add_areamaximum(x), lambda x: areamaximum(param, x), {param : value})

	def areamaximumalpha(self, param, value):
		root.addFilter("areamaximumalpha",lambda x: add_areamaximumalpha(x), lambda x: areamaximumalpha(param, x), {param : value})

	def areaminimum(self, param, value):
		root.addFilter("areaminimum",lambda x: add_areaminimum(x), lambda x: areaminimum(param, x), {param : value})

	def areaminimumalpha(self, param, value):
		root.addFilter("areaminimumalpha",lambda x: add_areaminimumalpha(x), lambda x: areaminimumalpha(param, x), {param : value})

	def barsswipetransition(self, param, value):
		root.addFilter("barsswipetransition",lambda x: add_barsswipetransition(x), lambda x: barsswipetransition(param, x), {param : value})

	def blendwithmask(self, param, value):
		root.addFilter("blendwithmask",lambda x: add_blendwithmask(x), lambda x: blendwithmask(param, x), {param : value})

	def bloom(self, param, value):
		root.addFilter("bloom",lambda x: add_bloom(x), lambda x: bloom(param, x), {param : value})

	def boxblur(self, param, value):
		root.addFilter("boxblur",lambda x: add_boxblur(x), lambda x: boxblur(param, x), {param : value})

	def bumpdistortion(self, param, value):
		root.addFilter("bumpdistortion",lambda x: add_bumpdistortion(x), lambda x: bumpdistortion(param, x), {param : value})

	def bumpdistortionlinear(self, param, value):
		root.addFilter("bumpdistortionlinear",lambda x: add_bumpdistortionlinear(x), lambda x: bumpdistortionlinear(param, x), {param : value})

	def checkerboardgenerator(self, param, value):
		root.addFilter("checkerboardgenerator",lambda x: add_checkerboardgenerator(x), lambda x: checkerboardgenerator(param, x), {param : value})

	def circlesplashdistortion(self, param, value):
		root.addFilter("circlesplashdistortion",lambda x: add_circlesplashdistortion(x), lambda x: circlesplashdistortion(param, x), {param : value})

	def circularscreen(self, param, value):
		root.addFilter("circularscreen",lambda x: add_circularscreen(x), lambda x: circularscreen(param, x), {param : value})

	def circularwrap(self, param, value):
		root.addFilter("circularwrap",lambda x: add_circularwrap(x), lambda x: circularwrap(param, x), {param : value})

	def cmykhalftone(self, param, value):
		root.addFilter("cmykhalftone",lambda x: add_cmykhalftone(x), lambda x: cmykhalftone(param, x), {param : value})

	def colorblendmode(self, param, value):
		root.addFilter("colorblendmode",lambda x: add_colorblendmode(x), lambda x: colorblendmode(param, x), {param : value})

	def colorburnblendmode(self, param, value):
		root.addFilter("colorburnblendmode",lambda x: add_colorburnblendmode(x), lambda x: colorburnblendmode(param, x), {param : value})

	def colorcontrols(self, param, value):
		root.addFilter("colorcontrols",lambda x: add_colorcontrols(x), lambda x: colorcontrols(param, x), {param : value})

	def colorcube(self, param, value):
		root.addFilter("colorcube",lambda x: add_colorcube(x), lambda x: colorcube(param, x), {param : value})

	def colordodgeblendmode(self, param, value):
		root.addFilter("colordodgeblendmode",lambda x: add_colordodgeblendmode(x), lambda x: colordodgeblendmode(param, x), {param : value})

	def colorinvert(self, param, value):
		root.addFilter("colorinvert",lambda x: add_colorinvert(x), lambda x: colorinvert(param, x), {param : value})

	def colormap(self, param, value):
		root.addFilter("colormap",lambda x: add_colormap(x), lambda x: colormap(param, x), {param : value})

	def colormatrix(self, param, value):
		root.addFilter("colormatrix",lambda x: add_colormatrix(x), lambda x: colormatrix(param, x), {param : value})

	def colormonochrome(self, param, value):
		root.addFilter("colormonochrome",lambda x: add_colormonochrome(x), lambda x: colormonochrome(param, x), {param : value})

	def colorposterize(self, param, value):
		root.addFilter("colorposterize",lambda x: add_colorposterize(x), lambda x: colorposterize(param, x), {param : value})

	def columnaverage(self, param, value):
		root.addFilter("columnaverage",lambda x: add_columnaverage(x), lambda x: columnaverage(param, x), {param : value})

	def comiceffect(self, param, value):
		root.addFilter("comiceffect",lambda x: add_comiceffect(x), lambda x: comiceffect(param, x), {param : value})

	def constantcolorgenerator(self, param, value):
		root.addFilter("constantcolorgenerator",lambda x: add_constantcolorgenerator(x), lambda x: constantcolorgenerator(param, x), {param : value})

	def copymachinetransition(self, param, value):
		root.addFilter("copymachinetransition",lambda x: add_copymachinetransition(x), lambda x: copymachinetransition(param, x), {param : value})

	def crop(self, param, value):
		root.addFilter("crop",lambda x: add_crop(x), lambda x: crop(param, x), {param : value})

	def crystallize(self, param, value):
		root.addFilter("crystallize",lambda x: add_crystallize(x), lambda x: crystallize(param, x), {param : value})

	def darkenblendmode(self, param, value):
		root.addFilter("darkenblendmode",lambda x: add_darkenblendmode(x), lambda x: darkenblendmode(param, x), {param : value})

	def differenceblendmode(self, param, value):
		root.addFilter("differenceblendmode",lambda x: add_differenceblendmode(x), lambda x: differenceblendmode(param, x), {param : value})

	def discblur(self, param, value):
		root.addFilter("discblur",lambda x: add_discblur(x), lambda x: discblur(param, x), {param : value})

	def disintegratewithmasktransition(self, param, value):
		root.addFilter("disintegratewithmasktransition",lambda x: add_disintegratewithmasktransition(x), lambda x: disintegratewithmasktransition(param, x), {param : value})

	def displacementdistortion(self, param, value):
		root.addFilter("displacementdistortion",lambda x: add_displacementdistortion(x), lambda x: displacementdistortion(param, x), {param : value})

	def dissolvetransition(self, param, value):
		root.addFilter("dissolvetransition",lambda x: add_dissolvetransition(x), lambda x: dissolvetransition(param, x), {param : value})

	def dotscreen(self, param, value):
		root.addFilter("dotscreen",lambda x: add_dotscreen(x), lambda x: dotscreen(param, x), {param : value})

	def edges(self, param, value):
		root.addFilter("edges",lambda x: add_edges(x), lambda x: edges(param, x), {param : value})

	def edgework(self, param, value):
		root.addFilter("edgework",lambda x: add_edgework(x), lambda x: edgework(param, x), {param : value})

	def eightfoldreflectedtile(self, param, value):
		root.addFilter("eightfoldreflectedtile",lambda x: add_eightfoldreflectedtile(x), lambda x: eightfoldreflectedtile(param, x), {param : value})

	def exclusionblendmode(self, param, value):
		root.addFilter("exclusionblendmode",lambda x: add_exclusionblendmode(x), lambda x: exclusionblendmode(param, x), {param : value})

	def exposureadjust(self, param, value):
		root.addFilter("exposureadjust",lambda x: add_exposureadjust(x), lambda x: exposureadjust(param, x), {param : value})

	def falsecolor(self, param, value):
		root.addFilter("falsecolor",lambda x: add_falsecolor(x), lambda x: falsecolor(param, x), {param : value})

	def flashtransition(self, param, value):
		root.addFilter("flashtransition",lambda x: add_flashtransition(x), lambda x: flashtransition(param, x), {param : value})

	def fourfoldreflectedtile(self, param, value):
		root.addFilter("fourfoldreflectedtile",lambda x: add_fourfoldreflectedtile(x), lambda x: fourfoldreflectedtile(param, x), {param : value})

	def fourfoldrotatedtile(self, param, value):
		root.addFilter("fourfoldrotatedtile",lambda x: add_fourfoldrotatedtile(x), lambda x: fourfoldrotatedtile(param, x), {param : value})

	def fourfoldtranslatedtile(self, param, value):
		root.addFilter("fourfoldtranslatedtile",lambda x: add_fourfoldtranslatedtile(x), lambda x: fourfoldtranslatedtile(param, x), {param : value})

	def gammaadjust(self, param, value):
		root.addFilter("gammaadjust",lambda x: add_gammaadjust(x), lambda x: gammaadjust(param, x), {param : value})

	def gaussianblur(self, param, value):
		root.addFilter("gaussianblur",lambda x: add_gaussianblur(x), lambda x: gaussianblur(param, x), {param : value})

	def gaussiangradient(self, param, value):
		root.addFilter("gaussiangradient",lambda x: add_gaussiangradient(x), lambda x: gaussiangradient(param, x), {param : value})

	def glassdistortion(self, param, value):
		root.addFilter("glassdistortion",lambda x: add_glassdistortion(x), lambda x: glassdistortion(param, x), {param : value})

	def glasslozenge(self, param, value):
		root.addFilter("glasslozenge",lambda x: add_glasslozenge(x), lambda x: glasslozenge(param, x), {param : value})

	def glidereflectedtile(self, param, value):
		root.addFilter("glidereflectedtile",lambda x: add_glidereflectedtile(x), lambda x: glidereflectedtile(param, x), {param : value})

	def gloom(self, param, value):
		root.addFilter("gloom",lambda x: add_gloom(x), lambda x: gloom(param, x), {param : value})

	def hardlightblendmode(self, param, value):
		root.addFilter("hardlightblendmode",lambda x: add_hardlightblendmode(x), lambda x: hardlightblendmode(param, x), {param : value})

	def hatchedscreen(self, param, value):
		root.addFilter("hatchedscreen",lambda x: add_hatchedscreen(x), lambda x: hatchedscreen(param, x), {param : value})

	def heightfieldfrommask(self, param, value):
		root.addFilter("heightfieldfrommask",lambda x: add_heightfieldfrommask(x), lambda x: heightfieldfrommask(param, x), {param : value})

	def hexagonalpixellate(self, param, value):
		root.addFilter("hexagonalpixellate",lambda x: add_hexagonalpixellate(x), lambda x: hexagonalpixellate(param, x), {param : value})

	def holedistortion(self, param, value):
		root.addFilter("holedistortion",lambda x: add_holedistortion(x), lambda x: holedistortion(param, x), {param : value})

	def hueadjust(self, param, value):
		root.addFilter("hueadjust",lambda x: add_hueadjust(x), lambda x: hueadjust(param, x), {param : value})

	def hueblendmode(self, param, value):
		root.addFilter("hueblendmode",lambda x: add_hueblendmode(x), lambda x: hueblendmode(param, x), {param : value})

	def kaleidoscope(self, param, value):
		root.addFilter("kaleidoscope",lambda x: add_kaleidoscope(x), lambda x: kaleidoscope(param, x), {param : value})

	def lanczosscaletransform(self, param, value):
		root.addFilter("lanczosscaletransform",lambda x: add_lanczosscaletransform(x), lambda x: lanczosscaletransform(param, x), {param : value})

	def lenticularhalogenerator(self, param, value):
		root.addFilter("lenticularhalogenerator",lambda x: add_lenticularhalogenerator(x), lambda x: lenticularhalogenerator(param, x), {param : value})

	def lightenblendmode(self, param, value):
		root.addFilter("lightenblendmode",lambda x: add_lightenblendmode(x), lambda x: lightenblendmode(param, x), {param : value})

	def lineargradient(self, param, value):
		root.addFilter("lineargradient",lambda x: add_lineargradient(x), lambda x: lineargradient(param, x), {param : value})

	def lineoverlay(self, param, value):
		root.addFilter("lineoverlay",lambda x: add_lineoverlay(x), lambda x: lineoverlay(param, x), {param : value})

	def linescreen(self, param, value):
		root.addFilter("linescreen",lambda x: add_linescreen(x), lambda x: linescreen(param, x), {param : value})

	def luminosityblendmode(self, param, value):
		root.addFilter("luminosityblendmode",lambda x: add_luminosityblendmode(x), lambda x: luminosityblendmode(param, x), {param : value})

	def masktoalpha(self, param, value):
		root.addFilter("masktoalpha",lambda x: add_masktoalpha(x), lambda x: masktoalpha(param, x), {param : value})

	def maximumcomponent(self, param, value):
		root.addFilter("maximumcomponent",lambda x: add_maximumcomponent(x), lambda x: maximumcomponent(param, x), {param : value})

	def maximumcompositing(self, param, value):
		root.addFilter("maximumcompositing",lambda x: add_maximumcompositing(x), lambda x: maximumcompositing(param, x), {param : value})

	def medianfilter(self, param, value):
		root.addFilter("medianfilter",lambda x: add_medianfilter(x), lambda x: medianfilter(param, x), {param : value})

	def minimumcomponent(self, param, value):
		root.addFilter("minimumcomponent",lambda x: add_minimumcomponent(x), lambda x: minimumcomponent(param, x), {param : value})

	def minimumcompositing(self, param, value):
		root.addFilter("minimumcompositing",lambda x: add_minimumcompositing(x), lambda x: minimumcompositing(param, x), {param : value})

	def modtransition(self, param, value):
		root.addFilter("modtransition",lambda x: add_modtransition(x), lambda x: modtransition(param, x), {param : value})

	def motionblur(self, param, value):
		root.addFilter("motionblur",lambda x: add_motionblur(x), lambda x: motionblur(param, x), {param : value})

	def multiplyblendmode(self, param, value):
		root.addFilter("multiplyblendmode",lambda x: add_multiplyblendmode(x), lambda x: multiplyblendmode(param, x), {param : value})

	def multiplycompositing(self, param, value):
		root.addFilter("multiplycompositing",lambda x: add_multiplycompositing(x), lambda x: multiplycompositing(param, x), {param : value})

	def noisereduction(self, param, value):
		root.addFilter("noisereduction",lambda x: add_noisereduction(x), lambda x: noisereduction(param, x), {param : value})

	def optile(self, param, value):
		root.addFilter("optile",lambda x: add_optile(x), lambda x: optile(param, x), {param : value})

	def overlayblendmode(self, param, value):
		root.addFilter("overlayblendmode",lambda x: add_overlayblendmode(x), lambda x: overlayblendmode(param, x), {param : value})

	def pagecurltransition(self, param, value):
		root.addFilter("pagecurltransition",lambda x: add_pagecurltransition(x), lambda x: pagecurltransition(param, x), {param : value})

	def parallelogramtile(self, param, value):
		root.addFilter("parallelogramtile",lambda x: add_parallelogramtile(x), lambda x: parallelogramtile(param, x), {param : value})

	def perspectivetile(self, param, value):
		root.addFilter("perspectivetile",lambda x: add_perspectivetile(x), lambda x: perspectivetile(param, x), {param : value})

	def perspectivetransform(self, param, value):
		root.addFilter("perspectivetransform",lambda x: add_perspectivetransform(x), lambda x: perspectivetransform(param, x), {param : value})

	def pinchdistortion(self, param, value):
		root.addFilter("pinchdistortion",lambda x: add_pinchdistortion(x), lambda x: pinchdistortion(param, x), {param : value})

	def pixellate(self, param, value):
		root.addFilter("pixellate",lambda x: add_pixellate(x), lambda x: pixellate(param, x), {param : value})

	def pointillize(self, param, value):
		root.addFilter("pointillize",lambda x: add_pointillize(x), lambda x: pointillize(param, x), {param : value})

	def radialgradient(self, param, value):
		root.addFilter("radialgradient",lambda x: add_radialgradient(x), lambda x: radialgradient(param, x), {param : value})

	def randomgenerator(self, param, value):
		root.addFilter("randomgenerator",lambda x: add_randomgenerator(x), lambda x: randomgenerator(param, x), {param : value})

	def rippletransition(self, param, value):
		root.addFilter("rippletransition",lambda x: add_rippletransition(x), lambda x: rippletransition(param, x), {param : value})

	def rowaverage(self, param, value):
		root.addFilter("rowaverage",lambda x: add_rowaverage(x), lambda x: rowaverage(param, x), {param : value})

	def saturationblendmode(self, param, value):
		root.addFilter("saturationblendmode",lambda x: add_saturationblendmode(x), lambda x: saturationblendmode(param, x), {param : value})

	def screenblendmode(self, param, value):
		root.addFilter("screenblendmode",lambda x: add_screenblendmode(x), lambda x: screenblendmode(param, x), {param : value})

	def sepiatone(self, param, value):
		root.addFilter("sepiatone",lambda x: add_sepiatone(x), lambda x: sepiatone(param, x), {param : value})

	def shadedmaterial(self, param, value):
		root.addFilter("shadedmaterial",lambda x: add_shadedmaterial(x), lambda x: shadedmaterial(param, x), {param : value})

	def sharpenluminance(self, param, value):
		root.addFilter("sharpenluminance",lambda x: add_sharpenluminance(x), lambda x: sharpenluminance(param, x), {param : value})

	def sixfoldreflectedtile(self, param, value):
		root.addFilter("sixfoldreflectedtile",lambda x: add_sixfoldreflectedtile(x), lambda x: sixfoldreflectedtile(param, x), {param : value})

	def sixfoldrotatedtile(self, param, value):
		root.addFilter("sixfoldrotatedtile",lambda x: add_sixfoldrotatedtile(x), lambda x: sixfoldrotatedtile(param, x), {param : value})

	def softlightblendmode(self, param, value):
		root.addFilter("softlightblendmode",lambda x: add_softlightblendmode(x), lambda x: softlightblendmode(param, x), {param : value})

	def sourceatopcompositing(self, param, value):
		root.addFilter("sourceatopcompositing",lambda x: add_sourceatopcompositing(x), lambda x: sourceatopcompositing(param, x), {param : value})

	def sourceincompositing(self, param, value):
		root.addFilter("sourceincompositing",lambda x: add_sourceincompositing(x), lambda x: sourceincompositing(param, x), {param : value})

	def sourceoutcompositing(self, param, value):
		root.addFilter("sourceoutcompositing",lambda x: add_sourceoutcompositing(x), lambda x: sourceoutcompositing(param, x), {param : value})

	def sourceovercompositing(self, param, value):
		root.addFilter("sourceovercompositing",lambda x: add_sourceovercompositing(x), lambda x: sourceovercompositing(param, x), {param : value})

	def spotcolor(self, param, value):
		root.addFilter("spotcolor",lambda x: add_spotcolor(x), lambda x: spotcolor(param, x), {param : value})

	def spotlight(self, param, value):
		root.addFilter("spotlight",lambda x: add_spotlight(x), lambda x: spotlight(param, x), {param : value})

	def starshinegenerator(self, param, value):
		root.addFilter("starshinegenerator",lambda x: add_starshinegenerator(x), lambda x: starshinegenerator(param, x), {param : value})

	def stripesgenerator(self, param, value):
		root.addFilter("stripesgenerator",lambda x: add_stripesgenerator(x), lambda x: stripesgenerator(param, x), {param : value})

	def sunbeamsgenerator(self, param, value):
		root.addFilter("sunbeamsgenerator",lambda x: add_sunbeamsgenerator(x), lambda x: sunbeamsgenerator(param, x), {param : value})

	def swipetransition(self, param, value):
		root.addFilter("swipetransition",lambda x: add_swipetransition(x), lambda x: swipetransition(param, x), {param : value})

	def toruslensdistortion(self, param, value):
		root.addFilter("toruslensdistortion",lambda x: add_toruslensdistortion(x), lambda x: toruslensdistortion(param, x), {param : value})

	def triangletile(self, param, value):
		root.addFilter("triangletile",lambda x: add_triangletile(x), lambda x: triangletile(param, x), {param : value})

	def twelvefoldreflectedtile(self, param, value):
		root.addFilter("twelvefoldreflectedtile",lambda x: add_twelvefoldreflectedtile(x), lambda x: twelvefoldreflectedtile(param, x), {param : value})

	def twirldistortion(self, param, value):
		root.addFilter("twirldistortion",lambda x: add_twirldistortion(x), lambda x: twirldistortion(param, x), {param : value})

	def unsharpmask(self, param, value):
		root.addFilter("unsharpmask",lambda x: add_unsharpmask(x), lambda x: unsharpmask(param, x), {param : value})

	def vortexdistortion(self, param, value):
		root.addFilter("vortexdistortion",lambda x: add_vortexdistortion(x), lambda x: vortexdistortion(param, x), {param : value})

	def whitepointadjust(self, param, value):
		root.addFilter("whitepointadjust",lambda x: add_whitepointadjust(x), lambda x: whitepointadjust(param, x), {param : value})

	def zoomblur(self, param, value):
		root.addFilter("zoomblur",lambda x: add_zoomblur(x), lambda x: zoomblur(param, x), {param : value})

root = ROOT_I_6732()
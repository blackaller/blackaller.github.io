#
#  Script for testing out the Yahoo search API. 
#  It does a few queries, then lays out the results in a "four petal rose" shape.
#
#  yahoo-search.py
#  E15
#
#  Created by Kate Hollenbach on 10/20/07.
#  Copyright (c) 2007 MIT Media Lab PLW. All rights reserved.
#


from staticwriter import *
import urllib
import simplejson
from math import *

# some terms to search for
terms = ["john maeda", "kate hollenbach", "luis blackaller", "takashi okamoto", "kyle buza"]

# Kate's Yahoo! search API key
appid = "qEZRBaPV34FQ6nttIzUGN9sf0I9qsKTAQVWPjXgejZAxQIMmjv3hPVPJ9sm2AVZo5HKR"


i = 0 # number of search results thus far
z = 0 # depth
a = 2 # petal size

# this is the query base
query = "http://search.yahooapis.com/WebSearchService/V1/webSearch"


for term in terms:
	params = urllib.urlencode( { 
			'appid' : appid,   # pass API key
			'query' : term,    # the query term
			'output' : 'json' 
	} )
	
  # perform the query and parse the JSON from the results
	data = urllib.urlopen(query, params).read()
	json = simplejson.loads(data)
	numresults = json['ResultSet']['totalResultsReturned']
	resultset = json['ResultSet']
	results = json['ResultSet']['Result']
	
	#transparent backgrounds?
	#background(0, 0, 0, 0)
	
  # render title, url and summary for each result.
	for result in results:
    # calculate position along four petal rose curve in polar coordinates.
		theta = 2.0 * pi * i / 50
		r = a * sin(2.0 * theta);
    # convert from polar coordinates to cartesian
		x = r * cos(theta)
		y = r * sin(theta)

		elem_begin(1000, 400, "elem")
		elem_pos(x, y, z)
		fontcolor(1, 1.0, 0.1, 0.9)
		font("ApexSansBookT", 20.0)
		text(result['Title'].encode('utf8'), 0, 200, 1000)
		fontcolor(.5, .81, 1.0, 0.9)
		text(result['Url'].encode('utf8'), 0, 180, 1000)
		elem_end()
		z += 0.01
		elem_begin(1000, 400, "elem")
		elem_pos(x, y, z)
		elem_xform(0, -90, 0.0)
		fontcolor(.94, 0.5, 0.5, 0.9) # coral
		text(result['Summary'].encode('utf8'), 0, 200, 1000)
		elem_end()
		z += .1
		i += 1
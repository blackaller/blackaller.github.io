from staticwriter import *
from math import *
from random import random

clusters = []
URL_PREFIX = 'http://e15.media.mit.edu/_E15'

class Cluster():
  def __init__(self, name_in, xin, yin, zin, rin, prefix, piles_in, mode):
    self.name = name_in 
    self.x = xin
    self.y = yin
    self.z = zin
    self.radius = rin
    self.piles = piles_in
    self.mode = mode
    self.prefix = prefix

    #draw title
    fontcolor(1, 1.0, 0.1, 0.9)
    font("ApexNew-Bold", 190.0)
    textbox(self.name, self.name, 1024, self.x, self.y, self.z + 3)
    num_piles = len(self.piles)
    
    
    if mode == 0:
      for k in range(len(self.piles[0].images)):
        posx = self.x
        posy = self.y
        posz = self.z - k*4
        imgload(self.prefix + self.piles[0].images[k][0], str(k), posx, posy, posz, 0, -90, 0)
        fontcolor(1, 1.0, 0.1, 0.9)
        font("ApexNew-Bold", 70.0)
        textbox(self.name + "_details_" + `k`, self.piles[0].images[k][1], 768, posx+0.1, posy, posz+0.02)
      
    elif mode == 1:
      num_images = len(self.piles[0].images)
      for k in range(num_images):
        posx = self.x + self.radius * cos(2*pi*k/num_images)
        posy = self.y + self.radius * sin(2*pi*k/num_images)
        imgload(self.prefix + self.piles[0].images[k][0], self.name + "_image_" + `k`, posx, posy, self.z - k*4, 0, -10, 0)
    
    elif mode == 2:
      for k in range(len(self.piles[0].images)):
        posx = self.x + 2 + self.radius * k
        posy = self.y
        imgload(self.prefix + self.piles[0].images[k][0], self.name + "_image_" + `k`, posx, posy, self.z - k*0.01, 0, -35, 0)

class Pile():
  def __init__(self, name_in, image_nums):
    self.name = name_in
    self.images = image_nums
    
    
###############################################################################
# STEP 1
# LOADING PAGE

x, y, z = (0, 0, -10)
imgload(URL_PREFIX + "/pages/openstudio.png", "os", x, y, z, 0, -10, 0)

fontcolor(1, 1.0, 0.1, 0.9)
font("ApexNew-Bold", 50.0)
textbox("openstudio", "http://openstudio.media.mit.edu", 768, x-.5, y+1.5, z+0.01,0, 20, 0)

###############################################################################
# STEP 2
# LOADING PAGE

x, y, z = (2, 1.5, -12)
imgload(URL_PREFIX + "/pages/opencode.png", "oc", x, y, z, 0, -10, 0)
fontcolor(1, 1.0, 0.1, 0.9)
font("ApexNew-Bold", 50.0)
textbox("opencode", "http://opencode.media.mit.edu", 768, x-.5, y+1, z+0.01,0, 20, 0)

###############################################################################
# MOVE BACK TO SHOW EVERYTHING
# Just by introducing web pages into this 3d environment,  you can see that there already is a  visualization of history.
# You can go back and forth from a site easily.
###############################################################################


###############################################################################
# STEP 4: MAKE SURE YOU MOVE BACK SO WE CAN SHOW
# ANOTHER THING WE CAN DO IS LOAD SETS OF RELATED PAGES.

# Group pages
x, y, z, r, prefix = (-3, 0, 4, 2, URL_PREFIX + "/pgset/")
p1 = Pile("plw", [["66.png", "http://plw.media.mit.edu/people/maeda"], ["68.png", "http://mudcorp.com"], ["15.png", "http://web.mit.edu/mud/www/"], ["60.png", "http://www.media.mit.edu/~mud"], ["65.png", "http://web.media.mit.edu/~black"]])
plw_cluster = Cluster("Physical Language Workshop", x, y, z, r, prefix, [p1], 0)

# News Pages
x, y, z, r, prefix = (-7, 1, 5, 2, URL_PREFIX + "/set/")
p1 = Pile("plw", [["news1.png", "http://www.pbs.org"], ["news2.png", "http://www.technologyreview.com"], ["news3.png", "http://www.wired.com"], ["news4.png", "http://www.reuters.com"], ["news5.png", "http://nytimes.com"], ["news6.png", "http://www.bbc.co.uk"]])
plw_cluster = Cluster("Daily News Sites", x, y, z, r, prefix, [p1], 0)


###############################################################################
# Right now, we're just introducing pages as they exist now.
# Web servers generally give us rendered html pages, where all the content is laid out and designed.
# But now many sites offer web services in which you can make a request and receive content where we are free to manipulate.
# So this is a new environment in which we can really ask the question, what can we do with this new environment, and how can we extend the web?
###############################################################################


###############################################################################
# STEP 5: Show PLW
#

x, y, z, r, prefix = (10, 10, -10, 5, URL_PREFIX + "/plw/")
plw = [["Henry Holtzman", "person/28/showface.php.jpg"], ["Jun Sato", "person/19/junsato.jpg"], ["Brent Fitzgerald", "person/1/pic.jpg"], ["Nozomi Kakiuchi", "person/33/3114125_3176024765.jpg"], ["Mariana Baca", "person/15/me.jpg"], ["Luis Blackaller", "person/5/yo_100_5.jpg"], ["Sanghoon Lee", "person/30/PICT2085.jpg"], ["Amber Frid-Jimenez", "person/22/amber9.jpg"], ["Adrienne Bolger", "person/10/photo.jpg"], ["Ishwinder Kaur", "person/25/pic.jpg"], ["John Maeda", "person/18/jm.jpg"], ["Takashi Okamoto", "person/17/DSCN3497.jpg"], ["Lihua Bai", "person/12/lihua2.png"], ["Martini", "person/32/plwpic.jpg"], ["Amna Carreiro", "person/13/amna.jpg"], ["Kate Hollenbach", "person/26/Picture_2.png"], ["Kyle Buza", "person/24/kb.jpg"], ["OGFX", "graphic/115/OpenGFX520.png"], ["__OGFX", "graphic/117/OpenGFX512.png"], ["___OGFX", "graphic/118/OpenGFX474.png"], ["ogfx_", "graphic/119/OpenGFX321.png"], ["____OGFX", "graphic/120/OpenGFX499.png"], ["_____OGFX", "graphic/121/OpenGFX473.png"], ["ogfx__", "graphic/124/OpenGFX330.png"], ["________OGFX", "graphic/125/OpenGFX452.png"], ["_________OGFX", "graphic/126/OpenGFX381.png"], ["_OGFX_", "graphic/128/kf.gif"], ["__OGFX_", "graphic/129/cbar.gif"], ["___oGFx_", "graphic/130/flw.gif"], ["___oGFx___", "graphic/131/spray.gif"], ["_oGFx___", "graphic/132/vessels.jpg"], ["BlogKitchen", "video/21/blogkitchen.png"], ["oGFX demo", "video/26/swirl1.png"], ["OpenWeb demo", "video/27/ow_1.gif"], ["e15.gfx", "video/28/OpenGFX003_800.jpg"]]

for i in range(len(plw)):
  # image
  posx = x + (random()-0.5)*10
  posy = y + (random()-0.5)*10
  posz = z + (random()-0.5)*10
  imgload(prefix + str(plw[i][1]), str(plw[i][1]), posx, posy, posz, 0, 0, 0)
  fontcolor(1, 1.0, 0.1, 0.9)
  font("ApexNew-Bold", 20.0)
  textbox("plw_" + `i`, plw[i][0], 768, posx+0.1, posy, posz+0.02,0, 20, 0)

fontcolor(1, 1.0, 0.1, 0.9)
font("ApexNew-Bold", 130.0)
textbox("plw", "http://plw.media.mit.edu", 1600, 10, 16, 16, 0, 20, 0)




###############################################################################
# STEP 6: Show RUNLOG
#
x, y, z = (10, 1.5, -20)
fontcolor(1, 1.0, 0.1, 0.9)
font("ApexNew-Bold", 70.0)
textbox("runlog", "http://runlog.media.mit.edu", 1600, x, y+2, z+.5, 0, 20, 0)

imgload(URL_PREFIX + "/pages/runlog.png", "rl", x, y, z, 0, -25, 0)

runners = [[1, 'n713154_38419.jpg', 1198.43], [330, 'DSCF0014.jpg', 949.50], [319, '01-022Barcelona.jpg', 804.45], [315, 'icon.png', 577.69], [430, 'mt_lincoln.jpg', 488.50], [38, 'images.jpg', 470.00], [312, 'images.jpg', 467.99], [139, '99942665_N00.jpg', 443.09], [349, 'avatar-chip-100.jpg', 403.00], [294, 'p.jpg', 333.02], [48, 'bananas.jpg', 319.42], [433, 'Chouchin_Reinensai__Lantern_.gif', 291.75], [3, 'pic.jpg', 252.17], [176, 'MaryLex.jpg', 182.30], [4457, 'IMG_4965-1.jpg', 155.35], [469, 'beerAvatar1.png', 155.24], [364, '2007_03_29_tatto_i_like.jpg', 144.50], [3901, 'daveg.jpg', 132.22], [304, 'avatar_head.jpg', 122.84], [422, 'fishbowl.jpg', 75.35], [318, '1.bmp', 58.70], [272, 'dan_square.jpg', 41.57], [356, 'IMG_0697.jpg', 40.55], [293, 'BangYourHead.gif', 34.00], [260, 'myphoto.jpg', 28.00], [527, 'images.jpg', 23.61], [5492, 'Photo_40.jpg', 16.59], [4367, 'me.png', 7.11], [5364, 'n19904265_30910447_5144.jpg', 5.60], [216, 'pic.jpg', 3.00]]

y -= 1
font("ApexNew-Bold", 30)
print len(runners)
for i in range(len(runners)):
  pict_location = URL_PREFIX + "/runlog/image/" + `runners[i][0]` + "/" + runners[i][1]
  imgload(pict_location, str(i), x, y-i/5.0, z-i/2.003, 0, 0, 0)
  elem_begin(200, 60, str(1))
  elem_pos(x+.4, y-i/5.0+.05, z-i/2.0004-.05)
  fontcolor(1, 0.1, 0.1, 0.9)
  text(`i+1`, 5, 25)
  fontcolor(0.0, 1.0, 0.8, 0.9)
  text("\n" + '%.2f' % (runners[i][2]) + "mi", 5, 25)
  elem_end()

font("ApexNew-Bold", 80)
fontcolor(1.0, 0.4, 0.8, 0.9)
elem_begin(400, 300, str(1))
elem_pos(10, .35, -18.1)
text("Top Overall Distance", 5, 60)
elem_end()

sessions = [[315, 'icon.png', 8.8875148222997], [319, '01-022Barcelona.jpg', 6.7600840400247], [481, 'Sushi.bmp', 6.6279596686363], [1, 'n713154_38419.jpg', 6.4431720677242], [3901, 'daveg.jpg', 5.7487642972366], [273, 'HPIM1889.jpg', 5.7392857415336], [312, 'images.jpg', 5.6383958925684], [294, 'p.jpg', 4.625277787447], [5431, 'menj.jpg', 4.0], [843, 'Chouchin_Reinensai__Lantern_.gif', 3.9021739130435], [256, '612de7c66e61bb98ed0fab2dcd8f1e69.png', 3.8134998530149], [211, 'SP-avatar.png', 3.7138738373052], [4457, 'IMG_4965-1.jpg', 3.6127907120904], [48, 'bananas.jpg', 3.549149100648], [304, 'avatar_head.jpg', 3.5097143241337], [5518, 'CIMG3493.jpg', 3.2814316408975], [318, '1.bmp', 2.9349999785423], [38, 'images.jpg', 2.7011765796563], [3, 'pic.jpg', 2.5600662745681], [364, '2007_03_29_tatto_i_like.jpg', 2.5350877192982], [421, 'douglasjarquin-black-and-white-medium.jpg', 2.0712355640199], [272, 'dan_square.jpg', 1.8076495764158], [260, 'myphoto.jpg', 1.75], [5358, 'girl_runner2.gif', 1.2427424192429]]

x, y, z = (9, 2.5, -20)

font("ApexNew-Bold", 30)
for i in range(len(sessions)):
  pict_location = URL_PREFIX + "/runlog/image/" + `sessions[i][0]` + "/" + sessions[i][1]
  imgload(pict_location, str(i), x, y+i/5.0, z-i/2.002, 0, 0, 0)
  elem_begin(200, 60, str(1))
  elem_pos(x+.4, y+i/5.0+.05, z-i/2.001-.05)
  fontcolor(1, 0.1, 0.1, 0.9)
  text(`i+1`, 5, 25)
  fontcolor(0.0, 1.0, 0.8, 0.9)
  text("\n" + '%.2f' % (sessions[i][2]) + "mi", 5, 25)
  elem_end()

font("ApexNew-Bold", 80)
fontcolor(1.0, 0.4, 0.8, 0.9)
elem_begin(400, 300, str(1))
elem_pos(9, 2.35, -18.001)
text("Top Session Average", 5, 60)
elem_end()

members = [[5518, 'CIMG3493.jpg', 3.2814316408975], [5431, 'menj.jpg', 4.0], [5358, 'girl_runner2.gif', 1.2427424192429], [4457, 'IMG_4965-1.jpg', 3.6127907120904], [3901, 'daveg.jpg', 5.7487642972366], [843, 'Chouchin_Reinensai__Lantern_.gif', 3.9021739130435], [481, 'Sushi.bmp', 6.6279596686363], [421, 'douglasjarquin-black-and-white-medium.jpg', 2.0712355640199]]

x, y, z = (11, 1, -20)
font("ApexNew-Bold", 30)
for i in range(len(members)):
  pict_location = URL_PREFIX + "/runlog/image/" + `members[i][0]` + "/" + members[i][1]
  imgload(pict_location, str(i), x+i/4.0, y, z-i/4.001, 0, 0, 0)

font("ApexNew-Bold", 80)
fontcolor(1.0, 0.4, 0.8, 0.9)
elem_begin(400, 300, str(1))
elem_pos(11.28, 1.25, -18)
text("New Members", 5, 60)
elem_end()


###############################################################################
# STEP 7: Show E15
#
x, y, z = (0, 0, 0)

elem_begin(800, 200, str(1))
elem_pos(x, y+3, z+.5)
fontcolor(1, 1.0, 0.1, 0.9)
font("ApexNew-Bold", 70.0)
text("http://e15.media.mit.edu", 0, 100)
elem_end()

imgload(URL_PREFIX + "/pages/e15.png", "e15", x, y, z, 0, 25, 0)

r = 3.0
for i in range(11):
  deg = (i/11.0*360)
  x = r*cos(radians (deg))
  z = -r*sin(radians (deg))+1
  imgload(URL_PREFIX + "/_extra/" + `i` + ".jpg", "extra" + `i`, x, y, z, 0, 180+deg, 0)
  
def onHit(e_id):
  print e_id
  camera_goto(e_id)
from staticwriter import *
from inspect import *
from string import upper

class OutRedirect:
	def __init__(self, stdout):
		self.stdout = stdout
	def write(self, s):
		capturestdout(s)

class ErrRedirect:
	def __init__(self, stdout):
		self.stdout = stdout
	def write(self, s):
		capturestderr(s)
        
sys.stderr = ErrRedirect(sys.stderr)
sys.stdout = OutRedirect(sys.stdout)


def console_input(message, magic_string='Yes'):
  print message
  open("/tmp/STDIN.txt", "w").write("# STDIN #")
  saved_state = sys.stdin
  sys.stdin = open("/tmp/STDIN.txt")
  line = sys.stdin.readline().strip()
  prev_result = line
  first_time = True
  while upper(line) != upper(magic_string):
    if prev_result != line and first_time == False:
        print 'Please answer ' + magic_string
        prev_result = line
    first_time = False
    sys.stdin = open("/tmp/STDIN.txt")
    line = sys.stdin.readline().strip()
  sys.stdin = saved_state
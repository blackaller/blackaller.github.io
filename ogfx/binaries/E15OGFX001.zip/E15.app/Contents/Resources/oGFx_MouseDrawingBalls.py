#
#  MouseDrawingBalls.py
#  OpenGFX
#
#  Created by blackaller on 10/24/07.
#  Copyright (c) 2007 MITPLW. All rights reserved.
#  A doodle is a list of Point2Ds
#

from drawengine import *
from math import *

history(50,0.001)
envcolor(0.05,0.05,0.05)
blendmode(0,0)
#blendmode(4,0)
#root.gaussianblur("radius", 4)
#Size of the texture
size = 512

tsize(size)

mx = 0
my = 0

mouse()

class Point2D:
	def __init__(self, px, py):
		self.x = px
		self.y = py

px, py = 0, 0		
doodle = []

def draw():
	global mx, my, px, py, doodle
	background(1,1,1,0.01)
	linewidth(4)
	
	if mx != px and my != py:
		#doodle.append(Point2D(mx,my))
		doodle.append(mapScreenToQuad(Point2D(mx,my)))
		px, py = mx, my
	
	doodle = transformDoodle(doodle)
	
	color(1,1,1,0.5)
	stroke(0, 0, 0, 0.8)
	push()
	translate(-12,-12)
	if len(doodle) > 0:
		for p2D in doodle:
			
			ellipse(p2D.x,p2D.y,24,24)
	pop()
			
	color(1,0,0,0.5)
	stroke(0, 0, 0, 0.8)
	push()
	translate(-8,-8)
	if len(doodle) > 0:
		for p2D in doodle:	
			ellipse(p2D.x,p2D.y,16,16)
	pop()
	
	
	#print mapScreenToQuad(Point2D(mx,my)).x, mapScreenToQuad(Point2D(mx,my)).y
			
def mapScreenToQuad(point):
	mapx = point.x * 512 / screenWidth
	mapy = point.y * 512 / screenHeight
	return Point2D(mapx,mapy)
	
def transformPoint(point, index, length):
	point.x += sin(index / 50.0) * (length - index) / 100.0
	point.y -= cos(index / 100.0) * (length - index) / 100.0
	if point.x < 0 or point.x > screenWidth or point.y < 0 or point.y > screenHeight:
		return None
	return point
	
def transformDoodle(doodle, f=transformPoint):
	length = len(doodle)
	newlist=[]
	for i, point in enumerate(doodle):
		newpoint = f(point, i, length)
		if newpoint is not None:
			newlist.append(newpoint)
	return newlist

#
#  e15_googlesearch.py
#  E15
#
#  Created by buza on 07/27/08.
#  Copyright 2007 buza. All rights reserved.
#

from staticwriter import *
from random import random

start = 1

def myrand():
  if random() < 0.5: 
    return random()
  else:
    return -random() 

def callphp1(s):
  print "Request for page ", s
  #The parameters we send to the php file.
  pdict = {"tag":"robot", "page":str(s+1), "size":"thumb"}

  #Send our request to the remote php file, and get a callback full of data on completion.
  rservice("http://buza.mitplw.com/gspeak/googleimg.php", pdict, "myCallback1")
  

global_elem_speed(0.08)

zz = 0
zzzz = 0

#This gets called when we get our data. This will always be a dictionary, but may only have keys, no values.
def myCallback1(dat):
  global zz
  global start
  global zzzz
  #print "callback!", dat
  fnames =[]
  idnames = []
  opos = []
  dpos = []
  ot = []
  dt = []
  owh = []
  dwh = []
  x = 0
  y = 0
  zzz = 0
  for iurl in dat.keys():
    zzz = zzz + 0.0001
    fnames.append(iurl)
    idnames.append(str(zzzz))
    opos.append([myrand()*60,myrand()*40, myrand()*70])
    dpos.append([x-6.0,y-5.0,zz + zzz])
    ot.append([0,0,0])
    dt.append([0,0,0])
    owh.append([0,0])
    dwh.append([80,80])
    zzzz = zzzz + 1
    x = x + 0.4 + random()/4
    if x > 4:
      x = 0
      y = y + 0.3 + random()/5
      
  zz -= 1
  imgloada(fnames, idnames, opos, dpos, ot, dt, owh, dwh, 1)
  
  if -zz < 10:
    callback("callphp1("+str(-zz)+")", 1)


callphp1(0)

  
def onHit(e):
  print e
  camera_goto(e, -.3, .3, 0)

def onShake():
  print "shake!"

def onSelect(e):
  print e
  
  
pdict = {"tag":"robot"}
rservice("http://buza.mitplw.com/gspeak/flk_tags.php", pdict, "foo")

def foo(e):
  print "hello tags", e
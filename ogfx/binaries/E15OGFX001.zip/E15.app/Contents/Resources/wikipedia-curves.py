from staticwriter import *

import gdata.service, urllib

serv = gdata.service.GDataService()
feed = serv.Get("http://gdata.youtube.com/feeds/api/videos?vq=vectrex&start-index=12&max-results=4")
envcolor(1, 1, 1)
z = 0
def printElements(ext_element):

   global z
   if ext_element.tag == 'thumbnail':
     #imgload(ext_element.attributes['url'], str(z), 0, 0, -z, 0, 0, 0, 0, 0)
     z = z + 0.5
   if ext_element.attributes.has_key('type'):
     if(ext_element.attributes['type'] == "video/3gpp"):
       if ext_element.attributes.has_key('{http://gdata.youtube.com/schemas/2007}format'):
         if ext_element.attributes['{http://gdata.youtube.com/schemas/2007}format'] == '6':
           loadmovie(ext_element.attributes['url'], ext_element.attributes['url'])
           startmovie(ext_element.attributes['url'], 3)
           elem_moveto(ext_element.attributes['url'], z, 0, -z, 0, 0, 0)
   if ext_element.children:
     for child in ext_element.children:
       printElements(child)

for entry in feed.entry:
  for ext_element in entry.extension_elements:
    printElements(ext_element)

def onHit(elem):
  print elem